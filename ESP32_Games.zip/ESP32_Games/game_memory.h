#pragma once
#define MR 4
#define MCO 5
#define MCL 90
static int8_t mmC[MR][MCO];static bool mmF[MR][MCO],mmM[MR][MCO];
static int mmF1R=-1,mmF1C=-1,mmF2R=-1,mmF2C=-1;static int mmPl,mmCr;static int mmSc[3];
static uint32_t mmPMs[3],mmLTk;static bool mmClk=false,mmGO=false;static uint32_t mmFT=0;static bool mmW=false;static char mmSt[64]="";static bool mmPD=true;
static uint32_t mmClrs[]={0xE53935,0x1E88E5,0x43A047,0xFDD835,0x8E24AA,0xF4511E,0x00ACC1,0x6D4C41,0xD81B60,0x546E7A};
static void mmShuf(){int8_t v[20];for(int i=0;i<10;i++){v[i*2]=i+1;v[i*2+1]=i+1;}for(int i=19;i>0;i--){int j=random(i+1);int8_t t=v[i];v[i]=v[j];v[j]=t;}
  int k=0;for(int r=0;r<MR;r++)for(int c=0;c<MCO;c++){mmC[r][c]=v[k++];mmF[r][c]=false;mmM[r][c]=false;}}
static void mmInit(int pl){mmPl=pl;mmCr=0;memset(mmSc,0,12);mmGO=false;mmF1R=mmF1C=mmF2R=mmF2C=-1;mmW=false;mmShuf();strcpy(mmSt,"Player 1's Turn");mmPD=true;}
static void mmDrawBoard(){lcd.fillRect(0,0,480,480,0x263238);int ox=(480-MCO*MCL)/2,oy=(480-MR*MCL)/2;
  for(int r=0;r<MR;r++)for(int c=0;c<MCO;c++){int x=ox+c*MCL+4,y=oy+r*MCL+4,w=MCL-8,h=MCL-8;
    if(mmM[r][c]){lcd.fillRoundRect(x,y,w,h,8,0x263238);continue;}
    if(mmF[r][c]){lcd.fillRoundRect(x,y,w,h,8,mmClrs[mmC[r][c]-1]);lcd.drawRoundRect(x,y,w,h,8,TX);lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(TX);char s[3];sprintf(s,"%d",mmC[r][c]);lcd.drawString(s,x+w/2-12,y+h/2-14);}
    else{lcd.fillRoundRect(x,y,w,h,8,0x37474F);lcd.drawRoundRect(x,y,w,h,8,0x546E7A);lcd.fillRoundRect(x+15,y+15,w-30,h-30,4,0x455A64);}}}
static void mmDrawPanels(){if(!mmPD)return;mmPD=false;lcd.fillRect(PX,0,PW,480,BGC);lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(0xE2B96F);lcd.drawCenterString("MEMORY",PX+PW/2,15);
  uint32_t pc[]={0xE53935,0x1E88E5,0x43A047};for(int i=0;i<mmPl;i++){int y=70+i*55;lcd.fillRoundRect(PX+15,y,PW-30,45,8,i==mmCr?pc[i]:0x333333);
    lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);char buf[32];sprintf(buf,"P%d: %d pairs",i+1,mmSc[i]);lcd.drawString(buf,PX+25,y+12);char tb[16];fmtTime(mmPMs[i],tb);lcd.drawString(tb,PX+210,y+12);}
  lcd.fillRect(PX,300,PW,60,BGC);drawNGBtn(PX,300,PW,60);
  if(mmGO){lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(0xF9A825);lcd.drawString(mmSt,PX+20,380);}}
static int mmSP=2;
void mm_drawOpt(){lcd.fillScreen(BGC);lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(0xE2B96F);lcd.drawCenterString("MEMORY",400,20);
  lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);lcd.drawString("Players:",100,80);
  for(int i=0;i<2;i++){int bx=250+i*150,by=70;lcd.fillRoundRect(bx,by,120,50,10,0x01579B);lcd.drawRoundRect(bx,by,120,50,10,0x0288D1);char s[2];sprintf(s,"%d",i+2);lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(TX);lcd.drawString(s,bx+45,by+10);}
  lcd.drawRoundRect(250,70,120,50,10,0xFFFF00);
  lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);lcd.drawString("Time per player:",100,160);
  int tms[]={5,10,15};const char*lb[]={"5 min","10 min","15 min"};for(int i=0;i<3;i++){int bx=100+i*200,by=200;lcd.fillRoundRect(bx,by,170,60,10,0x01579B);lcd.drawRoundRect(bx,by,170,60,10,0x0288D1);lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);lcd.drawCenterString(lb[i],bx+85,by+18);}}
void mm_handleOpt(int16_t tx,int16_t ty){for(int i=0;i<2;i++){int bx=250+i*150,by=70;if(tx>=bx&&tx<bx+120&&ty>=by&&ty<by+50){mmSP=i+2;lcd.drawRoundRect(250,70,120,50,10,0x01579B);lcd.drawRoundRect(400,70,120,50,10,0x01579B);lcd.drawRoundRect(bx,by,120,50,10,0xFFFF00);return;}}
  int tms[]={5,10,15};for(int i=0;i<3;i++){int bx=100+i*200,by=200;if(tx>=bx&&tx<bx+170&&ty>=by&&ty<by+60){mmInit(mmSP);for(int p=0;p<3;p++)mmPMs[p]=(uint32_t)tms[i]*60000;mmClk=true;mmLTk=millis();appState=2;lcd.fillScreen(BGC);mmDrawBoard();mmPD=true;mmDrawPanels();return;}}}
void mm_loop(){int16_t tx,ty,rx,ry;bool tch=tRaw(&rx,&ry);if(doNG(PX,300,PW,60,rx,ry,tch))return;
  if(mmW&&millis()-mmFT>1000){if(mmC[mmF1R][mmF1C]==mmC[mmF2R][mmF2C]){mmM[mmF1R][mmF1C]=mmM[mmF2R][mmF2C]=true;mmSc[mmCr]++;}
    else{mmF[mmF1R][mmF1C]=mmF[mmF2R][mmF2C]=false;mmCr=(mmCr+1)%mmPl;}mmF1R=mmF1C=mmF2R=mmF2C=-1;mmW=false;
    bool ad=true;for(int r=0;r<MR&&ad;r++)for(int c=0;c<MCO&&ad;c++)if(!mmM[r][c])ad=false;
    if(ad){mmGO=true;mmClk=false;
      // Tiebreaker: equal score -> most time wins
      int best=0,bp=0;for(int i=0;i<mmPl;i++)if(mmSc[i]>best){best=mmSc[i];bp=i;}
      // Check ties
      int tied=0;for(int i=0;i<mmPl;i++)if(mmSc[i]==best)tied++;
      if(tied>1){uint32_t bestT=0;for(int i=0;i<mmPl;i++)if(mmSc[i]==best&&mmPMs[i]>bestT){bestT=mmPMs[i];bp=i;}}
      sprintf(mmSt,"Player %d wins!",bp+1);}
    else sprintf(mmSt,"Player %d's Turn",mmCr+1);mmDrawBoard();mmPD=true;mmDrawPanels();}
  if(!ngH&&!mmW&&!mmGO&&tOnce(&tx,&ty)&&tx<480&&ty<480){int ox=(480-MCO*MCL)/2,oy=(480-MR*MCL)/2;int col=(tx-ox)/MCL,row=(ty-oy)/MCL;
    if(row>=0&&row<MR&&col>=0&&col<MCO&&!mmF[row][col]&&!mmM[row][col]){mmF[row][col]=true;if(mmF1R<0){mmF1R=row;mmF1C=col;}else{mmF2R=row;mmF2C=col;mmW=true;mmFT=millis();}mmDrawBoard();}}
  if(mmClk&&!mmGO){uint32_t now=millis(),dt=now-mmLTk;mmLTk=now;if(mmPMs[mmCr]<=dt){mmPMs[mmCr]=0;mmGO=true;mmClk=false;sprintf(mmSt,"P%d time out!",mmCr+1);mmPD=true;mmDrawPanels();}
    else mmPMs[mmCr]-=dt;static uint32_t mtl=0;if(now-mtl>500){mtl=now;
      // Minimal timer update: just redraw the timer text for current player
      int y=70+mmCr*55;uint32_t pc2[]={0xE53935,0x1E88E5,0x43A047};
      lcd.fillRect(PX+200,y+10,110,28,pc2[mmCr]);
      char tb2[16];fmtTime(mmPMs[mmCr],tb2);lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);lcd.drawString(tb2,PX+210,y+12);}
    }}

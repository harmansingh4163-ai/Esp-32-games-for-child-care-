#pragma once
// Chess state
static int8_t cb[8][8];static bool cwKM,cbKM,cwRA,cwRH,cbRA,cbRH;
static int8_t cEP;static bool cWT,cGO;static int cSR=-1,cSC=-1;static bool cPS=false;
static int cVM[64][2],cVC=0;static int cHMC=0;static uint32_t cPH[600];static int cPN=0;
static uint32_t cWMs,cBMs,cLTk;static bool cClk=false;
static bool cPP=false;static int cPR,cPC;static bool cChk=false;static int cKR=-1,cKC=-1;
static int8_t cWCap[16],cBCap[16];static int cWCC=0,cBCC=0;
static bool cDt[8][8],cFull=true;static char cSt[64]="";static int cRes=0;static bool cRW=false;static bool cPromoUI=false;
static lgfx::LGFX_Sprite*cFlipSpr=nullptr;static lgfx::LGFX_Sprite*cTopSpr2=nullptr;
#define CPT(p) ((p)&7)
#define CIW(p) ((p)&8)
#define CIB(p) ((p)&16)
static bool cOB(int r,int c){return r>=0&&r<8&&c>=0&&c<8;}
static bool cIsE(int r,int c,bool w){if(!cOB(r,c)||!cb[r][c])return false;return w?CIB(cb[r][c]):CIW(cb[r][c]);}
static bool cEm(int r,int c){return cOB(r,c)&&!cb[r][c];}
static uint32_t cHash(){uint32_t h=0;for(int i=0;i<64;i++)h=h*31+(uint32_t)(cb[i/8][i%8]+1);h=h*31+(cwKM?1:0)+(cbKM?2:0)+(cwRA?4:0)+(cwRH?8:0)+(cbRA?16:0)+(cbRH?32:0);h=h*31+(uint32_t)(cEP+2);h=h*31+(cWT?1:0);return h;}
static int cPCt(uint32_t hh){int c=0;for(int i=0;i<cPN;i++)if(cPH[i]==hh)c++;return c;}
void chess_initBoard(){memset(cb,0,64);int8_t bk[]={4,2,3,5,6,3,2,4};for(int c=0;c<8;c++){cb[0][c]=bk[c]|16;cb[1][c]=1|16;cb[6][c]=1|8;cb[7][c]=bk[c]|8;}
  cWT=true;cGO=false;cPS=false;cVC=0;cEP=-1;cHMC=0;cPN=0;cwKM=cbKM=cwRA=cwRH=cbRA=cbRH=false;cPP=false;cRes=0;cChk=false;cKR=cKC=-1;cWCC=cBCC=0;cPromoUI=false;strcpy(cSt,"White's Turn");if(cPN<600)cPH[cPN++]=cHash();memset(cDt,1,64);cFull=true;}
// Attack
static bool cSA(int r,int c,bool bW,int8_t b[8][8]){int d=bW?-1:1;int ap=bW?(1|8):(1|16);int pr=r-d;for(int dc:{-1,1})if(cOB(pr,c+dc)&&b[pr][c+dc]==ap)return true;
  int km[8][2]={{-2,-1},{-2,1},{-1,-2},{-1,2},{1,-2},{1,2},{2,-1},{2,1}};for(auto&m:km){int nr=r+m[0],nc=c+m[1];if(cOB(nr,nc)){int p=b[nr][nc];if(CPT(p)==2&&(bW?CIW(p):CIB(p)))return true;}}
  int rd[4][2]={{0,1},{0,-1},{1,0},{-1,0}};for(auto&dd:rd)for(int i=1;i<8;i++){int nr=r+dd[0]*i,nc=c+dd[1]*i;if(!cOB(nr,nc))break;int p=b[nr][nc];if(p){if((bW?CIW(p):CIB(p))&&(CPT(p)==4||CPT(p)==5))return true;break;}}
  int bd[4][2]={{1,1},{1,-1},{-1,1},{-1,-1}};for(auto&dd:bd)for(int i=1;i<8;i++){int nr=r+dd[0]*i,nc=c+dd[1]*i;if(!cOB(nr,nc))break;int p=b[nr][nc];if(p){if((bW?CIW(p):CIB(p))&&(CPT(p)==3||CPT(p)==5))return true;break;}}
  for(int dr=-1;dr<=1;dr++)for(int dc=-1;dc<=1;dc++){if(!dr&&!dc)continue;int nr=r+dr,nc=c+dc;if(cOB(nr,nc)){int p=b[nr][nc];if(CPT(p)==6&&(bW?CIW(p):CIB(p)))return true;}}return false;}
static bool cIC(bool w,int8_t b[8][8]){int kp=w?(6|8):(6|16);for(int r=0;r<8;r++)for(int c=0;c<8;c++)if(b[r][c]==kp)return cSA(r,c,!w,b);return true;}
static bool cMC(int fr,int fc,int tr,int tc,bool w){int8_t t[8][8];memcpy(t,cb,64);t[tr][tc]=t[fr][fc];t[fr][fc]=0;if(CPT(cb[fr][fc])==1&&fc!=tc&&!cb[tr][tc])t[fr][tc]=0;return cIC(w,t);}
static int cGVM(int r,int c,int mv[][2]){int n=0;int p=cb[r][c];if(!p)return 0;bool w=CIW(p);int ty=CPT(p);
  auto ad=[&](int tr,int tc){if(!cOB(tr,tc))return;if(cb[tr][tc]&&(w?CIW(cb[tr][tc]):CIB(cb[tr][tc])))return;if(!cMC(r,c,tr,tc,w)){mv[n][0]=tr;mv[n][1]=tc;n++;}};
  if(ty==1){int dr=w?-1:1;int sr=w?6:1;if(cEm(r+dr,c)){ad(r+dr,c);if(r==sr&&cEm(r+2*dr,c))ad(r+2*dr,c);}for(int dc:{-1,1})if(cOB(r+dr,c+dc)){if(cIsE(r+dr,c+dc,w))ad(r+dr,c+dc);if(cEP==c+dc&&r==(w?3:4))if(!cMC(r,c,r+dr,c+dc,w)){mv[n][0]=r+dr;mv[n][1]=c+dc;n++;}}}
  else if(ty==2){int km[8][2]={{-2,-1},{-2,1},{-1,-2},{-1,2},{1,-2},{1,2},{2,-1},{2,1}};for(auto&m:km)ad(r+m[0],c+m[1]);}
  else if(ty>=3&&ty<=5){int ds[8][2]={{1,1},{1,-1},{-1,1},{-1,-1},{0,1},{0,-1},{1,0},{-1,0}};int s=(ty==3)?0:(ty==4)?4:0,e=(ty==3)?4:(ty==4)?8:8;for(int d=s;d<e;d++)for(int i=1;i<8;i++){int nr=r+ds[d][0]*i,nc=c+ds[d][1]*i;if(!cOB(nr,nc))break;ad(nr,nc);if(cb[nr][nc])break;}}
  else if(ty==6){for(int dr=-1;dr<=1;dr++)for(int dc=-1;dc<=1;dc++)if(dr||dc)ad(r+dr,c+dc);int8_t t[8][8];memcpy(t,cb,64);
    if(w&&!cwKM&&r==7&&c==4){if(!cwRH&&!cb[7][5]&&!cb[7][6]&&cb[7][7]==(4|8)&&!cSA(7,4,0,t)&&!cSA(7,5,0,t)&&!cSA(7,6,0,t)){mv[n][0]=7;mv[n][1]=6;n++;}if(!cwRA&&!cb[7][3]&&!cb[7][2]&&!cb[7][1]&&cb[7][0]==(4|8)&&!cSA(7,4,0,t)&&!cSA(7,3,0,t)&&!cSA(7,2,0,t)){mv[n][0]=7;mv[n][1]=2;n++;}}
    if(!w&&!cbKM&&r==0&&c==4){if(!cbRH&&!cb[0][5]&&!cb[0][6]&&cb[0][7]==(4|16)&&!cSA(0,4,1,t)&&!cSA(0,5,1,t)&&!cSA(0,6,1,t)){mv[n][0]=0;mv[n][1]=6;n++;}if(!cbRA&&!cb[0][3]&&!cb[0][2]&&!cb[0][1]&&cb[0][0]==(4|16)&&!cSA(0,4,1,t)&&!cSA(0,3,1,t)&&!cSA(0,2,1,t)){mv[n][0]=0;mv[n][1]=2;n++;}}}return n;}
static bool cAny(bool w){for(int r=0;r<8;r++)for(int c=0;c<8;c++){if(!cb[r][c])continue;if(w?!CIW(cb[r][c]):!CIB(cb[r][c]))continue;int mv[64][2];if(cGVM(r,c,mv)>0)return true;}return false;}
static bool cIsVT(int r,int c){for(int i=0;i<cVC;i++)if(cVM[i][0]==r&&cVM[i][1]==c)return true;return false;}
static bool cInsuf(){int wN=0,wB=0,bN=0,bB=0,wBs=-1,bBs=-1,ot=0;for(int r=0;r<8;r++)for(int c=0;c<8;c++){int p=cb[r][c];if(!p)continue;int t=CPT(p);if(t==6)continue;if(t==1||t==4||t==5){ot++;continue;}if(CIW(p)){if(t==2)wN++;if(t==3){wB++;wBs=(r+c)%2;}}else{if(t==2)bN++;if(t==3){bB++;bBs=(r+c)%2;}}}if(ot)return false;int tot=wN+wB+bN+bB;if(!tot)return true;if(tot==1)return true;if(tot==2&&wB==1&&bB==1&&wBs==bBs)return true;return false;}
static void cUpdChk(){int8_t t[8][8];memcpy(t,cb,64);cChk=cIC(cWT,t);cKR=cKC=-1;if(cChk){int kp=cWT?(6|8):(6|16);for(int r=0;r<8;r++)for(int c=0;c<8;c++)if(cb[r][c]==kp){cKR=r;cKC=c;return;}}}
static void cCheckEnd(){cUpdChk();bool hm=cAny(cWT);if(!hm){cGO=true;cClk=false;if(cChk){cRes=1;cRW=!cWT;snprintf(cSt,64,"%s wins!",cWT?"Black":"White");}else{cRes=2;strcpy(cSt,"Stalemate!");}return;}
  if(cHMC>=100){cGO=true;cRes=3;strcpy(cSt,"50-Move Draw!");cClk=false;return;}uint32_t ch=cPH[cPN-1];if(cPCt(ch)>=3){cGO=true;cRes=4;strcpy(cSt,"Threefold Draw!");cClk=false;return;}if(cInsuf()){cGO=true;cRes=5;strcpy(cSt,"Draw!");cClk=false;return;}
  if(cChk)snprintf(cSt,64,"%s CHECK!",cWT?"White":"Black");else snprintf(cSt,64,"%s's Turn",cWT?"White":"Black");}
static void cDoMove(int fr,int fc,int tr,int tc){int p=cb[fr][fc];bool w=CIW(p);int ty=CPT(p);bool cap=cb[tr][tc]!=0;
  if(cap){if(w)cWCap[cWCC++]=cb[tr][tc];else cBCap[cBCC++]=cb[tr][tc];}int ne=-1;
  if(ty==1){if(abs(tr-fr)==2)ne=tc;if(fc!=tc&&!cb[tr][tc]){if(w)cWCap[cWCC++]=cb[fr][tc];else cBCap[cBCC++]=cb[fr][tc];cb[fr][tc]=0;cap=true;cDt[fr][tc]=true;}}cEP=ne;
  if(ty==6){if(w)cwKM=true;else cbKM=true;if(tc-fc==2){cb[fr][fc+1]=cb[fr][7];cb[fr][7]=0;cDt[fr][5]=cDt[fr][7]=true;}if(fc-tc==2){cb[fr][fc-1]=cb[fr][0];cb[fr][0]=0;cDt[fr][3]=cDt[fr][0]=true;}}
  if(ty==4){if(fr==7&&fc==0)cwRA=true;if(fr==7&&fc==7)cwRH=true;if(fr==0&&fc==0)cbRA=true;if(fr==0&&fc==7)cbRH=true;}
  if(tr==7&&tc==7)cwRH=true;if(tr==7&&tc==0)cwRA=true;if(tr==0&&tc==7)cbRH=true;if(tr==0&&tc==0)cbRA=true;
  cb[tr][tc]=cb[fr][fc];cb[fr][fc]=0;cDt[fr][fc]=cDt[tr][tc]=true;
  if(ty==1&&(tr==0||tr==7)){cPP=true;cPR=tr;cPC=tc;cPromoUI=true;return;}
  if(cap||ty==1)cHMC=0;else cHMC++;cWT=!cWT;if(cPN<600)cPH[cPN++]=cHash();cCheckEnd();}
static void cFinPromo(int pc){bool w=CIW(cb[cPR][cPC]);cb[cPR][cPC]=pc|(w?8:16);cPP=false;cPromoUI=false;cHMC=0;cWT=!cWT;if(cPN<600)cPH[cPN++]=cHash();cCheckEnd();memset(cDt,1,64);cFull=true;}
// Piece drawing
static void cDP(lgfx::LovyanGFX*g,int x,int y,int piece){if(!piece)return;int hf=CC/2-5;bool w=CIW(piece);int ty=CPT(piece);uint32_t mc=w?0xFAFAFA:0x111111,oc=w?0x666666:0xAAAAAA;
  switch(ty){case 1:g->fillCircle(x,y-hf+7,7,mc);g->drawCircle(x,y-hf+7,7,oc);g->fillRoundRect(x-9,y-hf+16,18,hf*2-16,3,mc);g->drawRoundRect(x-9,y-hf+16,18,hf*2-16,3,oc);break;
    case 4:g->fillRect(x-hf,y-hf,hf*2,8,mc);g->drawRect(x-hf,y-hf,hf*2,8,oc);g->fillRect(x-hf+2,y-hf-6,6,8,mc);g->drawRect(x-hf+2,y-hf-6,6,8,oc);g->fillRect(x-3,y-hf-6,6,8,mc);g->drawRect(x-3,y-hf-6,6,8,oc);g->fillRect(x+hf-8,y-hf-6,6,8,mc);g->drawRect(x+hf-8,y-hf-6,6,8,oc);g->fillRoundRect(x-9,y-hf+8,18,hf*2-8,2,mc);g->drawRoundRect(x-9,y-hf+8,18,hf*2-8,2,oc);break;
    case 2:g->fillRoundRect(x-10,y-hf+10,20,hf*2-10,3,mc);g->drawRoundRect(x-10,y-hf+10,20,hf*2-10,3,oc);g->fillRoundRect(x-8,y-hf-6,10,18,2,mc);g->drawRoundRect(x-8,y-hf-6,10,18,2,oc);g->fillRoundRect(x-8,y-hf+4,20,10,2,mc);g->drawRoundRect(x-8,y-hf+4,20,10,2,oc);g->fillCircle(x-1,y-hf,2,w?0x333333:TX);break;
    case 3:g->fillRect(x-2,y-hf-4,5,6,mc);g->drawRect(x-2,y-hf-4,5,6,oc);g->fillRect(x-5,y-hf+1,11,5,mc);g->drawRect(x-5,y-hf+1,11,5,oc);g->fillRect(x-8,y-hf+5,17,6,mc);g->drawRect(x-8,y-hf+5,17,6,oc);g->fillRoundRect(x-8,y-hf+12,16,hf*2-10,3,mc);g->drawRoundRect(x-8,y-hf+12,16,hf*2-10,3,oc);g->fillRect(x-1,y-hf+14,2,10,oc);break;
    case 5:g->fillRoundRect(x-hf,y-8,hf*2,8+hf,3,mc);g->drawRoundRect(x-hf,y-8,hf*2,8+hf,3,oc);g->fillCircle(x-hf+4,y-hf+4,4,mc);g->drawCircle(x-hf+4,y-hf+4,4,oc);g->fillCircle(x,y-hf,4,mc);g->drawCircle(x,y-hf,4,oc);g->fillCircle(x+hf-4,y-hf+4,4,mc);g->drawCircle(x+hf-4,y-hf+4,4,oc);break;
    case 6:g->fillRoundRect(x-10,y-hf+8,20,hf*2-6,3,mc);g->drawRoundRect(x-10,y-hf+8,20,hf*2-6,3,oc);g->fillRoundRect(x-hf,y-hf+4,hf*2,8,2,mc);g->drawRoundRect(x-hf,y-hf+4,hf*2,8,2,oc);g->fillRect(x-2,y-hf-8,4,14,oc);g->fillRect(x-6,y-hf-4,12,4,oc);break;}}
static void cDrawSq(int r,int c){int x=c*CC,y=r*CC;uint32_t bg;
  if(!cGO&&cChk&&r==cKR&&c==cKC)bg=0xEF5350;else if(cPS&&r==cSR&&c==cSC)bg=0x66BB6A;else if(cPS&&cIsVT(r,c))bg=0x4CAF50;else bg=((r+c)%2==0)?0xF0D9B5:0xB58863;
  lcd.fillRect(x,y,CC,CC,bg);int piece=cb[r][c];if(!piece)return;
  if(CIB(piece)){if(!cFlipSpr){cFlipSpr=new lgfx::LGFX_Sprite(&lcd);cFlipSpr->setColorDepth(16);cFlipSpr->createSprite(CC,CC);}
    cFlipSpr->fillSprite(bg);cDP(cFlipSpr,CC/2,CC/2,piece);cFlipSpr->setPivot(CC/2,CC/2);cFlipSpr->pushRotateZoom(x+CC/2,y+CC/2,180,1.0,1.0);}
  else cDP(&lcd,x+CC/2,y+CC/2,piece);}
static void cDrawBoard(){lcd.startWrite();for(int r=0;r<8;r++)for(int c=0;c<8;c++){if(!cFull&&!cDt[r][c])continue;cDrawSq(r,c);}
  if(cFull){lcd.setTextColor(0x999999);lcd.setFont(&fonts::Font2);const char f[]="abcdefgh";const char rk[]="87654321";for(int i=0;i<8;i++){char s[2]={f[i],0};lcd.drawString(s,i*CC+CC-12,BRD-16);char s2[2]={rk[i],0};lcd.drawString(s2,2,i*CC+2);}}
  lcd.endWrite();memset(cDt,0,64);cFull=false;}
// Captured: K for Knight (user request), P,K,B,R,Q,K
static void cCapStr(char*buf,int8_t*caps,int cnt){const char sy[]=" PKBRQK";int bi=0;for(int i=0;i<cnt&&i<15;i++)buf[bi++]=sy[CPT(caps[i])];buf[bi]=0;}
// Panels
static void cDrawTopPanel(){
  if(!cTopSpr2){cTopSpr2=new lgfx::LGFX_Sprite(&lcd);cTopSpr2->setColorDepth(16);cTopSpr2->createSprite(PW,200);}
  lgfx::LGFX_Sprite*s=cTopSpr2;bool act=!cWT&&!cGO;
  uint32_t bg;
  if(cGO)bg=(cRes==1&&!cRW)?0xF9A825:0x616161;
  else if(cChk&&!cWT)bg=0xB71C1C;
  else bg=act?0x333333:0x87CEEB; // dark=black piece color, sky blue=inactive
  s->fillSprite(bg);
  s->setFont(&fonts::FreeSansBold12pt7b);s->setTextColor(TX);s->drawString(act?"Black's turn":"BLACK",15,15);
  char buf[16];fmtTime(cBMs,buf);s->setFont(&fonts::FreeSansBold18pt7b);s->setTextColor(TX);s->drawString(buf,180,10);
  char cb2[20];cCapStr(cb2,cBCap,cBCC);s->setFont(&fonts::FreeSans9pt7b);s->setTextColor(0xCCCCCC);s->drawString("Captured:",15,55);s->drawString(cb2,15,78);
  if(cGO){s->setFont(&fonts::FreeSansBold12pt7b);s->drawString(cSt,15,160);}else if(cChk&&!cWT){s->setFont(&fonts::FreeSansBold12pt7b);s->drawString("CHECK!",120,160);}
  s->setPivot(PW/2,100);s->pushRotateZoom(PX+PW/2,100,180,1.0,1.0);}
static void cDrawBotPanel(){bool act=cWT&&!cGO;uint32_t bg2;
  if(cGO)bg2=(cRes==1&&cRW)?0xF9A825:0x616161;
  else if(cChk&&cWT)bg2=0xB71C1C;
  else bg2=act?0xEEEEEE:0x87CEEB; // white=piece color, sky blue=inactive
  lcd.fillRect(PX,280,PW,200,bg2);
  lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(0x111111);lcd.drawString(act?"White's turn":"WHITE",PX+15,435);
  char buf[16];fmtTime(cWMs,buf);lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(0x111111);lcd.drawString(buf,PX+180,430);
  char cb2[20];cCapStr(cb2,cWCap,cWCC);lcd.setFont(&fonts::FreeSans9pt7b);lcd.setTextColor(0x444444);lcd.drawString("Captured:",PX+15,385);lcd.drawString(cb2,PX+15,405);
  if(cGO){lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(0x111111);lcd.drawString(cSt,PX+15,295);}else if(cChk&&cWT){lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(0xCC0000);lcd.drawString("CHECK!",PX+120,295);}}
static void cDrawMidPanel(){lcd.fillRect(PX,200,PW,80,BGC);drawNGBtn(PX,200,PW,80);}
static void cDrawPanels(){cDrawTopPanel();cDrawMidPanel();cDrawBotPanel();}
static void cDrawPromo(){lcd.fillRect(100,180,280,120,0x2C3E50);lcd.drawRect(100,180,280,120,TX);lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);lcd.drawString("Promote:",150,192);
  const char*nm[]={"Q","R","B","K"};for(int i=0;i<4;i++){lcd.fillRoundRect(112+i*66,230,58,50,6,PGN);lcd.drawRoundRect(112+i*66,230,58,50,6,0x4CAF50);lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(TX);lcd.drawString(nm[i],128+i*66,240);}}
void chess_drawOpt(){lcd.fillScreen(BGC);lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(0xE2B96F);lcd.drawCenterString("CHESS",400,30);lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);lcd.drawCenterString("Select Time",400,80);
  const char*lb[]={"5 min","10 min","15 min","20 min","30 min"};for(int i=0;i<5;i++){int bx=25+i*155,by=150;lcd.fillRoundRect(bx,by,140,70,12,PGN);lcd.drawRoundRect(bx,by,140,70,12,0x4CAF50);lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);lcd.drawCenterString(lb[i],bx+70,by+22);}}
void chess_handleOpt(int16_t tx,int16_t ty){int tms[]={5,10,15,20,30};for(int i=0;i<5;i++){int bx=25+i*155,by=150;if(tx>=bx&&tx<bx+140&&ty>=by&&ty<by+70){
  chess_initBoard();cWMs=cBMs=(uint32_t)tms[i]*60000;cClk=true;
  cLTk=millis();appState=2;lcd.fillScreen(BGC);cDrawBoard();cDrawPanels();return;}}}
void chess_loop(){int16_t tx,ty;
  if(cPromoUI){if(tOnce(&tx,&ty)){int pcs[]={5,4,3,2};for(int i=0;i<4;i++)if(tx>=112+i*66&&tx<170+i*66&&ty>=230&&ty<280){cFinPromo(pcs[i]);cDrawBoard();cDrawPanels();return;}}delay(5);return;}
  int16_t rx,ry;bool tch=tRaw(&rx,&ry);if(doNG(PX,200,PW,80,rx,ry,tch))return;
  if(!ngH&&tOnce(&tx,&ty)&&tx<BRD&&ty<BRD&&!cGO&&!cPP){int col=tx/CC,row=ty/CC;if(!cOB(row,col))goto ctmr;
    if(cPS){cDt[cSR][cSC]=true;for(int i=0;i<cVC;i++)cDt[cVM[i][0]][cVM[i][1]]=true;}int tp=cb[row][col];bool own=(tp&&(cWT?CIW(tp):CIB(tp)));
    if(!cPS){if(own){cSR=row;cSC=col;cPS=true;cVC=cGVM(row,col,cVM);cDt[row][col]=true;for(int i=0;i<cVC;i++)cDt[cVM[i][0]][cVM[i][1]]=true;}}
    else{if(row==cSR&&col==cSC){cPS=false;cVC=0;}else if(own){cSR=row;cSC=col;cVC=cGVM(row,col,cVM);cDt[row][col]=true;for(int i=0;i<cVC;i++)cDt[cVM[i][0]][cVM[i][1]]=true;}
      else if(cIsVT(row,col)){cDt[cSR][cSC]=cDt[row][col]=true;if(CPT(cb[cSR][cSC])==6&&abs(col-cSC)==2){if(col>cSC){cDt[cSR][5]=cDt[cSR][7]=true;}else{cDt[cSR][0]=cDt[cSR][3]=true;}}
        if(CPT(cb[cSR][cSC])==1&&cSC!=col&&!cb[row][col])cDt[cSR][col]=true;cDoMove(cSR,cSC,row,col);cPS=false;cVC=0;}else{cPS=false;cVC=0;}}
    cDrawBoard();cDrawPanels();if(cPromoUI)cDrawPromo();}
  ctmr:if(cClk&&!cGO&&!cPP){uint32_t now=millis(),dt=now-cLTk;cLTk=now;
    if(cWT){if(cWMs<=dt){cWMs=0;cGO=true;cRes=6;cRW=false;strcpy(cSt,"Black wins on time!");cClk=false;cDrawPanels();}else cWMs-=dt;}
    else{if(cBMs<=dt){cBMs=0;cGO=true;cRes=6;cRW=true;strcpy(cSt,"White wins on time!");cClk=false;cDrawPanels();}else cBMs-=dt;}
    static uint32_t ctu=0;if(now-ctu>100){ctu=now;cDrawTopPanel();
      uint32_t tbg=(cWT&&!cGO)?(cChk?0xB71C1C:0xEEEEEE):0x87CEEB;
      lcd.fillRect(PX+170,425,140,40,tbg);char buf[16];fmtTime(cWMs,buf);lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(0x111111);lcd.drawString(buf,PX+180,430);}}}

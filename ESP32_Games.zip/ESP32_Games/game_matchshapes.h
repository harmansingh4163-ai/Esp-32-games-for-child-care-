#pragma once
// ===== Match Shapes =====
// 15 distinct shape types. Each round picks 1 match shape; player 1 grid =
// match + 7 unique others; player 2 grid = match + 7 unique others; the two sets
// of "others" are disjoint, so EXACTLY ONE shape appears in both grids.
// Wrong tap = opponent scores. No "too slow" message.

#define MS_NSHAPES 15
static int msRoundsTotal=10;
static int msRound=0;
static int msScore[2]={0,0};
static int msMatchShape=-1;
static int msGrid[2][8];
static bool msGO=false;
static char msSt[64]="";
static bool msShowing=false;
static uint32_t msShowT=0;
static int msWinner=-1;
static bool msNGH=false;
static uint32_t msNGStart=0;

// ===== Shape primitives =====
static void msShapeAt(int cx,int cy,int sz,int type,uint32_t cl,bool rot){
  switch(type){
    case 0: lcd.fillCircle(cx,cy,sz,cl); break;
    case 1: lcd.fillRect(cx-sz,cy-sz,sz*2,sz*2,cl); break;
    case 2:
      if(rot) lcd.fillTriangle(cx,cy+sz,cx-sz,cy-sz,cx+sz,cy-sz,cl);
      else    lcd.fillTriangle(cx,cy-sz,cx-sz,cy+sz,cx+sz,cy+sz,cl);
      break;
    case 3: { // 5-point star
      int x[10],y[10];
      for(int i=0;i<10;i++){
        float a=-PI/2+i*PI/5;
        if(rot)a+=PI;
        int r=(i%2==0)?sz:sz/2;
        x[i]=cx+cos(a)*r;y[i]=cy+sin(a)*r;}
      for(int i=0;i<10;i++){int n=(i+1)%10;lcd.fillTriangle(cx,cy,x[i],y[i],x[n],y[n],cl);}
      break;
    }
    case 4: { // heart
      int r=sz*3/4;
      if(rot){
        lcd.fillCircle(cx-r/2,cy+r/4,r,cl);
        lcd.fillCircle(cx+r/2,cy+r/4,r,cl);
        lcd.fillTriangle(cx-r,cy+1,cx+r,cy+1,cx,cy-sz,cl);
      } else {
        lcd.fillCircle(cx-r/2,cy-r/4,r,cl);
        lcd.fillCircle(cx+r/2,cy-r/4,r,cl);
        lcd.fillTriangle(cx-r,cy-1,cx+r,cy-1,cx,cy+sz,cl);
      }
      break;
    }
    case 5: // diamond
      lcd.fillTriangle(cx,cy-sz,cx-sz,cy,cx+sz,cy,cl);
      lcd.fillTriangle(cx,cy+sz,cx-sz,cy,cx+sz,cy,cl);
      break;
    case 6: { // hexagon
      int px[6],py[6];
      for(int i=0;i<6;i++){float a=i*PI/3;px[i]=cx+cos(a)*sz;py[i]=cy+sin(a)*sz;}
      for(int i=1;i<5;i++)lcd.fillTriangle(px[0],py[0],px[i],py[i],px[i+1],py[i+1],cl);
      break;
    }
    case 7: { // pentagon
      int px[5],py[5];
      for(int i=0;i<5;i++){
        float a=-PI/2+i*2*PI/5;
        if(rot)a+=PI;
        px[i]=cx+cos(a)*sz;py[i]=cy+sin(a)*sz;}
      for(int i=1;i<4;i++)lcd.fillTriangle(px[0],py[0],px[i],py[i],px[i+1],py[i+1],cl);
      break;
    }
    case 8:
      lcd.fillRect(cx-sz,cy-sz/3,sz*2,(sz*2)/3,cl);
      lcd.fillRect(cx-sz/3,cy-sz,(sz*2)/3,sz*2,cl);
      break;
    case 9: // moon
      lcd.fillCircle(cx,cy,sz,cl);
      if(rot) lcd.fillCircle(cx-sz/3,cy+sz/4,sz-2,0xFFFFFF);
      else    lcd.fillCircle(cx+sz/3,cy-sz/4,sz-2,0xFFFFFF);
      break;
    case 10: // 4-point star
      lcd.fillTriangle(cx,cy-sz,cx-sz/3,cy,cx+sz/3,cy,cl);
      lcd.fillTriangle(cx,cy+sz,cx-sz/3,cy,cx+sz/3,cy,cl);
      lcd.fillTriangle(cx-sz,cy,cx,cy-sz/3,cx,cy+sz/3,cl);
      lcd.fillTriangle(cx+sz,cy,cx,cy-sz/3,cx,cy+sz/3,cl);
      break;
    case 11: // ring
      lcd.fillCircle(cx,cy,sz,cl);
      lcd.fillCircle(cx,cy,sz/2,0xFFFFFF);
      break;
    case 12: // arrow
      if(rot){
        lcd.fillTriangle(cx,cy+sz,cx-sz,cy,cx+sz,cy,cl);
        lcd.fillRect(cx-sz/3,cy-sz,sz*2/3,sz,cl);
      } else {
        lcd.fillTriangle(cx,cy-sz,cx-sz,cy,cx+sz,cy,cl);
        lcd.fillRect(cx-sz/3,cy,sz*2/3,sz,cl);
      }
      break;
    case 13: { // lightning
      int px[6],py[6];
      if(rot){
        px[0]=cx+sz/3;py[0]=cy+sz;
        px[1]=cx-sz/3;py[1]=cy+sz/4;
        px[2]=cx+sz/8;py[2]=cy+sz/4;
        px[3]=cx-sz/3;py[3]=cy-sz/4;
        px[4]=cx+sz/3;py[4]=cy-sz;
        px[5]=cx-sz/8;py[5]=cy-sz/4;
      } else {
        px[0]=cx-sz/3;py[0]=cy-sz;
        px[1]=cx+sz/3;py[1]=cy-sz/4;
        px[2]=cx-sz/8;py[2]=cy-sz/4;
        px[3]=cx+sz/3;py[3]=cy+sz/4;
        px[4]=cx-sz/3;py[4]=cy+sz;
        px[5]=cx+sz/8;py[5]=cy+sz/4;
      }
      lcd.fillTriangle(px[0],py[0],px[1],py[1],px[2],py[2],cl);
      lcd.fillTriangle(px[2],py[2],px[1],py[1],px[3],py[3],cl);
      lcd.fillTriangle(px[2],py[2],px[3],py[3],px[4],py[4],cl);
      lcd.fillTriangle(px[4],py[4],px[3],py[3],px[5],py[5],cl);
      break;
    }
    case 14: { // 15th shape: octagon (symmetric)
      int px[8],py[8];
      for(int i=0;i<8;i++){float a=i*PI/4;px[i]=cx+cos(a)*sz;py[i]=cy+sin(a)*sz;}
      for(int i=1;i<7;i++)lcd.fillTriangle(px[0],py[0],px[i],py[i],px[i+1],py[i+1],cl);
      break;
    }
  }
}
static uint32_t msShapeColor(int i){
  uint32_t arr[]={SRED,SBLU,SGRN,SYLW,SPRP,SORG,STEA,SPNK,SCOR,GOLD,DANGER,SBLU,SGRN,GOLD,STEA};
  return arr[i%MS_NSHAPES];
}

// ===== Layout =====
#define MS_HW 800
#define MS_HH 220

// Cell layout in player-local coords. Local y origin = top of that player's
// view (closest to that player's hand). Header is at top, cells below.
// Header band: 0..40, cells start at y=45.
static void msCellLocal(int idx,int*lx,int*ly,int*lw,int*lh){
  int col=idx%4,row=idx/4;
  *lw=175;*lh=78;
  *lx=20+col*195;
  *ly=50+row*88;
}
// Screen->local mapping
//   p=0 (Player 1, bottom): screen y 260..480 corresponds to local y 0..220
//     local (lx,ly) -> screen (lx, ly+260)
//   p=1 (Player 2, top, rotated 180): local (lx,ly) -> screen
//     screen_x = MS_HW-1 - (lx + lw - 1)  (top-left of cell after rotation)
//     screen_y = MS_HH-1 - (ly + lh - 1)
static void msCellScreen(int p,int idx,int*sx,int*sy,int*sw,int*sh){
  int lx,ly,lw,lh;msCellLocal(idx,&lx,&ly,&lw,&lh);
  *sw=lw;*sh=lh;
  if(p==0){
    *sx=lx;*sy=ly+260;
  } else {
    *sx=MS_HW-1-(lx+lw-1);
    *sy=MS_HH-1-(ly+lh-1);
  }
}

static void msDrawPlayerHalf(int p){
  bool rot=(p==1);
  // Both halves use BGC for clean consistent look; differentiation via header strip
  int yoff=(p==0)?260:0;
  lcd.fillRect(0,yoff,MS_HW,MS_HH,BGC);
  // Header strip with player's color
  uint32_t hdrCl=(p==0)?SBLU:SPRP;
  if(p==0){
    // Player 1 bottom: header strip at top of bottom half
    lcd.fillRect(0,yoff,MS_HW,38,hdrCl);
  } else {
    // Player 2 top: header strip at bottom of top half (visually top from P2's POV)
    lcd.fillRect(0,yoff+MS_HH-38,MS_HW,38,hdrCl);
  }

  char pl[40];sprintf(pl,"P%d   Score: %d",p+1,msScore[p]);
  char rb[20];sprintf(rb,"Round %d/%d",msRound,msRoundsTotal);
  lcd.setFont(&fonts::FreeSansBold18pt7b);
  lcd.setTextColor(TX);
  if(p==0){
    lcd.drawString(pl,20,yoff+5);
    lcd.setFont(&fonts::FreeSansBold12pt7b);
    lcd.setTextColor(GOLD);
    lcd.drawString(rb,MS_HW-170,yoff+10);
    if(msShowing && msWinner==p){
      lcd.setFont(&fonts::FreeSansBold18pt7b);
      lcd.setTextColor(GOLD);
      lcd.drawCenterString("YOU WIN!",MS_HW/2,yoff+5);
    }
  } else {
    int hy=yoff+MS_HH-30;
    lcd.drawString(pl,20,hy);
    lcd.setFont(&fonts::FreeSansBold12pt7b);
    lcd.setTextColor(GOLD);
    lcd.drawString(rb,MS_HW-170,hy+5);
    if(msShowing && msWinner==p){
      lcd.setFont(&fonts::FreeSansBold18pt7b);
      lcd.setTextColor(GOLD);
      lcd.drawCenterString("YOU WIN!",MS_HW/2,hy);
    }
  }

  // Draw 8 cells
  for(int i=0;i<8;i++){
    int sx,sy,sw,sh;msCellScreen(p,i,&sx,&sy,&sw,&sh);
    int sh_idx=msGrid[p][i];
    bool isMatch=(msShowing && sh_idx==msMatchShape);
    if(isMatch){
      lcd.fillRoundRect(sx,sy,sw,sh,10,GOLD);
      lcd.drawRoundRect(sx,sy,sw,sh,10,SGRN);
      lcd.drawRoundRect(sx+1,sy+1,sw-2,sh-2,9,SGRN);
    } else {
      lcd.fillRoundRect(sx,sy,sw,sh,10,0xFFFFFF);
      lcd.drawRoundRect(sx,sy,sw,sh,10,SPRP);
    }
    msShapeAt(sx+sw/2,sy+sh/2,26,sh_idx,msShapeColor(sh_idx),rot);
  }
}
static void msRenderMiddle(){
  lcd.fillRect(0,220,800,40,BGC);
  // Smaller button to leave room for label
  int bw=280,bh=32;
  int bx=(800-bw)/2,by=224;
  lcd.fillRoundRect(bx,by,bw,bh,10,SURF2);
  lcd.drawRoundRect(bx,by,bw,bh,10,BORD);
  // Text and progress bar layout:
  //   Text "HOLD 3s: NEW GAME" centered, with progress bar BELOW it (small)
  lcd.setFont(&fonts::FreeSansBold9pt7b);lcd.setTextColor(TX);
  lcd.drawCenterString("HOLD 3s: NEW GAME",bx+bw/2,by+5);
  // Progress bar at bottom of button - kept narrow and visually contained
  int pbx=bx+60,pby=by+bh-9,pbw=bw-120,pbh=5;
  lcd.fillRoundRect(pbx,pby,pbw,pbh,2,BORD);
}
void msDrawAll(){
  msNGH=false; // reset hold state on any full redraw
  lcd.fillScreen(BGC);
  msDrawPlayerHalf(1);
  msDrawPlayerHalf(0);
  msRenderMiddle();
}

// ===== Game logic =====
// 15 distinct shapes. Pick a match, then split the remaining 14 into 2 groups of 7
// for the two players. Each player's grid = match + their 7 others.
static void msNewRound(){
  msMatchShape=random(0,MS_NSHAPES);
  int pool[MS_NSHAPES];int pc=0;
  for(int i=0;i<MS_NSHAPES;i++)if(i!=msMatchShape)pool[pc++]=i;
  // Shuffle the pool (14 items)
  for(int i=pc-1;i>0;i--){int j=random(0,i+1);int t=pool[i];pool[i]=pool[j];pool[j]=t;}
  // First 7 go to player 0, next 7 to player 1
  for(int i=0;i<7;i++)msGrid[0][i]=pool[i];
  msGrid[0][7]=msMatchShape;
  for(int i=0;i<7;i++)msGrid[1][i]=pool[7+i];
  msGrid[1][7]=msMatchShape;
  // Shuffle each grid so match position is random
  for(int p=0;p<2;p++)
    for(int i=7;i>0;i--){int j=random(0,i+1);int t=msGrid[p][i];msGrid[p][i]=msGrid[p][j];msGrid[p][j]=t;}
  msShowing=false;msWinner=-1;
}
static void msInit(int rounds){
  randomSeed(millis()); // fresh seed for every new game
  msRoundsTotal=rounds;msRound=1;msScore[0]=msScore[1]=0;msGO=false;
  msShowing=false;msWinner=-1;
  msNewRound();
  sprintf(msSt,"Round 1 of %d",rounds);
}

// ===== Touch =====
static int msHitGrid(int sx,int sy,int*outP){
  if(sy>=260 && sy<480){
    *outP=0;
    for(int i=0;i<8;i++){
      int x,y,w,h;msCellScreen(0,i,&x,&y,&w,&h);
      if(sx>=x&&sx<x+w&&sy>=y&&sy<y+h)return i;
    }
  } else if(sy>=0 && sy<220){
    *outP=1;
    for(int i=0;i<8;i++){
      int x,y,w,h;msCellScreen(1,i,&x,&y,&w,&h);
      if(sx>=x&&sx<x+w&&sy>=y&&sy<y+h)return i;
    }
  }
  return -1;
}

// ===== Options =====
void ms_drawOpt(){
  lcd.fillScreen(BGC);
  lcd.fillRect(0,0,800,50,SURF2);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(TX);
  lcd.drawCenterString("MATCH SHAPES",400,12);
  lcd.fillRoundRect(60,70,680,150,14,0xFFFFFF);
  lcd.drawRoundRect(60,70,680,150,14,BORD);
  lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(SBLU);
  lcd.drawString("How to play",80,85);
  lcd.setFont(&fonts::FreeSans9pt7b);lcd.setTextColor(TXK);
  lcd.drawString("- Sit opposite each other (like chess).",80,120);
  lcd.drawString("- Each player has 8 shapes shown immediately.",80,148);
  lcd.drawString("- EXACTLY ONE shape is the same in both grids.",80,176);
  lcd.drawString("- First to tap it wins. Wrong tap = opponent scores. Next round.",80,200);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(TXK);
  lcd.drawCenterString("Choose number of rounds",400,245);
  int rs[]={10,15,20};
  uint32_t bcl[]={SGRN,SBLU,SPRP};
  for(int i=0;i<3;i++){int bx=140+i*180,by=285;
    lcd.fillRoundRect(bx,by,150,110,14,bcl[i]);
    lcd.drawRoundRect(bx,by,150,110,14,GOLD);
    lcd.drawRoundRect(bx+1,by+1,148,108,13,GOLD);
    lcd.setFont(&fonts::FreeSansBold24pt7b);lcd.setTextColor(TX);
    char s[4];sprintf(s,"%d",rs[i]);
    lcd.drawCenterString(s,bx+75,by+20);
    lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);
    lcd.drawCenterString("rounds",bx+75,by+72);}
}
void ms_handleOpt(int16_t tx,int16_t ty){
  int rs[]={10,15,20};
  for(int i=0;i<3;i++){int bx=140+i*180,by=285;
    if(tx>=bx&&tx<bx+150&&ty>=by&&ty<by+110){
      msInit(rs[i]);appState=2;msDrawAll();return;}}
}

// ===== Loop =====
// Custom new game hold with progress bar inside the middle band, separate from doNG
// because we need a narrower progress bar that doesn't overlap text.
void ms_loop(){
  int16_t tx,ty,rx,ry;bool tch=tRaw(&rx,&ry);
  // Middle band new-game button
  int bw=280,bh=32;
  int bx=(800-bw)/2,by=224;
  // Use the standard doNG, but override the progress bar position visually
  if(ngConf){
    // Confirm dialog handled by main loop
    delay(5);return;
  }
  bool inBtn=(rx>=bx&&rx<bx+bw&&ry>=by&&ry<by+bh);
  if(tch&&inBtn){
    if(!msNGH){msNGH=true;msNGStart=millis();ngH=true;}
    uint32_t el=millis()-msNGStart;int pct=min((int)(el*100/3000),100);
    int pbx=bx+60,pby=by+bh-9,pbw=bw-120,pbh=5;
    lcd.fillRoundRect(pbx,pby,pbw,pbh,2,BORD);
    int w=pct*(pbw-4)/100;
    if(w>0)lcd.fillRoundRect(pbx+2,pby+1,w,pbh-2,2,GOLD);
    if(el>=3000){msNGH=false;ngH=false;ngConf=true;drawConfirm();return;}
    return;
  } else {
    if(msNGH){msNGH=false;ngH=false;
      // Repaint the progress bar empty
      int pbx=bx+60,pby=by+bh-9,pbw=bw-120,pbh=5;
      lcd.fillRoundRect(pbx,pby,pbw,pbh,2,BORD);
    }
  }
  if(msGO){delay(20);return;}
  if(msShowing){
    if(millis()-msShowT>1500){
      msShowing=false;
      if(msRound>=msRoundsTotal){
        msGO=true;
        if(msScore[0]>msScore[1])sprintf(msSt,"P1 WINS  %d-%d",msScore[0],msScore[1]);
        else if(msScore[1]>msScore[0])sprintf(msSt,"P2 WINS  %d-%d",msScore[1],msScore[0]);
        else sprintf(msSt,"DRAW  %d-%d",msScore[0],msScore[1]);
        lcd.fillRoundRect(100,200,600,80,14,GOLD);
        lcd.drawRoundRect(100,200,600,80,14,SBLU);
        lcd.drawRoundRect(101,201,598,78,13,SBLU);
        lcd.setFont(&fonts::FreeSansBold24pt7b);lcd.setTextColor(TXK);
        lcd.drawCenterString(msSt,400,225);
        return;}
      msRound++;
      msNewRound();
      sprintf(msSt,"Round %d of %d",msRound,msRoundsTotal);
      msDrawAll();}
    return;
  }
  if(!msNGH&&tOnce(&tx,&ty)){
    int p=-1;
    int idx=msHitGrid(tx,ty,&p);
    if(idx>=0 && p>=0){
      if(msGrid[p][idx]==msMatchShape){
        msScore[p]++;msWinner=p;
      } else {
        msScore[1-p]++;msWinner=1-p;
      }
      msShowing=true;msShowT=millis();
      msDrawAll();
      return;
    }
  }
}

#define LGFX_USE_V1
#include <Arduino.h>
#include <LovyanGFX.hpp>
#include <lgfx/v1/platforms/esp32s3/Panel_RGB.hpp>
#include <lgfx/v1/platforms/esp32s3/Bus_RGB.hpp>
#include "chess_types.h"
class LGFX:public lgfx::LGFX_Device{public:lgfx::Bus_RGB _bus;lgfx::Panel_RGB _panel;lgfx::Light_PWM _light;lgfx::Touch_GT911 _touch;
LGFX(void){{auto c=_panel.config();c.memory_width=800;c.memory_height=480;c.panel_width=800;c.panel_height=480;c.offset_x=0;c.offset_y=0;_panel.config(c);}
{auto c=_panel.config_detail();c.use_psram=1;_panel.config_detail(c);}
{auto c=_bus.config();c.panel=&_panel;c.pin_d0=GPIO_NUM_14;c.pin_d1=GPIO_NUM_38;c.pin_d2=GPIO_NUM_18;c.pin_d3=GPIO_NUM_17;c.pin_d4=GPIO_NUM_10;c.pin_d5=GPIO_NUM_39;c.pin_d6=GPIO_NUM_0;c.pin_d7=GPIO_NUM_45;c.pin_d8=GPIO_NUM_48;c.pin_d9=GPIO_NUM_47;c.pin_d10=GPIO_NUM_21;c.pin_d11=GPIO_NUM_1;c.pin_d12=GPIO_NUM_2;c.pin_d13=GPIO_NUM_42;c.pin_d14=GPIO_NUM_41;c.pin_d15=GPIO_NUM_40;c.pin_henable=GPIO_NUM_5;c.pin_vsync=GPIO_NUM_3;c.pin_hsync=GPIO_NUM_46;c.pin_pclk=GPIO_NUM_7;c.freq_write=16000000;c.hsync_polarity=0;c.hsync_front_porch=8;c.hsync_pulse_width=4;c.hsync_back_porch=8;c.vsync_polarity=0;c.vsync_front_porch=8;c.vsync_pulse_width=4;c.vsync_back_porch=8;c.pclk_active_neg=1;c.de_idle_high=0;c.pclk_idle_high=0;_bus.config(c);}
{auto c=_light.config();c.pin_bl=GPIO_NUM_2;c.invert=false;_light.config(c);}
{auto c=_touch.config();c.x_min=0;c.x_max=799;c.y_min=0;c.y_max=479;c.pin_int=GPIO_NUM_NC;c.pin_rst=GPIO_NUM_NC;c.i2c_port=0;c.i2c_addr=0x14;c.pin_sda=GPIO_NUM_8;c.pin_scl=GPIO_NUM_9;c.freq=400000;_touch.config(c);}
_panel.setBus(&_bus);_panel.setLight(&_light);_panel.setTouch(&_touch);setPanel(&_panel);}};
LGFX lcd;
int appState=0,curGame=0;
bool prevTch=false;uint32_t lastTchMs=0;
bool tOnce(int16_t*tx,int16_t*ty){uint16_t x,y;bool t=lcd.getTouch(&x,&y);*tx=x;*ty=y;uint32_t n=millis();if(t&&!prevTch&&(n-lastTchMs>200)){prevTch=true;lastTchMs=n;return true;}if(!t)prevTch=false;return false;}
bool tRaw(int16_t*tx,int16_t*ty){uint16_t x,y;bool t=lcd.getTouch(&x,&y);*tx=x;*ty=y;return t;}
void fmtTime(uint32_t ms,char*b){uint32_t s=ms/1000,m=s/60;s%=60;if(m*60+s<10){uint32_t t=(ms%1000)/100;sprintf(b,"%d:%02d.%d",m,s,t);}else sprintf(b,"%d:%02d",m,s);}
// 6-button dice: 1.5s wait, proper shuffle, values HIDDEN until tapped
int diceOff=0;
bool diceWait=false;uint32_t diceWaitStart=0;
bool diceReady=false; // buttons tappable but values hidden
bool testDice=false;
int diceVals[6]; // hidden values on 6 buttons
void startDiceWait(){diceWait=true;diceWaitStart=millis();diceReady=false;}
bool updateDiceWait(){if(!diceWait)return false;if(millis()-diceWaitStart>=1500){
  diceWait=false;
  // Fisher-Yates shuffle of 1-6
  for(int i=0;i<6;i++)diceVals[i]=i+1;
  for(int i=5;i>0;i--){int j=random(0,i+1);int t=diceVals[i];diceVals[i]=diceVals[j];diceVals[j]=t;}
  diceReady=true;return false;}return true;}
void drawNGBtn(int bx,int by,int bw,int bh){lcd.fillRoundRect(bx+5,by+5,bw-10,bh-10,10,0x333333);lcd.drawRoundRect(bx+5,by+5,bw-10,bh-10,10,0x666666);
  lcd.setFont(&fonts::FreeSansBold9pt7b);lcd.setTextColor(0xCCCCCC);lcd.drawCenterString("HOLD 3s: NEW GAME",bx+bw/2-15,by+bh/2-7);lcd.fillRoundRect(bx+bw-60,by+bh/2-5,50,10,4,0x555555);}
void drawMenu();void redrawCurrentGame();
bool ngH=false;uint32_t ngS=0;bool ngConf=false;
void drawConfirm(){lcd.fillRect(150,160,500,170,0x1A1A30);lcd.drawRoundRect(150,160,500,170,12,0xE74C3C);lcd.drawRoundRect(151,161,498,168,11,0xE74C3C);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(TX);lcd.drawCenterString("Return to menu?",400,185);
  lcd.fillRoundRect(220,260,150,55,12,0x27AE60);lcd.drawRoundRect(220,260,150,55,12,0x2ECC71);lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);lcd.drawCenterString("YES",295,275);
  lcd.fillRoundRect(430,260,150,55,12,0xC0392B);lcd.drawRoundRect(430,260,150,55,12,0xE74C3C);lcd.drawCenterString("NO",505,275);}
bool doNG(int bx,int by,int bw,int bh,int16_t rx,int16_t ry,bool tch){
  if(ngConf)return true;bool in=(rx>=bx&&rx<bx+bw&&ry>=by&&ry<by+bh);
  if(tch&&in){if(!ngH){ngH=true;ngS=millis();}uint32_t el=millis()-ngS;int pct=min((int)(el*100/3000),100);
    int px=bx+bw-60,py=by+bh/2-5;lcd.fillRoundRect(px,py,50,10,4,0x555555);int w=pct*44/100;if(w>0)lcd.fillRoundRect(px+3,py+2,w,6,3,0xFF4444);
    if(el>=3000){ngH=false;ngConf=true;drawConfirm();return true;}}else{if(ngH){ngH=false;}}return false;}
bool handleConfirm(int16_t tx,int16_t ty){if(!ngConf)return false;
  if(tx>=220&&tx<370&&ty>=260&&ty<315){ngConf=false;appState=0;drawMenu();return true;}
  if(tx>=430&&tx<580&&ty>=260&&ty<315){ngConf=false;redrawCurrentGame();return true;}return true;}
#include "game_chess.h"
#include "game_checkers.h"
#include "game_fourrow.h"
#include "game_memory.h"
#include "game_ludo.h"
#include "game_snakes.h"
#include "game_tictactoe.h"
#include "game_mathquiz.h"
#include "game_dotsboxes.h"
void redrawCurrentGame(){lcd.fillScreen(BGC);switch(curGame){
  case 1:memset(cDt,1,64);cFull=true;cDrawBoard();cDrawPanels();break;case 2:ckDrawBoard();ckDrawPanels();break;
  case 3:frDrawBoard();frDrawPanels();break;case 4:mmDrawBoard();mmDrawPanels();break;
  case 5:luDrawBoard();luDrawPanels();break;case 6:snDrawBoard();snDrawPanels();break;
  case 7:ttDrawBoard();ttDrawPanels();break;case 8:mqRedraw();break;case 9:dbDrawBoard();dbDrawPanels();break;}}
void drawMenu(){lcd.fillScreen(0x1C1C2E);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(0xE2B96F);lcd.drawCenterString("GAME CENTER",400,8);
  const char*nm[]={"CHESS","CHECKERS","FOUR IN ROW","MEMORY","LUDO","SNAKES","TIC TAC TOE","MATH QUIZ","DOTS & BOXES"};
  uint32_t bg[]={0x2E7D32,0x5E35B1,0xC62828,0x00838F,0xE65100,0x2E7D32,0xAD1457,0x1565C0,0x6A1B9A};
  uint32_t bd[]={0x81C784,0xB39DDB,0xEF9A9A,0x80DEEA,0xFFCC80,0xA5D6A7,0xF48FB1,0x90CAF9,0xCE93D8};
  for(int i=0;i<9;i++){int col=i%3,r=i/3,bx=15+col*262,by=48+r*146;
    lcd.fillRoundRect(bx,by,250,138,14,bg[i]);lcd.drawRoundRect(bx,by,250,138,14,bd[i]);lcd.drawRoundRect(bx+1,by+1,248,136,13,bd[i]);
    lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);lcd.drawCenterString(nm[i],bx+125,by+58);}}
void handleMenu(int16_t tx,int16_t ty){for(int i=0;i<9;i++){int bx=15+(i%3)*262,by=48+(i/3)*146;
  if(tx>=bx&&tx<bx+250&&ty>=by&&ty<by+138){curGame=i+1;appState=1;
    switch(curGame){case 1:chess_drawOpt();break;case 2:ck_drawOpt();break;case 3:fr_drawOpt();break;case 4:mm_drawOpt();break;case 5:lu_drawOpt();break;case 6:sn_drawOpt();break;case 7:tt_drawOpt();break;case 8:mq_drawOpt();break;case 9:db_drawOpt();break;}return;}}}
void setup(){Serial.begin(115200);delay(300);lcd.init();lcd.setRotation(0);lcd.setBrightness(200);lcd.setColorDepth(16);randomSeed(analogRead(0)+millis());drawMenu();}
void loop(){int16_t tx,ty;
  if(appState==0){if(tOnce(&tx,&ty))handleMenu(tx,ty);}
  else if(appState==1){if(tOnce(&tx,&ty)){switch(curGame){case 1:chess_handleOpt(tx,ty);break;case 2:ck_handleOpt(tx,ty);break;case 3:fr_handleOpt(tx,ty);break;case 4:mm_handleOpt(tx,ty);break;case 5:lu_handleOpt(tx,ty);break;case 6:sn_handleOpt(tx,ty);break;case 7:tt_handleOpt(tx,ty);break;case 8:mq_handleOpt(tx,ty);break;case 9:db_handleOpt(tx,ty);break;}}}
  else{if(ngConf){if(tOnce(&tx,&ty))handleConfirm(tx,ty);delay(5);return;}
    switch(curGame){case 1:chess_loop();break;case 2:ck_loop();break;case 3:fr_loop();break;case 4:mm_loop();break;case 5:lu_loop();break;case 6:sn_loop();break;case 7:tt_loop();break;case 8:mq_loop();break;case 9:db_loop();break;}}
  delay(5);}

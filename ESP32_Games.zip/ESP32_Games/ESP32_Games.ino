#define LGFX_USE_V1
#include <Arduino.h>
#include <LovyanGFX.hpp>
#include <lgfx/v1/platforms/esp32s3/Panel_RGB.hpp>
#include <lgfx/v1/platforms/esp32s3/Bus_RGB.hpp>
#include "chess_types.h"
class LGFX:public lgfx::LGFX_Device{public:lgfx::Bus_RGB _bus;lgfx::Panel_RGB _panel;lgfx::Light_PWM _light;lgfx::Touch_GT911 _touch;
LGFX(void){{auto c=_panel.config();c.memory_width=800;c.memory_height=480;c.panel_width=800;c.panel_height=480;c.offset_x=0;c.offset_y=0;_panel.config(c);}
{auto c=_panel.config_detail();c.use_psram=1;_panel.config_detail(c);}
{auto c=_bus.config();c.panel=&_panel;c.pin_d0=GPIO_NUM_14;c.pin_d1=GPIO_NUM_38;c.pin_d2=GPIO_NUM_18;c.pin_d3=GPIO_NUM_17;c.pin_d4=GPIO_NUM_10;c.pin_d5=GPIO_NUM_39;c.pin_d6=GPIO_NUM_0;c.pin_d7=GPIO_NUM_45;c.pin_d8=GPIO_NUM_48;c.pin_d9=GPIO_NUM_47;c.pin_d10=GPIO_NUM_21;c.pin_d11=GPIO_NUM_1;c.pin_d12=GPIO_NUM_2;c.pin_d13=GPIO_NUM_42;c.pin_d14=GPIO_NUM_41;c.pin_d15=GPIO_NUM_40;c.pin_henable=GPIO_NUM_5;c.pin_vsync=GPIO_NUM_3;c.pin_hsync=GPIO_NUM_46;c.pin_pclk=GPIO_NUM_7;c.freq_write=16000000;c.hsync_polarity=0;c.hsync_front_porch=8;c.hsync_pulse_width=4;c.hsync_back_porch=8;c.vsync_polarity=0;c.vsync_front_porch=8;c.vsync_pulse_width=4;c.vsync_back_porch=8;c.pclk_active_neg=1;c.de_idle_high=0;c.pclk_idle_high=0;_bus.config(c);}
{auto c=_light.config();c.pin_bl=GPIO_NUM_2;c.invert=false;_light.config(c);}
{auto c=_touch.config();c.x_min=0;c.x_max=799;c.y_min=0;c.y_max=479;c.pin_int=GPIO_NUM_NC;c.pin_rst=GPIO_NUM_NC;c.i2c_port=0;c.i2c_addr=0x14;c.pin_sda=GPIO_NUM_8;c.pin_scl=GPIO_NUM_9;c.freq=400000;_touch.config(c);}
_panel.setBus(&_bus);_panel.setLight(&_light);_panel.setTouch(&_touch);setPanel(&_panel);}};
LGFX lcd;
int appState=0,curGame=0;
bool prevTch=false;uint32_t lastTchMs=0;
bool tOnce(int16_t*tx,int16_t*ty){uint16_t x,y;bool t=lcd.getTouch(&x,&y);*tx=x;*ty=y;uint32_t n=millis();if(t&&!prevTch&&(n-lastTchMs>200)){prevTch=true;lastTchMs=n;return true;}if(!t)prevTch=false;return false;}
bool tRaw(int16_t*tx,int16_t*ty){uint16_t x,y;bool t=lcd.getTouch(&x,&y);*tx=x;*ty=y;return t;}
void fmtTime(uint32_t ms,char*b){uint32_t s=ms/1000,m=s/60;s%=60;if(m*60+s<10){uint32_t t=(ms%1000)/100;sprintf(b,"%d:%02d.%d",m,s,t);}else sprintf(b,"%d:%02d",m,s);}
// Soft button helper
void drawSoftBtn(int x,int y,int w,int h,uint32_t fill,uint32_t bord,const char*lb,uint32_t tc=TX,const lgfx::IFont*f=&fonts::FreeSansBold12pt7b){
  lcd.fillRoundRect(x,y,w,h,10,fill);lcd.drawRoundRect(x,y,w,h,10,bord);
  lcd.setFont(f);lcd.setTextColor(tc);lcd.drawCenterString(lb,x+w/2,y+h/2-10);}
// Dice
int diceOff=0;
bool diceWait=false;uint32_t diceWaitStart=0;
bool diceReady=false;
bool testDice=false;
int diceVals[6];
void startDiceWait(){diceWait=true;diceWaitStart=millis();diceReady=false;}
bool updateDiceWait(){if(!diceWait)return false;if(millis()-diceWaitStart>=1500){
  diceWait=false;
  for(int i=0;i<6;i++)diceVals[i]=i+1;
  for(int i=5;i>0;i--){int j=random(0,i+1);int t=diceVals[i];diceVals[i]=diceVals[j];diceVals[j]=t;}
  diceReady=true;return false;}return true;}
// New-game hold button
void drawNGBtn(int bx,int by,int bw,int bh){
  lcd.fillRoundRect(bx+5,by+5,bw-10,bh-10,10,SURF2);lcd.drawRoundRect(bx+5,by+5,bw-10,bh-10,10,BORD);
  lcd.setFont(&fonts::FreeSansBold9pt7b);lcd.setTextColor(TX);lcd.drawCenterString("HOLD 3s: NEW GAME",bx+bw/2-15,by+bh/2-7);
  lcd.fillRoundRect(bx+bw-60,by+bh/2-5,50,10,4,BORD);}
void drawMenu();void redrawCurrentGame();
bool ngH=false;uint32_t ngS=0;bool ngConf=false;
void drawConfirm(){
  lcd.fillRect(150,160,500,170,SURF2);lcd.drawRoundRect(150,160,500,170,12,DANGER);lcd.drawRoundRect(151,161,498,168,11,DANGER);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(TX);lcd.drawCenterString("Return to menu?",400,185);
  drawSoftBtn(220,260,150,55,SGRN,GOLD,"YES");
  drawSoftBtn(430,260,150,55,SRED,GOLD,"NO");}
bool doNG(int bx,int by,int bw,int bh,int16_t rx,int16_t ry,bool tch){
  if(ngConf)return true;bool in=(rx>=bx&&rx<bx+bw&&ry>=by&&ry<by+bh);
  if(tch&&in){if(!ngH){ngH=true;ngS=millis();}uint32_t el=millis()-ngS;int pct=min((int)(el*100/3000),100);
    int px=bx+bw-60,py=by+bh/2-5;lcd.fillRoundRect(px,py,50,10,4,BORD);int w=pct*44/100;if(w>0)lcd.fillRoundRect(px+3,py+2,w,6,3,GOLD);
    if(el>=3000){ngH=false;ngConf=true;drawConfirm();return true;}}else{if(ngH){ngH=false;}}return false;}
bool handleConfirm(int16_t tx,int16_t ty){if(!ngConf)return false;
  if(tx>=220&&tx<370&&ty>=260&&ty<315){ngConf=false;ngH=false;appState=0;drawMenu();return true;}
  if(tx>=430&&tx<580&&ty>=260&&ty<315){ngConf=false;ngH=false;redrawCurrentGame();return true;}return true;}
#include "game_chess.h"
#include "game_checkers.h"
#include "game_fourrow.h"
#include "game_memory.h"
#include "game_ludo.h"
#include "game_snakes.h"
#include "game_tictactoe.h"
#include "game_mathquiz.h"
#include "game_dotsboxes.h"
#include "game_bingo.h"
#include "game_rps.h"
#include "game_matchshapes.h"
void redrawCurrentGame(){lcd.fillScreen(BGC);switch(curGame){
  case 1:memset(cDt,1,64);cFull=true;cDrawBoard();cDrawPanels();break;
  case 2:ckDrawBoard();ckPnlDirty=true;ckDrawPanels();break;
  case 3:frDrawBoard();frPD=true;frDrawPanels();break;
  case 4:mmDrawBoard();mmPD=true;mmDrawPanels();break;
  case 5:luDrawBoard();luDrawPanels();break;
  case 6:snDrawBoard();snDrawPanels();break;
  case 7:ttDrawBoard();ttDrawPanels();break;
  case 8:mqRedraw();break;
  case 9:dbDrawBoard();dbDrawPanels();break;
  case 10:bgDrawBoard();bgDrawPanels();break;
  case 11:rpsDrawAll();break;
  case 12:msDrawAll();break;}}
// Menu (4 cols x 3 rows = 12 games, all filled)
void drawMenu(){
  lcd.fillScreen(BGC);
  // Title band - blue, contrasting
  lcd.fillRect(0,0,800,46,SURF2);
  lcd.fillRect(0,44,800,2,GOLD);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(TX);
  lcd.drawCenterString("GAME CENTER",400,10);
  lcd.setFont(&fonts::FreeSans9pt7b);lcd.setTextColor(GOLD);
  lcd.drawString("v2.1",740,16);
  // 12 games in 4x3 grid
  const char*nm[]={"CHESS","CHECKERS","FOUR IN ROW","MEMORY","LUDO","SNAKES","TIC TAC TOE","MATH QUIZ","DOTS BOXES","BINGO WHEEL","ROCK PAPER","MATCH SHAPES"};
  const char*nm2[]={"","","","","","","","","","","SCISSORS",""};
  // Player count badges
  const char*pc[]={"2P","2P","2P","2-3P","2-4P","2-4P","2P","2-3P","2P","2P","2P","2P"};
  // Tile colors per game
  uint32_t tc[]={SGRN,VPRP,SRED,VTEAL,VORG,SBLU,VPNK,SYLW,VCOR,VPRP,SRED,SBLU};
  for(int i=0;i<12;i++){
    int col=i%4,r=i/4;
    int bx=12+col*197,by=56+r*138;
    int bw=185,bh=125;
    // Tile fill
    lcd.fillRoundRect(bx,by,bw,bh,14,tc[i]);
    lcd.drawRoundRect(bx,by,bw,bh,14,GOLD);
    lcd.drawRoundRect(bx+1,by+1,bw-2,bh-2,13,GOLD);
    // White inner panel for text contrast
    lcd.fillRoundRect(bx+8,by+8,bw-16,bh-16,8,0xFFFFFF);
    // Top accent stripe
    lcd.fillRect(bx+18,by+18,bw-36,5,tc[i]);
    // Title - use smaller font for long names
    bool longName=(strlen(nm[i])>9);
    if(longName) lcd.setFont(&fonts::FreeSansBold9pt7b);
    else         lcd.setFont(&fonts::FreeSansBold12pt7b);
    lcd.setTextColor(tc[i]);
    if(strlen(nm2[i])>0){
      lcd.drawCenterString(nm[i],bx+bw/2,by+40);
      lcd.drawCenterString(nm2[i],bx+bw/2,by+63);
    } else {
      lcd.drawCenterString(nm[i],bx+bw/2,by+53);
    }
    // Player count badge (small rounded pill at bottom)
    int pbx=bx+bw/2-22,pby=by+bh-30;
    lcd.fillRoundRect(pbx,pby,44,18,9,tc[i]);
    lcd.setFont(&fonts::FreeSansBold9pt7b);lcd.setTextColor(TX);
    lcd.drawCenterString(pc[i],bx+bw/2,pby+3);
  }
}
void handleMenu(int16_t tx,int16_t ty){
  for(int i=0;i<12;i++){
    int col=i%4,r=i/4;
    int bx=12+col*197,by=56+r*138;
    int bw=185,bh=125;
    if(tx>=bx&&tx<bx+bw&&ty>=by&&ty<by+bh){
      curGame=i+1;appState=1;
      switch(curGame){
        case 1:chess_drawOpt();break;case 2:ck_drawOpt();break;case 3:fr_drawOpt();break;
        case 4:mm_drawOpt();break;case 5:lu_drawOpt();break;case 6:sn_drawOpt();break;
        case 7:tt_drawOpt();break;case 8:mq_drawOpt();break;case 9:db_drawOpt();break;
        case 10:bg_drawOpt();break;case 11:rps_drawOpt();break;case 12:ms_drawOpt();break;}
      return;}}}
void setup(){
  Serial.begin(115200);delay(300);
  lcd.init();lcd.setRotation(0);lcd.setBrightness(200);lcd.setColorDepth(16);
  randomSeed(analogRead(0)+millis());
  drawMenu();
}
void loop(){
  int16_t tx,ty;
  if(appState==0){if(tOnce(&tx,&ty))handleMenu(tx,ty);}
  else if(appState==1){
    if(tOnce(&tx,&ty)){switch(curGame){
      case 1:chess_handleOpt(tx,ty);break;case 2:ck_handleOpt(tx,ty);break;
      case 3:fr_handleOpt(tx,ty);break;case 4:mm_handleOpt(tx,ty);break;
      case 5:lu_handleOpt(tx,ty);break;case 6:sn_handleOpt(tx,ty);break;
      case 7:tt_handleOpt(tx,ty);break;case 8:mq_handleOpt(tx,ty);break;
      case 9:db_handleOpt(tx,ty);break;case 10:bg_handleOpt(tx,ty);break;
      case 11:rps_handleOpt(tx,ty);break;case 12:ms_handleOpt(tx,ty);break;}}}
  else{
    if(ngConf){if(tOnce(&tx,&ty))handleConfirm(tx,ty);delay(5);return;}
    switch(curGame){
      case 1:chess_loop();break;case 2:ck_loop();break;case 3:fr_loop();break;
      case 4:mm_loop();break;case 5:lu_loop();break;case 6:sn_loop();break;
      case 7:tt_loop();break;case 8:mq_loop();break;case 9:db_loop();break;
      case 10:bg_loop();break;case 11:rps_loop();break;case 12:ms_loop();break;}}
  delay(5);
}

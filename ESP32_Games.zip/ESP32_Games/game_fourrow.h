#pragma once
#define FRR 6
#define FRC 7
#define FRCL 68
static int8_t frB[FRR][FRC];static bool frYT,frGO;static char frSt[64]="";
static uint32_t frYMs,frRMs,frLTk;static bool frClk=false;static int frWin[4][2];static bool frHW=false;static bool frPD=true;
static void frInit(){memset(frB,0,sizeof(frB));frYT=true;frGO=false;frHW=false;strcpy(frSt,"Yellow's Turn");frPD=true;}
static int frDrop(int c){for(int r=FRR-1;r>=0;r--)if(!frB[r][c]){frB[r][c]=frYT?1:2;return r;}return -1;}
static bool frC4(int r,int c,int dr,int dc,int8_t p){for(int i=0;i<4;i++){int nr=r+dr*i,nc=c+dc*i;if(nr<0||nr>=FRR||nc<0||nc>=FRC||frB[nr][nc]!=p)return false;}for(int i=0;i<4;i++){frWin[i][0]=r+dr*i;frWin[i][1]=c+dc*i;}return true;}
static bool frCW(int8_t p){for(int r=0;r<FRR;r++)for(int c=0;c<FRC;c++)if(frC4(r,c,0,1,p)||frC4(r,c,1,0,p)||frC4(r,c,1,1,p)||frC4(r,c,1,-1,p))return true;return false;}
static bool frFull(){for(int c=0;c<FRC;c++)if(!frB[0][c])return false;return true;}
static void frDrawBoard(){
  int ox=(480-FRC*FRCL)/2,oy=(480-FRR*FRCL)/2;
  // Soft muted blue board
  lcd.fillRect(0,0,480,480,BGC);
  lcd.fillRoundRect(ox-8,oy-8,FRC*FRCL+16,FRR*FRCL+16,14,0x3D5479);
  lcd.drawRoundRect(ox-8,oy-8,FRC*FRCL+16,FRR*FRCL+16,14,BORD2);
  for(int r=0;r<FRR;r++)for(int c=0;c<FRC;c++){
    int x=ox+c*FRCL+FRCL/2,y=oy+r*FRCL+FRCL/2;
    uint32_t cl=SURF;
    if(frB[r][c]==1)cl=SYLW;
    else if(frB[r][c]==2)cl=SRED;
    lcd.fillCircle(x,y,FRCL/2-4,cl);
    lcd.drawCircle(x,y,FRCL/2-4,0x2A3650);
  }
  if(frHW)for(int i=0;i<4;i++){
    int x=ox+frWin[i][1]*FRCL+FRCL/2,y=oy+frWin[i][0]*FRCL+FRCL/2;
    lcd.drawCircle(x,y,FRCL/2-2,GOLD);
    lcd.drawCircle(x,y,FRCL/2-3,GOLD);}
}
static void frDrawPanels(){
  if(!frPD)return;frPD=false;
  // Top: Red - gentle dusty rose
  bool actR=!frYT&&!frGO;
  lcd.fillRect(PX,0,PW,200,SRED);
  if(actR){for(int i=0;i<4;i++)lcd.drawRect(PX+i,i,PW-i*2,200-i*2,YLBORD);}
  lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);
  lcd.drawString(actR?"Red's turn":"RED",PX+20,20);
  lcd.fillCircle(PX+PW-40,40,18,SRED);lcd.drawCircle(PX+PW-40,40,18,TX);
  char buf[16];fmtTime(frRMs,buf);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(actR?YLBORD:TX);lcd.drawString(buf,PX+30,70);
  if(frGO){lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(GOLD);lcd.drawString(frSt,PX+15,150);}
  // Mid
  lcd.fillRect(PX,200,PW,80,BGC);drawNGBtn(PX,200,PW,80);
  // Bottom: Yellow - gentle mustard
  bool actY=frYT&&!frGO;
  lcd.fillRect(PX,280,PW,200,SYLW);
  if(actY){for(int i=0;i<4;i++)lcd.drawRect(PX+i,280+i,PW-i*2,200-i*2,DANGER);}
  lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TXK);
  lcd.drawString(actY?"Yellow's turn":"YELLOW",PX+20,300);
  lcd.fillCircle(PX+PW-40,320,18,SYLW);lcd.drawCircle(PX+PW-40,320,18,TXK);
  fmtTime(frYMs,buf);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(actY?DANGER:TXK);lcd.drawString(buf,PX+30,360);
  if(frGO){lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(DANGER);lcd.drawString(frSt,PX+15,440);}
}
void fr_drawOpt(){
  lcd.fillScreen(BGC);
  lcd.fillRect(0,0,800,42,SURF);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(GOLD);lcd.drawCenterString("FOUR IN ROW",400,8);
  lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);lcd.drawCenterString("Select Time",400,90);
  const char*lb[]={"5 min","10 min"};
  for(int i=0;i<2;i++){int bx=180+i*220,by=170;
    lcd.fillRoundRect(bx,by,180,80,14,SURF2);lcd.drawRoundRect(bx,by,180,80,14,BORD);
    lcd.fillRect(bx+15,by+15,4,30,SRED);
    lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(TX);lcd.drawCenterString(lb[i],bx+90,by+28);}
}
void fr_handleOpt(int16_t tx,int16_t ty){
  int tms[]={5,10};
  for(int i=0;i<2;i++){int bx=180+i*220,by=170;if(tx>=bx&&tx<bx+180&&ty>=by&&ty<by+80){
    frYMs=frRMs=(uint32_t)tms[i]*60000;frInit();frClk=true;frLTk=millis();appState=2;
    lcd.fillScreen(BGC);frDrawBoard();frPD=true;frDrawPanels();return;}}
}
void fr_loop(){
  int16_t tx,ty,rx,ry;bool tch=tRaw(&rx,&ry);
  if(doNG(PX,200,PW,80,rx,ry,tch))return;
  if(!ngH&&tOnce(&tx,&ty)&&tx<480&&ty<480&&!frGO){
    int ox=(480-FRC*FRCL)/2;int col=(tx-ox)/FRCL;
    if(col>=0&&col<FRC){int row=frDrop(col);if(row>=0){
      if(frCW(frYT?1:2)){frGO=true;frClk=false;frHW=true;snprintf(frSt,64,"%s wins!",frYT?"Yellow":"Red");}
      else if(frFull()){frGO=true;frClk=false;strcpy(frSt,"Draw!");}
      else{frYT=!frYT;snprintf(frSt,64,"%s's Turn",frYT?"Yellow":"Red");}
      frDrawBoard();frPD=true;frDrawPanels();}}}
  if(frClk&&!frGO){uint32_t now=millis(),dt=now-frLTk;frLTk=now;
    if(frYT){if(frYMs<=dt){frYMs=0;frGO=true;frClk=false;strcpy(frSt,"Red wins!");frPD=true;frDrawPanels();}else frYMs-=dt;}
    else{if(frRMs<=dt){frRMs=0;frGO=true;frClk=false;strcpy(frSt,"Yellow wins!");frPD=true;frDrawPanels();}else frRMs-=dt;}
    static uint32_t frtl=0;if(now-frtl>500){frtl=now;frPD=true;frDrawPanels();}}
}

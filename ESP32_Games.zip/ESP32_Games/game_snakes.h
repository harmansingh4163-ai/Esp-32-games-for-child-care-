#pragma once
#define SCL 48
static int snP[4];static int snPl,snCr;static bool snGO=false;static int snD=0;static bool snRl=false;static char snSt[64]="";
static int snk[][2]={{16,6},{47,26},{49,11},{56,53},{62,19},{64,60},{87,24},{93,73},{95,75},{98,78}};
static int ldr[][2]={{1,38},{4,14},{9,31},{21,42},{28,84},{36,44},{51,67},{71,91},{80,100}};
static void snInit(int p){snPl=p;snCr=0;snGO=false;snD=0;snRl=false;diceReady=false;diceWait=false;for(int i=0;i<4;i++)snP[i]=0;strcpy(snSt,"Tap ROLL");}
static void snXY(int pos,int*ox,int*oy){
  if(pos<1){*ox=*oy=-1;return;}
  int p=pos-1;int row=9-p/10;int col=((9-row)%2==0)?(p%10):(9-p%10);
  *ox=col*SCL+SCL/2;*oy=row*SCL+SCL/2;}
static void snDrawBoard(){
  // Cream board with black numbers, gentle accents
  lcd.fillRect(0,0,480,480,0xFFF5E0);
  uint32_t cl[]={0xFFFAEB,0xFFE5B0};
  for(int r=0;r<10;r++)for(int c=0;c<10;c++){
    int x=c*SCL,y=r*SCL;
    lcd.fillRect(x,y,SCL,SCL,cl[(r+c)%2]);
    lcd.drawRect(x,y,SCL,SCL,0xCAB68E);
    int brow=9-r;int bcol=(brow%2==0)?c:(9-c);int num=brow*10+bcol+1;
    lcd.setFont(&fonts::Font2);lcd.setTextColor(0x000000); // BLACK numbers
    char s[4];sprintf(s,"%d",num);lcd.drawString(s,x+2,y+2);}
  // Snakes - gentle coral
  for(int i=0;i<10;i++){
    int x1,y1,x2,y2;snXY(snk[i][0],&x1,&y1);snXY(snk[i][1],&x2,&y2);
    if(x1>=0)for(int t=-1;t<=1;t++)lcd.drawLine(x1+t,y1,x2+t,y2,SCOR);}
  // Ladders - gentle sage, two rails
  for(int i=0;i<9;i++){
    int x1,y1,x2,y2;snXY(ldr[i][0],&x1,&y1);snXY(ldr[i][1],&x2,&y2);
    if(x1>=0){
      lcd.drawLine(x1-3,y1,x2-3,y2,SGRN);
      lcd.drawLine(x1+3,y1,x2+3,y2,SGRN);}}
  // Player tokens - gentle
  uint32_t tc[]={SRED,SBLU,SGRN,SYLW};
  for(int p=0;p<snPl;p++){
    if(snP[p]<1)continue;
    int x,y;snXY(snP[p],&x,&y);x+=p*6-6;
    lcd.fillCircle(x,y,10,tc[p]);lcd.drawCircle(x,y,10,0x3A3A3A);}
}
static void snDraw6Btn(){
  int bx=PX+PW/2-150,by=280;
  bool show=testDice||diceReady;
  for(int i=0;i<6;i++){int x=bx+(i%3)*100,y=by+(i/3)*55;
    lcd.fillRoundRect(x,y,90,48,8,show?SURF2:SURF);
    lcd.drawRoundRect(x,y,90,48,8,show?GOLD:BORD);
    if(testDice){lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(TX);
      char s[2];sprintf(s,"%d",i+1);lcd.drawCenterString(s,x+45,y+12);}
    else{lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(show?TX:TXD);lcd.drawCenterString("?",x+45,y+12);}}}
static void snDrawPanels(){
  lcd.fillRect(PX,0,PW,480,BGC);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(GOLD);
  lcd.drawCenterString("SNAKES",PX+PW/2,12);
  uint32_t tc[]={SRED,SBLU,SGRN,SYLW};
  for(int p=0;p<snPl;p++){
    int y=55+p*42;bool cur=(p==snCr&&!snGO);
    lcd.fillRoundRect(PX+15,y,PW-30,36,8,cur?tc[p]:SURF2);
    lcd.drawRoundRect(PX+15,y,PW-30,36,8,cur?GOLD:BORD);
    lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(cur?TX:TXD);
    char buf[20];sprintf(buf,"P%d   square %d",p+1,snP[p]);
    lcd.drawString(buf,PX+25,y+8);}
  if(!testDice){
    uint32_t rb=diceWait?SURF:PGN;uint32_t rbd=diceWait?BORD:PGNB;
    lcd.fillRoundRect(PX+PW/2-80,235,160,40,10,rb);
    lcd.drawRoundRect(PX+PW/2-80,235,160,40,10,rbd);
    lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);
    lcd.drawCenterString(diceWait?"ROLLING...":"TAP TO ROLL",PX+PW/2,245);}
  if(diceWait){uint32_t el=millis()-diceWaitStart;int pct=min((int)(el*100/1500),100);
    lcd.fillRoundRect(PX+PW/2-70,225,140,6,3,SURF);int w=pct*136/100;if(w>0)lcd.fillRoundRect(PX+PW/2-68,226,w,4,2,GOLD);}
  snDraw6Btn();
  lcd.fillRect(PX+5,395,PW-10,30,BGC);
  if(testDice||diceReady){lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(GOLD);lcd.drawCenterString("Pick a number!",PX+PW/2,398);}
  else if(snD>0&&!diceWait){lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(SGRN);
    char db[20];sprintf(db,"Picked: %d",snD);lcd.drawCenterString(db,PX+PW/2,398);}
  if(snGO){lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(GOLD);lcd.drawString(snSt,PX+40,410);}
  lcd.fillRect(PX,440,PW,40,BGC);drawNGBtn(PX,440,PW,40);
}
void sn_drawOpt(){
  lcd.fillScreen(BGC);
  lcd.fillRect(0,0,800,42,SURF);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(GOLD);
  lcd.drawCenterString("SNAKES & LADDERS",400,8);
  lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);
  lcd.drawCenterString("Players",400,100);
  for(int i=0;i<3;i++){int bx=150+i*200,by=160;
    lcd.fillRoundRect(bx,by,160,80,14,SURF2);lcd.drawRoundRect(bx,by,160,80,14,BORD);
    lcd.fillRect(bx+15,by+15,4,30,STEA);
    char s[2];sprintf(s,"%d",i+2);
    lcd.setFont(&fonts::FreeSansBold24pt7b);lcd.setTextColor(TX);lcd.drawCenterString(s,bx+80,by+18);}
}
void sn_handleOpt(int16_t tx,int16_t ty){
  for(int i=0;i<3;i++){int bx=150+i*200,by=160;if(tx>=bx&&tx<bx+160&&ty>=by&&ty<by+80){
    snInit(i+2);appState=2;lcd.fillScreen(BGC);snDrawBoard();snDrawPanels();return;}}
}
void sn_loop(){
  int16_t tx,ty,rx,ry;bool tch=tRaw(&rx,&ry);
  if(doNG(PX,440,PW,40,rx,ry,tch))return;
  if(snGO){delay(20);return;}
  if(diceWait){updateDiceWait();snDrawPanels();delay(30);return;}
  if(!ngH&&tOnce(&tx,&ty)){
    if(!testDice&&!diceReady&&tx>=PX+PW/2-80&&tx<PX+PW/2+80&&ty>=235&&ty<275){startDiceWait();snDrawPanels();return;}
    if(testDice||diceReady){
      int bx=PX+PW/2-150,by=280;
      for(int i=0;i<6;i++){int x=bx+(i%3)*100,y=by+(i/3)*55;
        if(tx>=x&&tx<x+90&&ty>=y&&ty<y+48){
          snD=testDice?(i+1):diceVals[i];diceReady=false;
          if(snP[snCr]==0){snP[snCr]=snD;
            for(int j=0;j<10;j++)if(snk[j][0]==snP[snCr])snP[snCr]=snk[j][1];
            for(int j=0;j<9;j++)if(ldr[j][0]==snP[snCr])snP[snCr]=ldr[j][1];}
          else{int np=snP[snCr]+snD;if(np<=100){snP[snCr]=np;
            for(int j=0;j<10;j++)if(snk[j][0]==snP[snCr])snP[snCr]=snk[j][1];
            for(int j=0;j<9;j++)if(ldr[j][0]==snP[snCr])snP[snCr]=ldr[j][1];}}
          if(snP[snCr]>=100){snP[snCr]=100;snGO=true;sprintf(snSt,"Player %d wins!",snCr+1);}
          else{if(snD!=6)snCr=(snCr+1)%snPl;sprintf(snSt,"P%d: Tap ROLL",snCr+1);}
          snDrawBoard();snDrawPanels();return;}}}}
}

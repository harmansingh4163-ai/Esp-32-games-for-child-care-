#pragma once
static int mqPl,mqCr;static int mqSc[3];static bool mqGO=false;
static int mqA,mqB,mqAns,mqType=0;
static char mqQ[32]="";static char mqIn[12]="";static int mqIL=0;
static uint32_t mqTStart;static bool mqActive=false;
static char mqSt[64]="";static bool mqShowRes=false;static uint32_t mqResT=0;static bool mqCorrect=false;
static int mqPassCnt=0; // pass same question to next player
#define MQTIME 25000
static int dsum(int n){int s=0;n=abs(n);while(n>0){s+=n%10;n/=10;}return s;}
static void mqGenQ(){mqIL=0;mqIn[0]=0;mqActive=true;mqTStart=millis();mqCorrect=false;mqShowRes=false;mqPassCnt=0;
  switch(mqType){
    case 0:{do{mqA=random(10,99);mqB=random(10,99);}while(dsum(mqA)+dsum(mqB)<=10);mqAns=mqA+mqB;sprintf(mqQ,"%d + %d = ?",mqA,mqB);break;}
    case 1:{do{mqA=random(10,99);mqB=random(10,99);}while(dsum(mqA)+dsum(mqB)<=10||mqA<mqB);mqAns=mqA-mqB;sprintf(mqQ,"%d - %d = ?",mqA,mqB);break;}
    case 2:{do{mqA=random(100,999);mqB=random(100,999);}while(dsum(mqA)+dsum(mqB)<=10);mqAns=mqA+mqB;sprintf(mqQ,"%d + %d = ?",mqA,mqB);break;}
    case 3:{do{mqA=random(100,999);mqB=random(100,999);}while(dsum(mqA)+dsum(mqB)<=10||mqA<mqB);mqAns=mqA-mqB;sprintf(mqQ,"%d - %d = ?",mqA,mqB);break;}
    case 4:{mqA=random(2,10);mqB=random(2,10);mqAns=mqA*mqB;sprintf(mqQ,"%d x %d = ?",mqA,mqB);break;}
    case 5:{mqB=random(2,10);mqAns=random(2,10);mqA=mqB*mqAns;sprintf(mqQ,"%d / %d = ?",mqA,mqB);break;}}}
static void mqInit(int pl,int type){mqPl=pl;mqCr=0;memset(mqSc,0,12);mqGO=false;mqType=type;mqGenQ();strcpy(mqSt,"Player 1");}
static void mqDrawKeypad(){int kx=PX+10,ky=200;for(int i=0;i<12;i++){int r=i/3,c=i%3,bx=kx+c*105,by=ky+r*55;
    const char*lb[]={"1","2","3","4","5","6","7","8","9","<","0","OK"};uint32_t bg=(i==9)?0x8B0000:(i==11)?0x1B5E20:0x37474F;
    lcd.fillRoundRect(bx,by,95,48,8,bg);lcd.drawRoundRect(bx,by,95,48,8,0x666666);lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);lcd.drawString(lb[i],bx+32,by+12);}}
static void mqRedraw(){lcd.fillScreen(BGC);lcd.fillRect(0,0,480,480,0x1A237E);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(TX);char plb[20];sprintf(plb,"Player %d",mqCr+1);lcd.drawString(plb,150,30);
  lcd.setFont(&fonts::FreeSansBold24pt7b);lcd.setTextColor(0xFDD835);lcd.drawString(mqQ,50,120);
  lcd.fillRoundRect(80,220,320,60,10,0x283593);lcd.drawRoundRect(80,220,320,60,10,0x5C6BC0);
  lcd.setFont(&fonts::FreeSansBold24pt7b);lcd.setTextColor(TX);lcd.drawString(mqIL>0?mqIn:"_",100,230);
  if(mqActive){uint32_t el=millis()-mqTStart;int pct=max(0,(int)(100-el*100/MQTIME));lcd.fillRoundRect(80,300,320,15,6,0x333333);int w=pct*316/100;if(w>0)lcd.fillRoundRect(82,302,w,11,5,pct>30?0x4CAF50:0xF44336);}
  if(mqShowRes&&mqCorrect){lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(0x4CAF50);lcd.drawString("Correct!",160,360);}
  // Right panel
  lcd.fillRect(PX,0,PW,480,BGC);lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(0xE2B96F);lcd.drawCenterString("MATH QUIZ",PX+PW/2,15);
  uint32_t pc[]={0xE53935,0x1E88E5,0x43A047};for(int i=0;i<mqPl;i++){int y=60+i*45;lcd.fillRoundRect(PX+15,y,PW-30,38,6,i==mqCr?pc[i]:0x333333);
    lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);char buf[20];sprintf(buf,"P%d: %d/10",i+1,mqSc[i]);lcd.drawString(buf,PX+25,y+8);}
  mqDrawKeypad();lcd.fillRect(PX,430,PW,50,BGC);drawNGBtn(PX,430,PW,50);
  if(mqGO){lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(0xF9A825);lcd.drawString(mqSt,PX+50,175);}}
void mq_drawOpt(){lcd.fillScreen(BGC);lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(0xE2B96F);lcd.drawCenterString("MATH QUIZ",400,15);
  lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);lcd.drawString("Players:",100,60);
  for(int i=0;i<2;i++){int bx=250+i*150,by=50;lcd.fillRoundRect(bx,by,120,45,10,0x1A237E);lcd.drawRoundRect(bx,by,120,45,10,0x283593);char s[2];sprintf(s,"%d",i+2);lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(TX);lcd.drawString(s,bx+45,by+8);}lcd.drawRoundRect(250,50,120,45,10,0xFFFF00);
  lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);lcd.drawString("Quiz Type:",100,120);
  const char*tp[]={"2-Digit +","2-Digit -","3-Digit +","3-Digit -","Multiply","Division"};
  for(int i=0;i<6;i++){int bx=30+(i%3)*260,by=160+(i/3)*80;lcd.fillRoundRect(bx,by,240,65,10,0x1A237E);lcd.drawRoundRect(bx,by,240,65,10,0x283593);lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);lcd.drawCenterString(tp[i],bx+120,by+20);}}
static int mqSelPl=2;
void mq_handleOpt(int16_t tx,int16_t ty){for(int i=0;i<2;i++){int bx=250+i*150,by=50;if(tx>=bx&&tx<bx+120&&ty>=by&&ty<by+45){mqSelPl=i+2;lcd.drawRoundRect(250,50,120,45,10,0x1A237E);lcd.drawRoundRect(400,50,120,45,10,0x1A237E);lcd.drawRoundRect(bx,by,120,45,10,0xFFFF00);return;}}
  for(int i=0;i<6;i++){int bx=30+(i%3)*260,by=160+(i/3)*80;if(tx>=bx&&tx<bx+240&&ty>=by&&ty<by+65){mqInit(mqSelPl,i);appState=2;mqRedraw();return;}}}
void mq_loop(){int16_t tx,ty,rx,ry;bool tch=tRaw(&rx,&ry);if(doNG(PX,430,PW,50,rx,ry,tch))return;if(mqGO){delay(20);return;}
  // Result pause: correct shows briefly, wrong/timeout passes question to next player
  if(mqShowRes){if(millis()-mqResT>1200){mqShowRes=false;
    if(mqCorrect){mqPassCnt=0;mqSc[mqCr]++;if(mqSc[mqCr]>=10){mqGO=true;sprintf(mqSt,"Player %d wins!",mqCr+1);mqRedraw();return;}
      mqCr=(mqCr+1)%mqPl;mqGenQ();}  // correct: new question for next player
    else{mqPassCnt++;if(mqPassCnt>=mqPl*2){mqPassCnt=0;mqCr=(mqCr+1)%mqPl;mqGenQ();}else{mqCr=(mqCr+1)%mqPl;mqIL=0;mqIn[0]=0;mqActive=true;mqTStart=millis();}} // wrong: SAME question passes
    sprintf(mqSt,"Player %d",mqCr+1);mqRedraw();}
    else{static uint32_t mrl=0;if(millis()-mrl>100){mrl=millis();// timer bar
      uint32_t el=millis()-mqTStart;int pct=max(0,(int)(100-el*100/MQTIME));lcd.fillRoundRect(80,300,320,15,6,0x333333);int w=pct*316/100;if(w>0)lcd.fillRoundRect(82,302,w,11,5,pct>30?0x4CAF50:0xF44336);}}delay(5);return;}
  // Timer expired
  if(mqActive&&millis()-mqTStart>=MQTIME){mqActive=false;mqCorrect=false;mqShowRes=true;mqResT=millis();mqRedraw();delay(5);return;}
  // Timer bar
  if(mqActive){static uint32_t mtl=0;if(millis()-mtl>100){mtl=millis();uint32_t el=millis()-mqTStart;int pct=max(0,(int)(100-el*100/MQTIME));
    lcd.fillRoundRect(80,300,320,15,6,0x333333);int w=pct*316/100;if(w>0)lcd.fillRoundRect(82,302,w,11,5,pct>30?0x4CAF50:0xF44336);}}
  // Keypad
  if(!ngH&&tOnce(&tx,&ty)&&mqActive){int kx=PX+10,ky=200;for(int i=0;i<12;i++){int r=i/3,c=i%3,bx=kx+c*105,by=ky+r*55;
    if(tx>=bx&&tx<bx+95&&ty>=by&&ty<by+48){if(i==9){if(mqIL>0){mqIL--;mqIn[mqIL]=0;}}
      else if(i==11){if(mqIL>0){int ans=atoi(mqIn);mqCorrect=(ans==mqAns);mqActive=false;mqShowRes=true;mqResT=millis();}}
      else{int d=(i<9)?i+1:0;if(mqIL<8){mqIn[mqIL++]='0'+d;mqIn[mqIL]=0;}}mqRedraw();break;}}}}

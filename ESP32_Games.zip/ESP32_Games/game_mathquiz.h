#pragma once
// Math Quiz - Ready button before each question, 35s timer (was 25s)
static int mqPl,mqCr;static int mqSc[3];static bool mqGO=false;
static int mqA,mqB,mqAns,mqType=0;
static char mqQ[32]="";static char mqIn[12]="";static int mqIL=0;
static uint32_t mqTStart;static bool mqActive=false;
static char mqSt[64]="";static bool mqShowRes=false;static uint32_t mqResT=0;static bool mqCorrect=false;
static int mqPassCnt=0;
static bool mqReady=false; // false = waiting for Ready tap; true = question active
#define MQTIME 35000        // 35 seconds (was 25)
static int dsum(int n){int s=0;n=abs(n);while(n>0){s+=n%10;n/=10;}return s;}
static void mqGenQ(){
  mqIL=0;mqIn[0]=0;mqActive=false;mqReady=false;mqCorrect=false;mqShowRes=false;mqPassCnt=0;
  switch(mqType){
    case 0:{do{mqA=random(10,99);mqB=random(10,99);}while(dsum(mqA)+dsum(mqB)<=10);mqAns=mqA+mqB;sprintf(mqQ,"%d + %d = ?",mqA,mqB);break;}
    case 1:{do{mqA=random(10,99);mqB=random(10,99);}while(dsum(mqA)+dsum(mqB)<=10||mqA<mqB);mqAns=mqA-mqB;sprintf(mqQ,"%d - %d = ?",mqA,mqB);break;}
    case 2:{do{mqA=random(100,999);mqB=random(100,999);}while(dsum(mqA)+dsum(mqB)<=10);mqAns=mqA+mqB;sprintf(mqQ,"%d + %d = ?",mqA,mqB);break;}
    case 3:{do{mqA=random(100,999);mqB=random(100,999);}while(dsum(mqA)+dsum(mqB)<=10||mqA<mqB);mqAns=mqA-mqB;sprintf(mqQ,"%d - %d = ?",mqA,mqB);break;}
    case 4:{mqA=random(2,10);mqB=random(2,10);mqAns=mqA*mqB;sprintf(mqQ,"%d x %d = ?",mqA,mqB);break;}
    case 5:{mqB=random(2,10);mqAns=random(2,10);mqA=mqB*mqAns;sprintf(mqQ,"%d / %d = ?",mqA,mqB);break;}}}
static void mqInit(int pl,int type){randomSeed(millis());mqPl=pl;mqCr=0;memset(mqSc,0,12);mqGO=false;mqType=type;mqGenQ();strcpy(mqSt,"Player 1");}
static void mqDrawKeypad(){
  int kx=PX+10,ky=200;
  for(int i=0;i<12;i++){int r=i/3,c=i%3,bx=kx+c*105,by=ky+r*55;
    const char*lb[]={"1","2","3","4","5","6","7","8","9","<","0","OK"};
    uint32_t bg=(i==9)?DANGER:(i==11)?PGN:SURF2;
    uint32_t bd=(i==9)?SRED:(i==11)?PGNB:BORD;
    bool en=mqActive&&!mqShowRes;
    if(!en){bg=SURF;bd=BORD;}
    lcd.fillRoundRect(bx,by,95,48,8,bg);lcd.drawRoundRect(bx,by,95,48,8,bd);
    lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(en?TX:TXD);
    lcd.drawCenterString(lb[i],bx+47,by+12);}}
static void mqDrawReadyBtn(){
  // Big "Ready" button covering the keypad area when not active
  lcd.fillRect(PX,200,PW,330,BGC);
  int bx=PX+30,by=260,bw=PW-60,bh=140;
  lcd.fillRoundRect(bx,by,bw,bh,16,PGN);
  lcd.drawRoundRect(bx,by,bw,bh,16,PGNB);
  lcd.drawRoundRect(bx+2,by+2,bw-4,bh-4,15,PGNB);
  lcd.setFont(&fonts::FreeSansBold24pt7b);lcd.setTextColor(TX);
  lcd.drawCenterString("READY?",bx+bw/2,by+30);
  lcd.setFont(&fonts::FreeSans9pt7b);lcd.setTextColor(0xCCFFCC);
  lcd.drawCenterString("Tap to reveal question",bx+bw/2,by+85);
  lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(0xCCFFCC);
  lcd.drawCenterString("35s timer starts on tap",bx+bw/2,by+105);
}
static void mqRedraw(){
  lcd.fillScreen(BGC);
  // Left side - question area
  lcd.fillRect(0,0,480,480,SURF);
  // Player tag
  lcd.fillRoundRect(20,15,200,40,8,SURF2);
  lcd.drawRoundRect(20,15,200,40,8,BORD);
  lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(GOLD);
  char plb[20];sprintf(plb,"PLAYER %d",mqCr+1);lcd.drawString(plb,40,23);
  // Question or hidden
  if(mqReady){
    lcd.setFont(&fonts::FreeSansBold24pt7b);lcd.setTextColor(SYLW);
    lcd.drawCenterString(mqQ,240,130);
    // Input box
    lcd.fillRoundRect(80,220,320,60,10,SURF2);lcd.drawRoundRect(80,220,320,60,10,BORD2);
    lcd.setFont(&fonts::FreeSansBold24pt7b);lcd.setTextColor(TX);
    lcd.drawCenterString(mqIL>0?mqIn:"_",240,232);
    // Timer bar
    if(mqActive){uint32_t el=millis()-mqTStart;int pct=max(0,(int)(100-el*100/MQTIME));
      lcd.fillRoundRect(80,300,320,15,6,SURF);int w=pct*316/100;
      if(w>0)lcd.fillRoundRect(82,302,w,11,5,pct>30?SGRN:DANGER);}
  } else {
    // Question hidden - show ready prompt on left side
    lcd.fillRoundRect(60,100,360,140,16,SURF2);
    lcd.drawRoundRect(60,100,360,140,16,BORD);
    lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(GOLD);
    lcd.drawCenterString("Question Hidden",240,130);
    lcd.setFont(&fonts::FreeSans9pt7b);lcd.setTextColor(TXD);
    lcd.drawCenterString("Tap READY on the right",240,175);
    lcd.drawCenterString("when you are prepared",240,200);
  }
  // Result feedback
  if(mqShowRes){
    lcd.fillRoundRect(80,355,320,50,10,mqCorrect?PGN:DANGER);
    lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(TX);
    if(mqCorrect)lcd.drawCenterString("Correct!",240,367);
    else{char wb[40];sprintf(wb,"Wrong! Ans: %d",mqAns);lcd.drawCenterString(wb,240,367);}
  }
  // Right panel
  lcd.fillRect(PX,0,PW,480,BGC);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(GOLD);
  lcd.drawCenterString("MATH QUIZ",PX+PW/2,15);
  uint32_t pc[]={SRED,SBLU,SGRN};
  for(int i=0;i<mqPl;i++){int y=60+i*45;
    lcd.fillRoundRect(PX+15,y,PW-30,38,8,i==mqCr?pc[i]:SURF2);
    lcd.drawRoundRect(PX+15,y,PW-30,38,8,i==mqCr?pc[i]:BORD);
    lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(i==mqCr?TX:TXD);
    char buf[20];sprintf(buf,"P%d",i+1);lcd.drawString(buf,PX+25,y+8);
    char sb[20];sprintf(sb,"%d/10",mqSc[i]);
    lcd.drawString(sb,PX+200,y+8);}
  if(mqReady)mqDrawKeypad();
  else mqDrawReadyBtn();
  lcd.fillRect(PX,430,PW,50,BGC);drawNGBtn(PX,430,PW,50);
  if(mqGO){
    lcd.fillRect(PX+10,170,PW-20,28,BGC);
    lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(GOLD);
    lcd.drawCenterString(mqSt,PX+PW/2,175);}
}
void mq_drawOpt(){
  lcd.fillScreen(BGC);
  lcd.fillRect(0,0,800,42,SURF);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(GOLD);
  lcd.drawCenterString("MATH QUIZ",400,8);
  // Players
  lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);lcd.drawString("Players:",100,70);
  for(int i=0;i<2;i++){int bx=250+i*150,by=60;
    lcd.fillRoundRect(bx,by,120,45,10,SURF2);lcd.drawRoundRect(bx,by,120,45,10,BORD);
    char s[2];sprintf(s,"%d",i+2);
    lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(TX);lcd.drawCenterString(s,bx+60,by+8);}
  lcd.drawRoundRect(250,60,120,45,10,GOLD);
  // Quiz Type
  lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);lcd.drawString("Quiz Type:",100,135);
  const char*tp[]={"2-Digit +","2-Digit -","3-Digit +","3-Digit -","Multiply","Division"};
  uint32_t qc[]={SGRN,SRED,STEA,SCOR,SPRP,SBLU};
  for(int i=0;i<6;i++){int bx=30+(i%3)*260,by=175+(i/3)*90;
    lcd.fillRoundRect(bx,by,240,70,12,SURF2);lcd.drawRoundRect(bx,by,240,70,12,BORD);
    lcd.fillRect(bx+15,by+10,5,50,qc[i]);
    lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);
    lcd.drawCenterString(tp[i],bx+130,by+22);}
  lcd.setFont(&fonts::FreeSans9pt7b);lcd.setTextColor(TXD);
  lcd.drawCenterString("Tap Ready before each question  -  35s per question",400,400);}
static int mqSelPl=2;
void mq_handleOpt(int16_t tx,int16_t ty){
  for(int i=0;i<2;i++){int bx=250+i*150,by=60;if(tx>=bx&&tx<bx+120&&ty>=by&&ty<by+45){
    mqSelPl=i+2;
    lcd.drawRoundRect(250,60,120,45,10,BORD);lcd.drawRoundRect(400,60,120,45,10,BORD);
    lcd.drawRoundRect(bx,by,120,45,10,GOLD);return;}}
  for(int i=0;i<6;i++){int bx=30+(i%3)*260,by=175+(i/3)*90;if(tx>=bx&&tx<bx+240&&ty>=by&&ty<by+70){
    mqInit(mqSelPl,i);appState=2;mqRedraw();return;}}}
void mq_loop(){
  int16_t tx,ty,rx,ry;bool tch=tRaw(&rx,&ry);if(doNG(PX,430,PW,50,rx,ry,tch))return;
  if(mqGO){delay(20);return;}
  // Result pause
  if(mqShowRes){
    if(millis()-mqResT>1500){mqShowRes=false;
      if(mqCorrect){mqPassCnt=0;mqSc[mqCr]++;
        if(mqSc[mqCr]>=10){mqGO=true;sprintf(mqSt,"Player %d wins!",mqCr+1);mqRedraw();return;}
        mqCr=(mqCr+1)%mqPl;mqGenQ();}
      else{mqPassCnt++;
        if(mqPassCnt>=mqPl*2){mqPassCnt=0;mqCr=(mqCr+1)%mqPl;mqGenQ();}
        else{mqCr=(mqCr+1)%mqPl;mqIL=0;mqIn[0]=0;mqReady=false;mqActive=false;}}
      sprintf(mqSt,"Player %d",mqCr+1);mqRedraw();}
    delay(5);return;}
  // Timer expired
  if(mqActive&&millis()-mqTStart>=MQTIME){
    mqActive=false;mqCorrect=false;mqShowRes=true;mqResT=millis();mqRedraw();delay(5);return;}
  // Timer bar redraw while active
  if(mqActive){static uint32_t mtl=0;if(millis()-mtl>100){mtl=millis();
    uint32_t el=millis()-mqTStart;int pct=max(0,(int)(100-el*100/MQTIME));
    lcd.fillRoundRect(80,300,320,15,6,SURF);int w=pct*316/100;
    if(w>0)lcd.fillRoundRect(82,302,w,11,5,pct>30?SGRN:DANGER);}}
  // Touch handling
  if(!ngH&&tOnce(&tx,&ty)){
    // Ready button (only when not ready yet)
    if(!mqReady){
      int bx=PX+30,by=260,bw=PW-60,bh=140;
      if(tx>=bx&&tx<bx+bw&&ty>=by&&ty<by+bh){
        mqReady=true;mqActive=true;mqTStart=millis();mqRedraw();return;}
    }
    // Keypad (only when active)
    if(mqActive&&mqReady){
      int kx=PX+10,ky=200;
      for(int i=0;i<12;i++){int r=i/3,c=i%3,bx=kx+c*105,by=ky+r*55;
        if(tx>=bx&&tx<bx+95&&ty>=by&&ty<by+48){
          if(i==9){if(mqIL>0){mqIL--;mqIn[mqIL]=0;}}
          else if(i==11){if(mqIL>0){int ans=atoi(mqIn);mqCorrect=(ans==mqAns);mqActive=false;mqShowRes=true;mqResT=millis();}}
          else{int d=(i<9)?i+1:0;if(mqIL<8){mqIn[mqIL++]='0'+d;mqIn[mqIL]=0;}}
          mqRedraw();return;}}}}
}

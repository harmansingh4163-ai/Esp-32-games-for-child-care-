#pragma once
// Bingo Wheel - Spinning needle on a disk with 8 symbols.
// Each player has a card of 4 unique symbols. On their turn they spin.
// If the wheel lands on a symbol on their card, mark it. First to mark all 4 wins.
// Symbols: 0=Star 1=Heart 2=Diamond 3=Circle 4=Square 5=Triangle 6=Moon 7=Sun
static int bgCard[2][4]; // each player's 4 symbols
static bool bgHit[2][4];
static int bgCr=0;
static bool bgGO=false;
static char bgSt[64]="";
static bool bgSpin=false;
static uint32_t bgSpinStart=0;
static float bgAng=0; // current needle angle (degrees)
static float bgFinal=0; // target final angle
static float bgSpinDur=2200.0; // ms
static int bgLanded=-1;
static uint32_t bgShowT=0;
static bool bgShowing=false;
static int bgWheelCX=240,bgWheelCY=240;
static int bgWheelR=170;
static uint32_t bgSymCl[]={SYLW,SRED,SPRP,SBLU,SGRN,SORG,STEA,GOLD};
static const char*bgSymName[]={"Star","Heart","Diamond","Circle","Square","Triangle","Moon","Sun"};

// ---- Symbol drawing primitives ----
static void bgDrawStar(int cx,int cy,int sz,uint32_t cl){
  // 5-point star
  int x[10],y[10];
  for(int i=0;i<10;i++){
    float a=-PI/2+i*PI/5;
    int r=(i%2==0)?sz:sz/2;
    x[i]=cx+cos(a)*r;y[i]=cy+sin(a)*r;}
  for(int i=0;i<10;i++){
    int n=(i+1)%10;
    lcd.fillTriangle(cx,cy,x[i],y[i],x[n],y[n],cl);}}
static void bgDrawHeart(int cx,int cy,int sz,uint32_t cl){
  int r=sz/2;
  lcd.fillCircle(cx-r/2,cy-r/4,r-1,cl);
  lcd.fillCircle(cx+r/2,cy-r/4,r-1,cl);
  lcd.fillTriangle(cx-r,cy-r/8,cx+r,cy-r/8,cx,cy+r,cl);}
static void bgDrawDiamond(int cx,int cy,int sz,uint32_t cl){
  lcd.fillTriangle(cx,cy-sz,cx-sz,cy,cx+sz,cy,cl);
  lcd.fillTriangle(cx,cy+sz,cx-sz,cy,cx+sz,cy,cl);}
static void bgDrawCircleSym(int cx,int cy,int sz,uint32_t cl){
  lcd.fillCircle(cx,cy,sz,cl);
  lcd.fillCircle(cx,cy,sz-5,BGC);
  lcd.fillCircle(cx,cy,sz-9,cl);}
static void bgDrawSquare(int cx,int cy,int sz,uint32_t cl){
  lcd.fillRect(cx-sz,cy-sz,sz*2,sz*2,cl);
  lcd.fillRect(cx-sz+4,cy-sz+4,sz*2-8,sz*2-8,BGC);
  lcd.fillRect(cx-sz+8,cy-sz+8,sz*2-16,sz*2-16,cl);}
static void bgDrawTriangle(int cx,int cy,int sz,uint32_t cl){
  lcd.fillTriangle(cx,cy-sz,cx-sz,cy+sz-2,cx+sz,cy+sz-2,cl);}
static void bgDrawMoon(int cx,int cy,int sz,uint32_t cl){
  lcd.fillCircle(cx,cy,sz,cl);
  lcd.fillCircle(cx+sz/3,cy-sz/4,sz-2,BGC);}
static void bgDrawSun(int cx,int cy,int sz,uint32_t cl){
  // Center disk
  lcd.fillCircle(cx,cy,sz/2+1,cl);
  // 8 rays
  for(int i=0;i<8;i++){
    float a=i*PI/4;
    int x1=cx+cos(a)*(sz/2+3),y1=cy+sin(a)*(sz/2+3);
    int x2=cx+cos(a)*sz,y2=cy+sin(a)*sz;
    for(int t=-1;t<=1;t++){
      float pa=a+PI/2;
      int dx=cos(pa)*t,dy=sin(pa)*t;
      lcd.drawLine(x1+dx,y1+dy,x2+dx,y2+dy,cl);}}}

static void bgDrawSymbol(int cx,int cy,int sz,int type,uint32_t cl){
  switch(type){
    case 0:bgDrawStar(cx,cy,sz,cl);break;
    case 1:bgDrawHeart(cx,cy,sz,cl);break;
    case 2:bgDrawDiamond(cx,cy,sz,cl);break;
    case 3:bgDrawCircleSym(cx,cy,sz,cl);break;
    case 4:bgDrawSquare(cx,cy,sz-2,cl);break;
    case 5:bgDrawTriangle(cx,cy,sz,cl);break;
    case 6:bgDrawMoon(cx,cy,sz,cl);break;
    case 7:bgDrawSun(cx,cy,sz,cl);break;}}

static void bgInit(){
  randomSeed(millis());
  bgCr=0;bgGO=false;bgSpin=false;bgShowing=false;bgAng=0;bgLanded=-1;
  for(int p=0;p<2;p++)for(int i=0;i<4;i++)bgHit[p][i]=false;
  // Deal 4 unique symbols to each player. Allow overlap between players.
  for(int p=0;p<2;p++){
    int pool[8]={0,1,2,3,4,5,6,7};
    for(int i=7;i>0;i--){int j=random(0,i+1);int t=pool[i];pool[i]=pool[j];pool[j]=t;}
    for(int i=0;i<4;i++)bgCard[p][i]=pool[i];}
  sprintf(bgSt,"P1 to spin");
}

static void bgDrawWheel(){
  // Outer ring
  lcd.fillCircle(bgWheelCX,bgWheelCY,bgWheelR+10,SURF2);
  lcd.fillCircle(bgWheelCX,bgWheelCY,bgWheelR+4,SURF);
  // 8 segments
  for(int i=0;i<8;i++){
    float a1=(i*45-90-22.5)*PI/180;
    float a2=((i+1)*45-90-22.5)*PI/180;
    // Sector approximation: many thin triangles
    for(int j=0;j<14;j++){
      float t1=a1+(a2-a1)*j/14;
      float t2=a1+(a2-a1)*(j+1)/14;
      int x1=bgWheelCX+cos(t1)*bgWheelR,y1=bgWheelCY+sin(t1)*bgWheelR;
      int x2=bgWheelCX+cos(t2)*bgWheelR,y2=bgWheelCY+sin(t2)*bgWheelR;
      uint32_t sc=bgSymCl[i];
      // Darken alternate slightly
      lcd.fillTriangle(bgWheelCX,bgWheelCY,x1,y1,x2,y2,sc);
    }
    // Symbol in segment
    float ma=(a1+a2)/2;
    int sx=bgWheelCX+cos(ma)*(bgWheelR-50);
    int sy=bgWheelCY+sin(ma)*(bgWheelR-50);
    bgDrawSymbol(sx,sy,18,i,BGC);
  }
  // Dividing lines
  for(int i=0;i<8;i++){
    float a=(i*45-90-22.5)*PI/180;
    int x=bgWheelCX+cos(a)*bgWheelR,y=bgWheelCY+sin(a)*bgWheelR;
    lcd.drawLine(bgWheelCX,bgWheelCY,x,y,SURF);}
  // Outer rim
  lcd.drawCircle(bgWheelCX,bgWheelCY,bgWheelR,BORD2);
  lcd.drawCircle(bgWheelCX,bgWheelCY,bgWheelR+4,BORD);
}

static void bgDrawNeedle(float angDeg){
  float a=(angDeg-90)*PI/180; // pointing up at 0deg
  int tipx=bgWheelCX+cos(a)*(bgWheelR-15);
  int tipy=bgWheelCY+sin(a)*(bgWheelR-15);
  float pa=a+PI/2;
  int bx1=bgWheelCX+cos(pa)*10,by1=bgWheelCY+sin(pa)*10;
  int bx2=bgWheelCX-cos(pa)*10,by2=bgWheelCY-sin(pa)*10;
  // Tail
  int taila=a+PI;
  int taex=bgWheelCX+cos(taila)*25,taey=bgWheelCY+sin(taila)*25;
  // Draw needle as triangle + tail
  lcd.fillTriangle(tipx,tipy,bx1,by1,bx2,by2,TX);
  lcd.fillTriangle(bx1,by1,bx2,by2,taex,taey,SURF2);
  // Center hub
  lcd.fillCircle(bgWheelCX,bgWheelCY,16,SURF);
  lcd.drawCircle(bgWheelCX,bgWheelCY,16,GOLD);
  lcd.fillCircle(bgWheelCX,bgWheelCY,8,GOLD);
}

static void bgDrawBoard(){
  lcd.fillRect(0,0,480,480,BGC);
  bgDrawWheel();
  bgDrawNeedle(bgAng);
}

static void bgDrawCardPanel(int p,int y){
  bool cur=(p==bgCr&&!bgGO);
  uint32_t bg=cur?SURF2:SURF;
  uint32_t bd=cur?GOLD:BORD;
  lcd.fillRoundRect(PX+15,y,PW-30,130,12,bg);
  lcd.drawRoundRect(PX+15,y,PW-30,130,12,bd);
  lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(cur?GOLD:TXD);
  char b[20];sprintf(b,"PLAYER %d",p+1);
  lcd.drawString(b,PX+25,y+8);
  // Mark count
  int mc=0;for(int i=0;i<4;i++)if(bgHit[p][i])mc++;
  char mb[12];sprintf(mb,"%d/4",mc);
  lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(cur?GOLD:TXD);
  lcd.drawString(mb,PX+PW-65,y+8);
  // 4 symbol slots
  for(int i=0;i<4;i++){
    int sx=PX+30+i*65;int sy=y+45;
    if(bgHit[p][i]){
      lcd.fillRoundRect(sx,sy,55,55,8,bgSymCl[bgCard[p][i]]);
      lcd.drawRoundRect(sx,sy,55,55,8,GOLD);
      bgDrawSymbol(sx+28,sy+28,17,bgCard[p][i],SURF);
      // Checkmark indication
      lcd.drawLine(sx+10,sy+30,sx+22,sy+42,GOLD);
      lcd.drawLine(sx+22,sy+42,sx+45,sy+15,GOLD);
      lcd.drawLine(sx+10,sy+31,sx+22,sy+43,GOLD);
      lcd.drawLine(sx+22,sy+43,sx+45,sy+16,GOLD);
    } else {
      lcd.fillRoundRect(sx,sy,55,55,8,SURF);
      lcd.drawRoundRect(sx,sy,55,55,8,BORD);
      bgDrawSymbol(sx+28,sy+28,17,bgCard[p][i],bgSymCl[bgCard[p][i]]);
    }
  }
}

static void bgDrawPanels(){
  lcd.fillRect(PX,0,PW,480,BGC);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(GOLD);
  lcd.drawCenterString("BINGO WHEEL",PX+PW/2,12);
  bgDrawCardPanel(0,45);
  bgDrawCardPanel(1,185);
  // Spin button
  if(!bgGO){
    uint32_t bbg=bgSpin?SURF:PGN;
    uint32_t bbd=bgSpin?BORD:PGNB;
    lcd.fillRoundRect(PX+30,330,PW-60,55,14,bbg);
    lcd.drawRoundRect(PX+30,330,PW-60,55,14,bbd);
    lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(TX);
    lcd.drawCenterString(bgSpin?"SPINNING...":"TAP TO SPIN",PX+PW/2,345);
  }
  // Status text
  lcd.fillRect(PX+10,395,PW-20,30,BGC);
  if(bgShowing&&bgLanded>=0){
    lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(bgSymCl[bgLanded]);
    char b[40];sprintf(b,"Landed: %s",bgSymName[bgLanded]);
    lcd.drawCenterString(b,PX+PW/2,400);
  } else if(!bgGO){
    lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TXD);
    lcd.drawCenterString(bgSt,PX+PW/2,400);
  } else {
    lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(GOLD);
    lcd.drawCenterString(bgSt,PX+PW/2,398);
  }
  drawNGBtn(PX,430,PW,50);
}

void bg_drawOpt(){
  lcd.fillScreen(BGC);
  lcd.fillRect(0,0,800,42,SURF);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(GOLD);
  lcd.drawCenterString("BINGO WHEEL",400,8);
  // Info card
  lcd.fillRoundRect(80,75,640,220,16,SURF);lcd.drawRoundRect(80,75,640,220,16,BORD);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(GOLD);
  lcd.drawString("How to play",100,90);
  lcd.setFont(&fonts::FreeSans9pt7b);lcd.setTextColor(TX);
  lcd.drawString("- Each player gets a card with 4 random symbols.",100,135);
  lcd.drawString("- On your turn, tap SPIN. The wheel lands on a symbol.",100,160);
  lcd.drawString("- If that symbol is on YOUR card, it gets marked.",100,185);
  lcd.drawString("- First player to mark all 4 wins.",100,210);
  lcd.drawString("- Symbols on the wheel: Star, Heart, Diamond, Circle,",100,235);
  lcd.drawString("  Square, Triangle, Moon, Sun.",100,255);
  // Start button
  drawSoftBtn(280,335,240,70,PGN,PGNB,"START GAME",TX,&fonts::FreeSansBold18pt7b);
}

void bg_handleOpt(int16_t tx,int16_t ty){
  if(tx>=280&&tx<520&&ty>=335&&ty<405){
    bgInit();appState=2;lcd.fillScreen(BGC);bgDrawBoard();bgDrawPanels();}
}

void bg_loop(){
  int16_t tx,ty,rx,ry;bool tch=tRaw(&rx,&ry);
  if(doNG(PX,430,PW,50,rx,ry,tch))return;
  if(bgGO){delay(20);return;}
  // Spinning animation
  if(bgSpin){
    uint32_t el=millis()-bgSpinStart;
    if(el>=bgSpinDur){
      bgSpin=false;
      bgAng=bgFinal;
      // Determine landed segment from angle
      // Angle 0 = pointing up = segment 0 (Star)
      float a=fmod(bgAng,360.0);if(a<0)a+=360;
      // Each segment is 45 deg, centered at 0, 45, 90...
      // Segment i covers [i*45-22.5, i*45+22.5]
      float aa=a+22.5;if(aa>=360)aa-=360;
      bgLanded=((int)(aa/45))%8;
      // Check if matches current player's card
      bool matched=false;int slot=-1;
      for(int i=0;i<4;i++)if(bgCard[bgCr][i]==bgLanded&&!bgHit[bgCr][i]){
        bgHit[bgCr][i]=true;matched=true;slot=i;break;}
      // Check win
      bool win=true;for(int i=0;i<4;i++)if(!bgHit[bgCr][i])win=false;
      bgShowing=true;bgShowT=millis();
      if(win){bgGO=true;sprintf(bgSt,"Player %d wins!",bgCr+1);}
      else if(matched){sprintf(bgSt,"P%d marked %s!",bgCr+1,bgSymName[bgLanded]);}
      else{sprintf(bgSt,"P%d: No match",bgCr+1);}
      bgDrawBoard();bgDrawPanels();
    } else {
      // Ease-out animation
      float t=el/bgSpinDur;
      float eased=1-(1-t)*(1-t)*(1-t);
      bgAng=eased*bgFinal;
      static uint32_t lastA=0;
      if(millis()-lastA>40){lastA=millis();bgDrawBoard();}
    }
    return;
  }
  // After landed - show result for ~1.5s then advance turn
  if(bgShowing&&!bgGO&&millis()-bgShowT>1800){
    bgShowing=false;
    bgCr=1-bgCr;
    sprintf(bgSt,"P%d to spin",bgCr+1);
    bgDrawPanels();
  }
  if(!ngH&&tOnce(&tx,&ty)){
    // Spin button
    if(!bgSpin&&!bgShowing&&tx>=PX+30&&tx<PX+PW-30&&ty>=330&&ty<385){
      bgSpin=true;bgSpinStart=millis();
      // Pick a random target landing segment, add several full rotations
      int seg=random(0,8);
      bgFinal=fmod(bgAng,360);
      // Add 4-6 full turns plus offset to land in segment center
      int spins=4+random(0,3);
      bgFinal=spins*360+seg*45;
      // Add slight random offset within segment (-20..+20 deg from center)
      bgFinal+=random(-18,19);
      bgDrawPanels();return;
    }
  }
}

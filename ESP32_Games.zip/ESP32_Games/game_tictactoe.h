#pragma once
// Tic Tac Toe - Classic + Vanishing (3-piece) variant
static int8_t ttB[3][3];static bool ttXT,ttGO;static char ttSt[64]="";
static int ttVar=0; // 0=Classic, 1=Vanishing
// Vanishing variant queues: positions in order placed (oldest first)
static int8_t ttQR[2][3]; // row of each queued piece
static int8_t ttQC[2][3]; // col
static int ttQS[2]; // queue size (0..3)
#define TTCL 140
static void ttInit(){
  memset(ttB,0,9);ttXT=true;ttGO=false;
  ttQS[0]=ttQS[1]=0;
  strcpy(ttSt,"X's Turn");
}
static int ttCheck(){
  for(int i=0;i<3;i++){
    if(ttB[i][0]&&ttB[i][0]==ttB[i][1]&&ttB[i][1]==ttB[i][2])return ttB[i][0];
    if(ttB[0][i]&&ttB[0][i]==ttB[1][i]&&ttB[1][i]==ttB[2][i])return ttB[0][i];}
  if(ttB[0][0]&&ttB[0][0]==ttB[1][1]&&ttB[1][1]==ttB[2][2])return ttB[0][0];
  if(ttB[0][2]&&ttB[0][2]==ttB[1][1]&&ttB[1][1]==ttB[2][0])return ttB[0][2];
  return 0;}
static bool ttFull(){for(int r=0;r<3;r++)for(int c=0;c<3;c++)if(!ttB[r][c])return false;return true;}
// Check if a piece is the oldest of its player (next to vanish) - only in Vanishing variant
static bool ttIsOldest(int r,int c){
  if(ttVar!=1)return false;
  int p=ttB[r][c];if(!p)return false;
  int pi=p-1;
  if(ttQS[pi]<3)return false; // only fade when queue is full
  return (ttQR[pi][0]==r&&ttQC[pi][0]==c);
}
static void ttDrawBoard(){
  int ox=(480-3*TTCL)/2,oy=(480-3*TTCL)/2;
  lcd.fillRect(0,0,480,480,SURF);
  for(int r=0;r<3;r++)for(int c=0;c<3;c++){
    int x=ox+c*TTCL,y=oy+r*TTCL;
    lcd.fillRoundRect(x+4,y+4,TTCL-8,TTCL-8,12,0xFFFFFF);
    lcd.drawRoundRect(x+4,y+4,TTCL-8,TTCL-8,12,BORD);
    if(ttB[r][c]){
      // Piece colors gentle; only the next-to-vanish piece gets two RED rings
      uint32_t col=(ttB[r][c]==1)?SRED:SBLU;
      lcd.setFont(&fonts::FreeSansBold24pt7b);lcd.setTextColor(col);
      lcd.drawCenterString(ttB[r][c]==1?"X":"O",x+TTCL/2,y+TTCL/2-22);
      // If oldest in vanishing mode, draw two RED warning circles around it
      if(ttIsOldest(r,c)){
        int cx=x+TTCL/2,cy=y+TTCL/2;
        for(int t=0;t<3;t++){
          lcd.drawCircle(cx,cy,58-t,DANGER);
          lcd.drawCircle(cx,cy,50-t,DANGER);
        }
      }
    }
  }
}
static void ttDrawPanels(){
  lcd.fillRect(PX,0,PW,480,BGC);
  lcd.fillRect(PX,0,PW,42,SURF2);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(TX);
  lcd.drawCenterString("TIC TAC TOE",PX+PW/2,8);
  lcd.setFont(&fonts::FreeSans9pt7b);lcd.setTextColor(GOLD);
  lcd.drawCenterString(ttVar==0?"Classic":"Vanishing (3-piece)",PX+PW/2,50);
  bool xA=ttXT&&!ttGO;bool oA=!ttXT&&!ttGO;
  // X card - light surface, gentle red accent
  lcd.fillRoundRect(PX+20,75,PW-40,90,12,0xFFFFFF);
  lcd.drawRoundRect(PX+20,75,PW-40,90,12,SRED);
  if(xA){for(int i=0;i<4;i++)lcd.drawRoundRect(PX+20-i,75-i,PW-40+i*2,90+i*2,12,YLBORD);}
  lcd.setFont(&fonts::FreeSansBold24pt7b);lcd.setTextColor(SRED);
  lcd.drawString("X",PX+45,90);
  lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TXK);
  lcd.drawString(xA?"Your turn":"Player X",PX+105,100);
  if(ttVar==1){
    char b[20];sprintf(b,"On board: %d/3",ttQS[0]);
    lcd.setFont(&fonts::FreeSans9pt7b);lcd.setTextColor(TXK);
    lcd.drawString(b,PX+105,130);}
  // O card
  lcd.fillRoundRect(PX+20,175,PW-40,90,12,0xFFFFFF);
  lcd.drawRoundRect(PX+20,175,PW-40,90,12,SBLU);
  if(oA){for(int i=0;i<4;i++)lcd.drawRoundRect(PX+20-i,175-i,PW-40+i*2,90+i*2,12,YLBORD);}
  lcd.setFont(&fonts::FreeSansBold24pt7b);lcd.setTextColor(SBLU);
  lcd.drawString("O",PX+45,190);
  lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TXK);
  lcd.drawString(oA?"Your turn":"Player O",PX+105,200);
  if(ttVar==1){
    char b[20];sprintf(b,"On board: %d/3",ttQS[1]);
    lcd.setFont(&fonts::FreeSans9pt7b);lcd.setTextColor(TXK);
    lcd.drawString(b,PX+105,230);}
  if(ttGO){
    lcd.fillRoundRect(PX+20,285,PW-40,60,12,GOLD);
    lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(TXK);
    lcd.drawCenterString(ttSt,PX+PW/2,300);}
  if(ttVar==1&&!ttGO){
    lcd.setFont(&fonts::FreeSans9pt7b);lcd.setTextColor(DANGER);
    lcd.drawCenterString("Red rings = vanishes next",PX+PW/2,360);}
  lcd.fillRect(PX,400,PW,60,BGC);drawNGBtn(PX,400,PW,60);
}
// Place piece in current player's queue, handle vanishing rule
static void ttPlace(int r,int c){
  int pi=ttXT?0:1;
  if(ttVar==1&&ttQS[pi]==3){
    // Remove oldest piece from board
    int or_=ttQR[pi][0],oc=ttQC[pi][0];
    ttB[or_][oc]=0;
    // Shift queue
    ttQR[pi][0]=ttQR[pi][1];ttQC[pi][0]=ttQC[pi][1];
    ttQR[pi][1]=ttQR[pi][2];ttQC[pi][1]=ttQC[pi][2];
    ttQS[pi]=2;
  }
  ttB[r][c]=ttXT?1:2;
  if(ttVar==1){
    ttQR[pi][ttQS[pi]]=r;ttQC[pi][ttQS[pi]]=c;ttQS[pi]++;
  }
}
void tt_drawOpt(){
  lcd.fillScreen(BGC);
  lcd.fillRect(0,0,800,42,SURF);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(GOLD);
  lcd.drawCenterString("TIC TAC TOE",400,8);
  lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);
  lcd.drawCenterString("Choose Variant",400,80);
  // Classic
  int bx1=80,by1=140;
  lcd.fillRoundRect(bx1,by1,310,250,16,SURF2);lcd.drawRoundRect(bx1,by1,310,250,16,BORD);
  lcd.fillRect(bx1+20,by1+20,8,40,SPNK);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(SPNK);
  lcd.drawString("CLASSIC",bx1+50,by1+25);
  lcd.setFont(&fonts::FreeSans9pt7b);lcd.setTextColor(TXD);
  lcd.drawString("The original game.",bx1+25,by1+75);
  lcd.drawString("Place X or O.",bx1+25,by1+95);
  lcd.drawString("Three in a row wins.",bx1+25,by1+115);
  lcd.drawString("Board can fill up to 9.",bx1+25,by1+135);
  drawSoftBtn(bx1+55,by1+190,200,45,PGN,PGNB,"PLAY CLASSIC");
  // Vanishing
  int bx2=410,by2=140;
  lcd.fillRoundRect(bx2,by2,310,250,16,SURF2);lcd.drawRoundRect(bx2,by2,310,250,16,BORD);
  lcd.fillRect(bx2+20,by2+20,8,40,SBLU);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(SBLU);
  lcd.drawString("VANISHING",bx2+50,by2+25);
  lcd.setFont(&fonts::FreeSans9pt7b);lcd.setTextColor(TXD);
  lcd.drawString("Only 3 pieces per player.",bx2+25,by2+75);
  lcd.drawString("Your 4th placement makes",bx2+25,by2+95);
  lcd.drawString("your OLDEST piece vanish.",bx2+25,by2+115);
  lcd.drawString("Faded ring = next to go.",bx2+25,by2+135);
  drawSoftBtn(bx2+55,by2+190,200,45,PGN,PGNB,"PLAY VANISHING");
}
void tt_handleOpt(int16_t tx,int16_t ty){
  // Classic
  if(tx>=80+55&&tx<80+255&&ty>=140+190&&ty<140+235){
    ttVar=0;ttInit();appState=2;lcd.fillScreen(BGC);ttDrawBoard();ttDrawPanels();return;}
  // Vanishing
  if(tx>=410+55&&tx<410+255&&ty>=140+190&&ty<140+235){
    ttVar=1;ttInit();appState=2;lcd.fillScreen(BGC);ttDrawBoard();ttDrawPanels();return;}
}
void tt_loop(){
  int16_t tx,ty,rx,ry;bool tch=tRaw(&rx,&ry);
  if(doNG(PX,400,PW,60,rx,ry,tch))return;
  if(!ngH&&tOnce(&tx,&ty)&&tx<480&&ty<480&&!ttGO){
    int ox=(480-3*TTCL)/2,oy=(480-3*TTCL)/2;
    int col=(tx-ox)/TTCL,row=(ty-oy)/TTCL;
    if(row>=0&&row<3&&col>=0&&col<3&&!ttB[row][col]){
      ttPlace(row,col);
      int w=ttCheck();
      if(w){ttGO=true;sprintf(ttSt,"%s wins!",w==1?"X":"O");}
      else if(ttVar==0&&ttFull()){ttGO=true;strcpy(ttSt,"Draw!");}
      else{ttXT=!ttXT;sprintf(ttSt,"%s's Turn",ttXT?"X":"O");}
      ttDrawBoard();ttDrawPanels();}}
}

#pragma once
static int8_t ttB[3][3];static bool ttXT,ttGO;static char ttSt[64]="";
#define TTCL 140
static void ttInit(){memset(ttB,0,9);ttXT=true;ttGO=false;strcpy(ttSt,"X's Turn");}
static int ttCheck(){for(int i=0;i<3;i++){if(ttB[i][0]&&ttB[i][0]==ttB[i][1]&&ttB[i][1]==ttB[i][2])return ttB[i][0];if(ttB[0][i]&&ttB[0][i]==ttB[1][i]&&ttB[1][i]==ttB[2][i])return ttB[0][i];}
  if(ttB[0][0]&&ttB[0][0]==ttB[1][1]&&ttB[1][1]==ttB[2][2])return ttB[0][0];if(ttB[0][2]&&ttB[0][2]==ttB[1][1]&&ttB[1][1]==ttB[2][0])return ttB[0][2];return 0;}
static bool ttFull(){for(int r=0;r<3;r++)for(int c=0;c<3;c++)if(!ttB[r][c])return false;return true;}
static void ttDrawBoard(){int ox=(480-3*TTCL)/2,oy=(480-3*TTCL)/2;lcd.fillRect(0,0,480,480,0x263238);
  for(int r=0;r<3;r++)for(int c=0;c<3;c++){int x=ox+c*TTCL,y=oy+r*TTCL;lcd.fillRoundRect(x+4,y+4,TTCL-8,TTCL-8,8,0x37474F);lcd.drawRoundRect(x+4,y+4,TTCL-8,TTCL-8,8,0x546E7A);
    if(ttB[r][c]==1){lcd.setFont(&fonts::FreeSansBold24pt7b);lcd.setTextColor(0xE53935);lcd.drawString("X",x+TTCL/2-18,y+TTCL/2-20);}
    if(ttB[r][c]==2){lcd.setFont(&fonts::FreeSansBold24pt7b);lcd.setTextColor(0x1E88E5);lcd.drawString("O",x+TTCL/2-18,y+TTCL/2-20);}}}
static void ttDrawPanels(){lcd.fillRect(PX,0,PW,480,BGC);lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(0xE2B96F);lcd.drawCenterString("TIC TAC TOE",PX+PW/2,20);
  bool xA=ttXT&&!ttGO;bool oA=!ttXT&&!ttGO;
  lcd.fillRoundRect(PX+20,70,PW-40,65,10,xA?0xE53935:0x87CEEB);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(xA?TX:0x111111);lcd.drawCenterString(xA?"X's turn":"X",PX+PW/2,82);
  lcd.fillRoundRect(PX+20,145,PW-40,65,10,oA?0x1E88E5:0x87CEEB);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(oA?TX:0x111111);lcd.drawCenterString(oA?"O's turn":"O",PX+PW/2,157);
  if(ttGO){lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(0xF9A825);lcd.drawCenterString(ttSt,PX+PW/2,230);}
  lcd.fillRect(PX,280,PW,60,BGC);drawNGBtn(PX,280,PW,60);}
void tt_drawOpt(){ttInit();appState=2;lcd.fillScreen(BGC);ttDrawBoard();ttDrawPanels();}
void tt_handleOpt(int16_t tx,int16_t ty){}
void tt_loop(){int16_t tx,ty,rx,ry;bool tch=tRaw(&rx,&ry);if(doNG(PX,280,PW,60,rx,ry,tch))return;
  if(!ngH&&tOnce(&tx,&ty)&&tx<480&&ty<480&&!ttGO){int ox=(480-3*TTCL)/2,oy=(480-3*TTCL)/2;int col=(tx-ox)/TTCL,row=(ty-oy)/TTCL;
    if(row>=0&&row<3&&col>=0&&col<3&&!ttB[row][col]){ttB[row][col]=ttXT?1:2;int w=ttCheck();
      if(w){ttGO=true;sprintf(ttSt,"%s wins!",w==1?"X":"O");}else if(ttFull()){ttGO=true;strcpy(ttSt,"Draw!");}else{ttXT=!ttXT;}ttDrawBoard();ttDrawPanels();}}}

#pragma once
static int8_t ck[8][8];static bool ckWT,ckGO;static int ckSR=-1,ckSC=-1;static bool ckPS=false;
static int ckVM[32][2],ckVC=0;static bool ckFJ=false;
static uint32_t ckWMs,ckBMs,ckLTk;static bool ckClk=false;static char ckSt[64]="";
static lgfx::LGFX_Sprite*ckTopSpr=nullptr;static bool ckPnlDirty=true;

static void ckInit(){memset(ck,0,64);for(int r=0;r<3;r++)for(int c=0;c<8;c++)if((r+c)%2==1)ck[r][c]=2;
  for(int r=5;r<8;r++)for(int c=0;c<8;c++)if((r+c)%2==1)ck[r][c]=1;ckWT=true;ckGO=false;ckPS=false;ckVC=0;ckFJ=false;strcpy(ckSt,"White's Turn");ckPnlDirty=true;}
static bool ckCJ(int r,int c,bool w){int p=ck[r][c];bool k=(p==3||p==4);int d[4][2]={{-1,-1},{-1,1},{1,-1},{1,1}};
  for(auto&dd:d){if(!k&&w&&dd[0]==1)continue;if(!k&&!w&&dd[0]==-1)continue;int mr=r+dd[0],mc=c+dd[1],jr=r+2*dd[0],jc=c+2*dd[1];
    if(jr<0||jr>7||jc<0||jc>7||ck[jr][jc])continue;int mp=ck[mr][mc];if(!mp)continue;
    if(w&&(mp==2||mp==4))return true;if(!w&&(mp==1||mp==3))return true;}return false;}
static bool ckAJ(bool w){for(int r=0;r<8;r++)for(int c=0;c<8;c++){int p=ck[r][c];if(!p)continue;
    if(w&&(p==1||p==3)&&ckCJ(r,c,true))return true;if(!w&&(p==2||p==4)&&ckCJ(r,c,false))return true;}return false;}
static int ckGM(int r,int c,int mv[][2]){int cnt=0;int p=ck[r][c];if(!p)return 0;bool w=(p==1||p==3);bool k=(p==3||p==4);bool mj=ckAJ(w);int d[4][2]={{-1,-1},{-1,1},{1,-1},{1,1}};
  for(auto&dd:d){if(!k&&w&&dd[0]==1)continue;if(!k&&!w&&dd[0]==-1)continue;
    if(mj){int mr=r+dd[0],mc=c+dd[1],jr=r+2*dd[0],jc=c+2*dd[1];if(jr<0||jr>7||jc<0||jc>7||ck[jr][jc])continue;int mp=ck[mr][mc];if(!mp)continue;
      if(w&&(mp==2||mp==4)){mv[cnt][0]=jr;mv[cnt][1]=jc;cnt++;}if(!w&&(mp==1||mp==3)){mv[cnt][0]=jr;mv[cnt][1]=jc;cnt++;}}
    else{int nr=r+dd[0],nc=c+dd[1];if(nr<0||nr>7||nc<0||nc>7||ck[nr][nc])continue;mv[cnt][0]=nr;mv[cnt][1]=nc;cnt++;}}return cnt;}
static bool ckIVT(int r,int c){for(int i=0;i<ckVC;i++)if(ckVM[i][0]==r&&ckVM[i][1]==c)return true;return false;}
static bool ckAM(bool w){for(int r=0;r<8;r++)for(int c=0;c<8;c++){int p=ck[r][c];if(!p)continue;
    if(w&&(p==1||p==3)){int mv[32][2];if(ckGM(r,c,mv)>0)return true;}if(!w&&(p==2||p==4)){int mv[32][2];if(ckGM(r,c,mv)>0)return true;}}return false;}
static void ckDM(int fr,int fc,int tr,int tc){bool j=(abs(tr-fr)==2);if(j)ck[(fr+tr)/2][(fc+tc)/2]=0;
  ck[tr][tc]=ck[fr][fc];ck[fr][fc]=0;if(ck[tr][tc]==1&&tr==0)ck[tr][tc]=3;if(ck[tr][tc]==2&&tr==7)ck[tr][tc]=4;
  if(j&&ckCJ(tr,tc,ckWT)){ckSR=tr;ckSC=tc;ckPS=true;ckFJ=true;ckVC=ckGM(tr,tc,ckVM);return;}
  ckFJ=false;ckWT=!ckWT;ckPnlDirty=true;if(!ckAM(ckWT)){ckGO=true;ckClk=false;snprintf(ckSt,64,"%s wins!",ckWT?"Black":"White");}
  else snprintf(ckSt,64,"%s's Turn",ckWT?"White":"Black");}
static void ckDrawBoard(){lcd.startWrite();
  // Softer board: cream + sage
  for(int r=0;r<8;r++)for(int c=0;c<8;c++){int x=c*CC,y=r*CC;
    uint32_t bg=((r+c)%2==0)?0xEDDDC0:0x4F7556; // soft cream / muted sage
    if(ckPS&&r==ckSR&&c==ckSC)bg=SYLW;
    if(ckPS&&ckIVT(r,c))bg=SGRN;
    lcd.fillRect(x,y,CC,CC,bg);
    int p=ck[r][c];
    if(p){
      uint32_t pc=(p==1||p==3)?0xF4ECE0:0x1F2530; // softer black/white
      uint32_t bd=(p==1||p==3)?0x9C928A:0x4A4F5C;
      lcd.fillCircle(x+CC/2,y+CC/2,CC/2-6,pc);
      lcd.drawCircle(x+CC/2,y+CC/2,CC/2-6,bd);
      lcd.drawCircle(x+CC/2,y+CC/2,CC/2-9,bd);
      if(p==3||p==4){lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(p==3?TXK:GOLD);lcd.drawString("K",x+CC/2-8,y+CC/2-10);}}}
  lcd.endWrite();}
static void ckDrawPanels(){
  if(!ckPnlDirty)return;ckPnlDirty=false;
  // Top: Black (flipped)
  if(!ckTopSpr){ckTopSpr=new lgfx::LGFX_Sprite(&lcd);ckTopSpr->setColorDepth(16);ckTopSpr->createSprite(PW,200);}
  lgfx::LGFX_Sprite*s=ckTopSpr;bool actB=!ckWT&&!ckGO;
  s->fillSprite(0x2A2A2A);
  if(actB){for(int i=0;i<4;i++)s->drawRect(i,i,PW-i*2,200-i*2,YLBORD);}
  s->setFont(&fonts::FreeSansBold12pt7b);s->setTextColor(TX);
  s->drawString(actB?"Black's turn":"BLACK",20,20);
  char buf[16];fmtTime(ckBMs,buf);
  s->setFont(&fonts::FreeSansBold18pt7b);s->setTextColor(actB?YLBORD:TX);s->drawString(buf,180,15);
  if(ckGO){s->setFont(&fonts::FreeSansBold12pt7b);s->setTextColor(GOLD);s->drawString(ckSt,20,160);}
  s->setPivot(PW/2,100);s->pushRotateZoom(PX+PW/2,100,180,1.0,1.0);
  // Mid
  lcd.fillRect(PX,200,PW,80,BGC);drawNGBtn(PX,200,PW,80);
  // Bottom: White
  bool actW=ckWT&&!ckGO;
  lcd.fillRect(PX,280,PW,200,0xF0F0F0);
  if(actW){for(int i=0;i<4;i++)lcd.drawRect(PX+i,280+i,PW-i*2,200-i*2,YLBORD);}
  lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TXK);
  lcd.drawString(actW?"White's turn":"WHITE",PX+20,300);
  fmtTime(ckWMs,buf);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(actW?SRED:TXK);lcd.drawString(buf,PX+180,295);
  if(ckGO){lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(SRED);lcd.drawString(ckSt,PX+15,440);}
}
void ck_drawOpt(){
  lcd.fillScreen(BGC);
  lcd.fillRect(0,0,800,42,SURF);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(GOLD);lcd.drawCenterString("CHECKERS",400,8);
  lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);lcd.drawCenterString("Select Time",400,90);
  const char*lb[]={"5 min","10 min","15 min","20 min","30 min"};
  for(int i=0;i<5;i++){int bx=25+i*155,by=170;
    lcd.fillRoundRect(bx,by,140,80,14,SURF2);lcd.drawRoundRect(bx,by,140,80,14,BORD);
    lcd.fillRect(bx+12,by+12,4,30,SPRP);
    lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(TX);lcd.drawCenterString(lb[i],bx+70,by+28);}}
void ck_handleOpt(int16_t tx,int16_t ty){int tms[]={5,10,15,20,30};for(int i=0;i<5;i++){int bx=25+i*155,by=170;if(tx>=bx&&tx<bx+140&&ty>=by&&ty<by+80){
  ckInit();ckWMs=ckBMs=(uint32_t)tms[i]*60000;ckClk=true;
  ckLTk=millis();appState=2;lcd.fillScreen(BGC);ckDrawBoard();ckPnlDirty=true;ckDrawPanels();return;}}}
void ck_loop(){int16_t tx,ty,rx,ry;bool tch=tRaw(&rx,&ry);if(doNG(PX,200,PW,80,rx,ry,tch))return;
  if(!ngH&&tOnce(&tx,&ty)&&tx<BRD&&ty<BRD&&!ckGO){int col=tx/CC,row=ty/CC;if(row<0||row>7||col<0||col>7)goto cktmr;
    int tp=ck[row][col];bool own=(ckWT?(tp==1||tp==3):(tp==2||tp==4));
    if(!ckPS){if(own&&!ckFJ){ckSR=row;ckSC=col;ckPS=true;ckVC=ckGM(row,col,ckVM);}}
    else if(!ckFJ){if(row==ckSR&&col==ckSC){ckPS=false;ckVC=0;}else if(own){ckSR=row;ckSC=col;ckVC=ckGM(row,col,ckVM);}
      else if(ckIVT(row,col)){ckDM(ckSR,ckSC,row,col);if(!ckFJ){ckPS=false;ckVC=0;}}else{ckPS=false;ckVC=0;}}
    else if(ckIVT(row,col)){ckDM(ckSR,ckSC,row,col);if(!ckFJ){ckPS=false;ckVC=0;}}
    ckDrawBoard();ckPnlDirty=true;ckDrawPanels();}
  cktmr:if(ckClk&&!ckGO){uint32_t now=millis(),dt=now-ckLTk;ckLTk=now;
    if(ckWT){if(ckWMs<=dt){ckWMs=0;ckGO=true;ckClk=false;strcpy(ckSt,"Black wins!");ckPnlDirty=true;ckDrawPanels();}else ckWMs-=dt;}
    else{if(ckBMs<=dt){ckBMs=0;ckGO=true;ckClk=false;strcpy(ckSt,"White wins!");ckPnlDirty=true;ckDrawPanels();}else ckBMs-=dt;}
    static uint32_t cktl=0;if(now-cktl>500){cktl=now;ckPnlDirty=true;ckDrawPanels();}}}

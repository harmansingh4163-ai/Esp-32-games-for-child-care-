#pragma once
// Ludo: clockwise Red(TL), Green(TR), Yellow(BR), Blue(BL)
static int luPl,luCr;static bool luGO=false;static int luD=0;static bool luRl=false;
static int luP[4][4];
static char luSt[64]="";
// Vibrant colors directly
static uint32_t luCl[]={VRED,VGRN,VYLW,VBLU};
static uint32_t luClL[]={0xF5B0B0,0xB5DBB0,0xF5E59A,0xA8C8E8};
static const char*luNm[]={"Red","Green","Yellow","Blue"};
static int luEn[]={0,13,26,39};
static int luHX[]={1,10,10,1};
static int luHY[]={1,1,10,10};
static int luCRX[]={0,9,9,0};
static int luCRY[]={0,0,9,9};
#define LC 32
static bool luIsSafe(int absP){return absP==0||absP==8||absP==13||absP==21||absP==26||absP==34||absP==39||absP==47;}
static const int8_t luTr[52][2]={
  {6,1},{6,2},{6,3},{6,4},{6,5},
  {5,6},{4,6},{3,6},{2,6},{1,6},{0,6},
  {0,7},{0,8},
  {1,8},{2,8},{3,8},{4,8},{5,8},
  {6,9},{6,10},{6,11},{6,12},{6,13},{6,14},
  {7,14},{8,14},
  {8,13},{8,12},{8,11},{8,10},{8,9},
  {9,8},{10,8},{11,8},{12,8},{13,8},{14,8},
  {14,7},{14,6},
  {13,6},{12,6},{11,6},{10,6},{9,6},
  {8,5},{8,4},{8,3},{8,2},{8,1},{8,0},
  {7,0},{6,0}};
static const int8_t luLn[4][6][2]={
  {{7,1},{7,2},{7,3},{7,4},{7,5},{7,6}},
  {{1,7},{2,7},{3,7},{4,7},{5,7},{6,7}},
  {{7,13},{7,12},{7,11},{7,10},{7,9},{7,8}},
  {{13,7},{12,7},{11,7},{10,7},{9,7},{8,7}}};
static bool luNoMove=false;static uint32_t luNoMoveT=0;
static void luInit(int p){luPl=p;luCr=0;luGO=false;luD=0;luRl=false;diceReady=false;diceWait=false;
  for(int i=0;i<4;i++)for(int t=0;t<4;t++)luP[i][t]=-1;luNoMove=false;strcpy(luSt,"Pick a number!");}
static int luFn(int p){int c=0;for(int t=0;t<4;t++)if(luP[p][t]==57)c++;return c;}
static int luHome(int p){int c=0;for(int t=0;t<4;t++)if(luP[p][t]==-1)c++;return c;}
static bool luCM(int p,int t){
  if(luP[p][t]==57)return false;
  if(luP[p][t]==-1)return luD==6;
  int np=luP[p][t]+luD;
  return np<=57;}
static bool luExtraTurn=false;
static bool luCapture=false;
static void luMv(int p,int t){
  luExtraTurn=false;luCapture=false;
  if(luP[p][t]==-1){luP[p][t]=0;return;}
  int oldPos=luP[p][t];
  luP[p][t]+=luD;
  if(luP[p][t]>57)luP[p][t]=57;
  if(luP[p][t]==57&&oldPos<57){luExtraTurn=true;}
  if(luP[p][t]>=0&&luP[p][t]<51){
    int ab=(luP[p][t]+luEn[p])%52;
    if(!luIsSafe(ab)){
      for(int op=0;op<luPl;op++){if(op==p)continue;
        for(int ot=0;ot<4;ot++){
          if(luP[op][ot]<0||luP[op][ot]>=52)continue;
          int oA=(luP[op][ot]+luEn[op])%52;
          if(oA==ab){luP[op][ot]=-1;luCapture=true;}}}}}}
static void luGXY(int p,int t,int*ox,int*oy){
  int ps=luP[p][t];
  if(ps<0){
    int idx=0;for(int tt=0;tt<t;tt++)if(luP[p][tt]==-1)idx++;
    int cx=luHX[p]*LC+2*LC,cy=luHY[p]*LC+2*LC;int sp=LC*3/4;
    int dx[]={-1,1,-1,1},dy[]={-1,-1,1,1};
    *ox=cx+dx[idx]*sp;*oy=cy+dy[idx]*sp;return;}
  if(ps>=51&&ps<=56){
    int li=ps-51;
    *ox=luLn[p][li][1]*LC+LC/2;
    *oy=luLn[p][li][0]*LC+LC/2;return;}
  if(ps==57){
    *ox=7*LC+LC/2+p*8-12;*oy=7*LC+LC/2;return;}
  int ab=(ps+luEn[p])%52;
  *ox=luTr[ab][1]*LC+LC/2;
  *oy=luTr[ab][0]*LC+LC/2;}
static void luDrawDots(int cx,int cy,int cnt,int r){
  if(cnt<=0)return;
  int d=r-2;if(d<2)d=2;
  if(cnt==1){lcd.fillCircle(cx,cy,d,TX);}
  else if(cnt==2){lcd.fillCircle(cx-d-1,cy,d,TX);lcd.fillCircle(cx+d+1,cy,d,TX);}
  else if(cnt==3){lcd.fillCircle(cx,cy-d-1,d,TX);lcd.fillCircle(cx-d-1,cy+d,d,TX);lcd.fillCircle(cx+d+1,cy+d,d,TX);}
  else{lcd.fillCircle(cx-d-1,cy-d-1,d,TX);lcd.fillCircle(cx+d+1,cy-d-1,d,TX);lcd.fillCircle(cx-d-1,cy+d+1,d,TX);lcd.fillCircle(cx+d+1,cy+d+1,d,TX);}}
static int luCntTrack(int p,int absP){int c=0;for(int t=0;t<4;t++){if(luP[p][t]<0||luP[p][t]>=51)continue;if((luP[p][t]+luEn[p])%52==absP)c++;}return c;}
static void luDrawBoard(){
  // Soft cream board
  lcd.fillRect(0,0,480,480,0xE8E2D5);
  // 4 colored corners
  for(int p=0;p<4;p++)lcd.fillRect(luCRX[p]*LC,luCRY[p]*LC,6*LC,6*LC,luCl[p]);
  // Home yards
  for(int i=0;i<4;i++){
    lcd.fillRect(luHX[i]*LC,luHY[i]*LC,4*LC,4*LC,0xF0EBE0);
    lcd.drawRect(luHX[i]*LC,luHY[i]*LC,4*LC,4*LC,0xA89F8E);}
  // Home lanes
  for(int p=0;p<4;p++)for(int i=0;i<6;i++)lcd.fillRect(luLn[p][i][1]*LC,luLn[p][i][0]*LC,LC,LC,luClL[p]);
  // Center
  lcd.fillRect(6*LC,6*LC,3*LC,3*LC,SPRP);
  // Entry squares
  for(int p=0;p<4;p++)lcd.fillRect(luTr[luEn[p]][1]*LC,luTr[luEn[p]][0]*LC,LC,LC,luClL[p]);
  // Safe spaces
  int safeAbs[]={8,21,34,47};
  for(int i=0;i<4;i++){int r=luTr[safeAbs[i]][0],c=luTr[safeAbs[i]][1];lcd.fillRect(c*LC,r*LC,LC,LC,SPNK);}
  // Grid
  for(int r=0;r<15;r++)for(int c=0;c<15;c++){
    bool cr=(c>=6&&c<=8)||(r>=6&&r<=8);
    bool co=(r<6&&c<6)||(r<6&&c>8)||(r>8&&c<6)||(r>8&&c>8);
    if(cr&&!co)lcd.drawRect(c*LC,r*LC,LC,LC,0xC2BAA8);}
  // Tokens at home
  for(int p=0;p<luPl;p++){
    for(int t=0;t<4;t++){
      if(luP[p][t]!=-1)continue;
      int idx=0;for(int tt=0;tt<t;tt++)if(luP[p][tt]==-1)idx++;
      int cx=luHX[p]*LC+2*LC,cy=luHY[p]*LC+2*LC;int sp=LC*3/4;
      int ddx[]={-1,1,-1,1},ddy[]={-1,-1,1,1};
      int px=cx+ddx[idx]*sp;int py=cy+ddy[idx]*sp;
      lcd.fillCircle(px,py,LC/2-4,luCl[p]);lcd.drawCircle(px,py,LC/2-4,0x3A3A3A);
      lcd.fillCircle(px,py,LC/2-9,0xF8F0E0);}}
  // Track tokens
  bool trackDrawn[52];memset(trackDrawn,0,52);
  for(int p=0;p<luPl;p++)for(int t=0;t<4;t++){
    int ps=luP[p][t];if(ps<0||ps>=51)continue;
    int ab=(ps+luEn[p])%52;
    if(trackDrawn[ab])continue;trackDrawn[ab]=true;
    int gx=luTr[ab][1]*LC,gy=luTr[ab][0]*LC;
    bool safe=luIsSafe(ab);
    if(safe){
      int qx[]={0,LC/2,0,LC/2},qy[]={0,0,LC/2,LC/2};
      for(int cp=0;cp<luPl;cp++){
        int cnt=luCntTrack(cp,ab);
        if(cnt>0){
          int cx=gx+qx[cp]+LC/4,cy=gy+qy[cp]+LC/4;
          lcd.fillCircle(cx,cy,LC/4-2,luCl[cp]);
          lcd.drawCircle(cx,cy,LC/4-2,0x3A3A3A);
          if(cnt>1)luDrawDots(cx,cy,cnt,3);}}}
    else{
      int lastP=-1;
      for(int cp=0;cp<luPl;cp++)if(luCntTrack(cp,ab)>0)lastP=cp;
      if(lastP>=0){
        int cnt=luCntTrack(lastP,ab);
        int cx=gx+LC/2,cy=gy+LC/2;
        lcd.fillCircle(cx,cy,LC/2-5,luCl[lastP]);lcd.drawCircle(cx,cy,LC/2-5,0x3A3A3A);
        if(cnt>1)luDrawDots(cx,cy,cnt,3);}}}
  // Lane tokens
  for(int p=0;p<luPl;p++){
    bool drawn[6];memset(drawn,0,6);
    for(int t=0;t<4;t++){
      int ps=luP[p][t];if(ps<51||ps>56)continue;
      int li=ps-51;if(drawn[li])continue;drawn[li]=true;
      int cnt=0;for(int tt=0;tt<4;tt++)if(luP[p][tt]==ps)cnt++;
      int cx=luLn[p][li][1]*LC+LC/2,cy=luLn[p][li][0]*LC+LC/2;
      lcd.fillCircle(cx,cy,LC/2-5,luCl[p]);lcd.drawCircle(cx,cy,LC/2-5,0x3A3A3A);
      if(cnt>1)luDrawDots(cx,cy,cnt,3);}}
  // Finished tokens
  for(int p=0;p<luPl;p++){
    int cnt=luFn(p);if(!cnt)continue;
    int cx=6*LC+LC/2+p*(3*LC/4),cy=7*LC+LC/2;
    lcd.fillCircle(cx,cy,LC/2-4,luCl[p]);lcd.drawCircle(cx,cy,LC/2-4,0x3A3A3A);
    luDrawDots(cx,cy,cnt,3);}}
static void luDraw6Btn(){
  int bx=PX+PW/2-150,by=280;
  bool show=testDice||diceReady;
  for(int i=0;i<6;i++){int x=bx+(i%3)*100,y=by+(i/3)*55;
    lcd.fillRoundRect(x,y,90,48,8,show?SURF2:SURF);
    lcd.drawRoundRect(x,y,90,48,8,show?GOLD:BORD);
    if(testDice){lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(TX);char s[2];sprintf(s,"%d",i+1);lcd.drawCenterString(s,x+45,y+12);}
    else{lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(show?TX:TXD);lcd.drawCenterString("?",x+45,y+12);}}}
static void luDrawPanels(){
  lcd.fillRect(PX,0,PW,480,BGC);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(GOLD);
  lcd.drawCenterString("LUDO",PX+PW/2,12);
  for(int p=0;p<luPl;p++){
    int y=50+p*40;bool cur=(p==luCr&&!luGO);
    lcd.fillRoundRect(PX+15,y,PW-30,34,8,cur?luCl[p]:SURF2);
    lcd.drawRoundRect(PX+15,y,PW-30,34,8,cur?GOLD:BORD);
    lcd.setFont(&fonts::FreeSansBold9pt7b);lcd.setTextColor(cur?TX:TXD);
    char buf[30];sprintf(buf,"P%d %s   %d/4",p+1,luNm[p],luFn(p));
    lcd.drawString(buf,PX+25,y+10);}
  if(!testDice){
    uint32_t rb=diceWait?SURF:PGN;uint32_t rbd=diceWait?BORD:PGNB;
    lcd.fillRoundRect(PX+PW/2-80,235,160,40,10,rb);
    lcd.drawRoundRect(PX+PW/2-80,235,160,40,10,rbd);
    lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);
    lcd.drawCenterString(diceWait?"ROLLING...":"TAP TO ROLL",PX+PW/2,245);}
  if(diceWait){uint32_t el=millis()-diceWaitStart;int pct=min((int)(el*100/1500),100);
    lcd.fillRoundRect(PX+PW/2-70,225,140,6,3,SURF);int w=pct*136/100;if(w>0)lcd.fillRoundRect(PX+PW/2-68,226,w,4,2,GOLD);}
  luDraw6Btn();
  lcd.fillRect(PX+5,395,PW-10,30,BGC);
  if(luNoMove){lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(DANGER);lcd.drawCenterString(luSt,PX+PW/2,398);}
  else if(testDice&&!luRl){lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(GOLD);lcd.drawCenterString("Pick a number!",PX+PW/2,398);}
  else if(diceReady&&!testDice){lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(GOLD);lcd.drawCenterString("Pick a number!",PX+PW/2,398);}
  else if(luRl){lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(SGRN);char db[20];sprintf(db,"Picked: %d",luD);lcd.drawCenterString(db,PX+PW/2,398);}
  lcd.fillRect(PX,430,PW,50,BGC);drawNGBtn(PX,430,PW,50);
  if(luGO){lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(GOLD);lcd.drawString(luSt,PX+40,415);}}
void lu_drawOpt(){
  lcd.fillScreen(BGC);
  lcd.fillRect(0,0,800,42,SURF);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(GOLD);lcd.drawCenterString("LUDO",400,8);
  lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);lcd.drawCenterString("Players",400,100);
  for(int i=0;i<3;i++){int bx=150+i*200,by=160;
    lcd.fillRoundRect(bx,by,160,80,14,SURF2);lcd.drawRoundRect(bx,by,160,80,14,BORD);
    lcd.fillRect(bx+15,by+15,4,30,SORG);
    char s[2];sprintf(s,"%d",i+2);
    lcd.setFont(&fonts::FreeSansBold24pt7b);lcd.setTextColor(TX);lcd.drawCenterString(s,bx+80,by+18);}}
void lu_handleOpt(int16_t tx,int16_t ty){
  for(int i=0;i<3;i++){int bx=150+i*200,by=160;
    if(tx>=bx&&tx<bx+160&&ty>=by&&ty<by+80){luInit(i+2);appState=2;lcd.fillScreen(BGC);luDrawBoard();luDrawPanels();return;}}}
void lu_loop(){
  int16_t tx,ty,rx,ry;bool tch=tRaw(&rx,&ry);
  if(doNG(PX,430,PW,50,rx,ry,tch))return;
  if(luGO){delay(20);return;}
  if(luNoMove){if(millis()-luNoMoveT>1500){luNoMove=false;if(luD!=6)luCr=(luCr+1)%luPl;
    sprintf(luSt,"P%d %s: Pick",luCr+1,luNm[luCr]);luDrawBoard();luDrawPanels();}delay(20);return;}
  if(diceWait){updateDiceWait();luDrawPanels();delay(30);return;}
  if(!ngH&&tOnce(&tx,&ty)){
    if(!testDice&&!luRl&&!diceReady&&tx>=PX+PW/2-80&&tx<PX+PW/2+80&&ty>=235&&ty<275){startDiceWait();luDrawPanels();return;}
    if((testDice||diceReady)&&!luRl){
      int bx=PX+PW/2-150,by=280;
      for(int i=0;i<6;i++){int x=bx+(i%3)*100,y=by+(i/3)*55;
        if(tx>=x&&tx<x+90&&ty>=y&&ty<y+48){
          luD=testDice?(i+1):diceVals[i];diceReady=false;
          bool ca=false;for(int t=0;t<4;t++)if(luCM(luCr,t))ca=true;
          if(ca){luRl=true;sprintf(luSt,"P%d %s: Got %d!",luCr+1,luNm[luCr],luD);}
          else{luRl=false;sprintf(luSt,"P%d %s: Got %d, no moves",luCr+1,luNm[luCr],luD);
            luNoMove=true;luNoMoveT=millis();}
          luDrawBoard();luDrawPanels();return;}}}
    if(luRl&&tx<480&&ty<480){
      for(int t=0;t<4;t++){
        if(!luCM(luCr,t))continue;
        int px,py;luGXY(luCr,t,&px,&py);
        if(abs(tx-px)<20&&abs(ty-py)<20){
          luMv(luCr,t);luRl=false;
          if(luFn(luCr)==4){luGO=true;sprintf(luSt,"%s wins!",luNm[luCr]);}
          else{
            if(luD==6||luExtraTurn||luCapture){sprintf(luSt,"P%d %s: Extra turn!",luCr+1,luNm[luCr]);}
            else{luCr=(luCr+1)%luPl;sprintf(luSt,"P%d %s: Pick",luCr+1,luNm[luCr]);}}
          luDrawBoard();luDrawPanels();break;}}}}}

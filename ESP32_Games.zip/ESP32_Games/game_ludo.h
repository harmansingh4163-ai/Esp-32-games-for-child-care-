#pragma once
// Ludo: clockwise Red(TL), Green(TR), Yellow(BR), Blue(BL)
// Extra turn on 6 or reaching home
static int luPl,luCr;static bool luGO=false;static int luD=0;static bool luRl=false;
static int luP[4][4]; // -1=home yard, 0-51=track, 52-56=lane, 57=finished
static char luSt[64]="";
// Colors: 0=Red(TL), 1=Green(TR), 2=Yellow(BR), 3=Blue(BL)
static uint32_t luCl[]={0xD32F2F,0x388E3C,0xFBC02D,0x1976D2};
static uint32_t luClL[]={0xEF9A9A,0xA5D6A7,0xFFF59D,0x90CAF9};
static const char*luNm[]={"Red","Green","Yellow","Blue"};
// Entry points on track for each color
static int luEn[]={0,13,26,39};
// Home yard corners: Red=TL, Green=TR, Yellow=BR, Blue=BL
static int luHX[]={1,10,10,1}; // top-left x of home yard in grid units
static int luHY[]={1,1,10,10}; // top-left y of home yard
// Corner fill positions
static int luCRX[]={0,9,9,0}; // corner top-left in grid units (*LC)
static int luCRY[]={0,0,9,9};
#define LC 32

// Safe positions: entry points + star positions
static bool luIsSafe(int absP){return absP==0||absP==8||absP==13||absP==21||absP==26||absP==34||absP==39||absP==47;}

// Track positions (52 cells, row,col in 15x15 grid)
static const int8_t luTr[52][2]={
  {6,1},{6,2},{6,3},{6,4},{6,5}, // 0-4
  {5,6},{4,6},{3,6},{2,6},{1,6},{0,6}, // 5-10
  {0,7},{0,8}, // 11-12
  {1,8},{2,8},{3,8},{4,8},{5,8}, // 13-17
  {6,9},{6,10},{6,11},{6,12},{6,13},{6,14}, // 18-23
  {7,14},{8,14}, // 24-25
  {8,13},{8,12},{8,11},{8,10},{8,9}, // 26-30
  {9,8},{10,8},{11,8},{12,8},{13,8},{14,8}, // 31-36
  {14,7},{14,6}, // 37-38
  {13,6},{12,6},{11,6},{10,6},{9,6}, // 39-43
  {8,5},{8,4},{8,3},{8,2},{8,1},{8,0}, // 44-49
  {7,0},{6,0} // 50-51
};

// Home lanes (6 cells toward center for each color)
static const int8_t luLn[4][6][2]={
  {{7,1},{7,2},{7,3},{7,4},{7,5},{7,6}},   // Red
  {{1,7},{2,7},{3,7},{4,7},{5,7},{6,7}},   // Green
  {{7,13},{7,12},{7,11},{7,10},{7,9},{7,8}}, // Yellow
  {{13,7},{12,7},{11,7},{10,7},{9,7},{8,7}}  // Blue
};

static bool luNoMove=false;static uint32_t luNoMoveT=0;
static void luInit(int p){luPl=p;luCr=0;luGO=false;luD=0;luRl=false;diceReady=false;diceWait=false;
  for(int i=0;i<4;i++)for(int t=0;t<4;t++)luP[i][t]=-1;luNoMove=false;strcpy(luSt,"Pick a number!");}

static int luFn(int p){int c=0;for(int t=0;t<4;t++)if(luP[p][t]==57)c++;return c;}
static int luHome(int p){int c=0;for(int t=0;t<4;t++)if(luP[p][t]==-1)c++;return c;}

static bool luCM(int p,int t){
  if(luP[p][t]==57)return false;
  if(luP[p][t]==-1)return luD==6;
  int np=luP[p][t]+luD;
  return np<=57;
}

static bool luExtraTurn=false;
static bool luCapture=false;


static void luMv(int p,int t){
  luExtraTurn=false;luCapture=false;
  if(luP[p][t]==-1){luP[p][t]=0;return;}
  int oldPos=luP[p][t];
  luP[p][t]+=luD;
  if(luP[p][t]>57)luP[p][t]=57;
  // Reached home! Extra turn
  if(luP[p][t]==57&&oldPos<57){luExtraTurn=true;}
  // Capture on non-safe main track
  if(luP[p][t]>=0&&luP[p][t]<51){
    int ab=(luP[p][t]+luEn[p])%52;
    if(!luIsSafe(ab)){
      for(int op=0;op<luPl;op++){if(op==p)continue;
        for(int ot=0;ot<4;ot++){
          if(luP[op][ot]<0||luP[op][ot]>=52)continue;
          int oA=(luP[op][ot]+luEn[op])%52;
          if(oA==ab){luP[op][ot]=-1;luCapture=true;} // captured!
        }
      }
    }
  }
}

// Get pixel position for a token
static void luGXY(int p,int t,int*ox,int*oy){
  int ps=luP[p][t];
  if(ps<0){ // Home yard - centered in white square
    int idx=0;for(int tt=0;tt<t;tt++)if(luP[p][tt]==-1)idx++;
    int cx=luHX[p]*LC+2*LC,cy=luHY[p]*LC+2*LC;int sp=LC*3/4;
    int dx[]={-1,1,-1,1},dy[]={-1,-1,1,1};
    *ox=cx+dx[idx]*sp;*oy=cy+dy[idx]*sp;
    return;
  }
  if(ps>=51&&ps<=56){ // Lane
    int li=ps-51;
    *ox=luLn[p][li][1]*LC+LC/2;
    *oy=luLn[p][li][0]*LC+LC/2;
    return;
  }
  if(ps==57){ // Finished (center)
    *ox=7*LC+LC/2+p*8-12;*oy=7*LC+LC/2;return;
  }
  // Main track
  int ab=(ps+luEn[p])%52;
  *ox=luTr[ab][1]*LC+LC/2;
  *oy=luTr[ab][0]*LC+LC/2;
}

// Draw white dots (1-4) to indicate piece count
static void luDrawDots(int cx,int cy,int cnt,int r){
  if(cnt<=0)return;
  int d=r-2;if(d<2)d=2;
  if(cnt==1){lcd.fillCircle(cx,cy,d,TX);}
  else if(cnt==2){lcd.fillCircle(cx-d-1,cy,d,TX);lcd.fillCircle(cx+d+1,cy,d,TX);}
  else if(cnt==3){lcd.fillCircle(cx,cy-d-1,d,TX);lcd.fillCircle(cx-d-1,cy+d,d,TX);lcd.fillCircle(cx+d+1,cy+d,d,TX);}
  else{lcd.fillCircle(cx-d-1,cy-d-1,d,TX);lcd.fillCircle(cx+d+1,cy-d-1,d,TX);lcd.fillCircle(cx-d-1,cy+d+1,d,TX);lcd.fillCircle(cx+d+1,cy+d+1,d,TX);}
}

// Count pieces of player p at absolute track position
static int luCntTrack(int p,int absP){int c=0;for(int t=0;t<4;t++){if(luP[p][t]<0||luP[p][t]>=51)continue;if((luP[p][t]+luEn[p])%52==absP)c++;}return c;}

static void luDrawBoard(){
  lcd.fillRect(0,0,480,480,0xE8E8E8);
  // Four colored corners: Red=TL, Green=TR, Yellow=BR, Blue=BL
  lcd.fillRect(luCRX[0]*LC,luCRY[0]*LC,6*LC,6*LC,luCl[0]); // Red TL
  lcd.fillRect(luCRX[1]*LC,luCRY[1]*LC,6*LC,6*LC,luCl[1]); // Green TR
  lcd.fillRect(luCRX[2]*LC,luCRY[2]*LC,6*LC,6*LC,luCl[2]); // Yellow BR
  lcd.fillRect(luCRX[3]*LC,luCRY[3]*LC,6*LC,6*LC,luCl[3]); // Blue BL
  // Home yards (white squares)
  for(int i=0;i<4;i++){lcd.fillRect(luHX[i]*LC,luHY[i]*LC,4*LC,4*LC,TX);lcd.drawRect(luHX[i]*LC,luHY[i]*LC,4*LC,4*LC,0x888888);}
  // Home lanes
  for(int p=0;p<4;p++)for(int i=0;i<6;i++)lcd.fillRect(luLn[p][i][1]*LC,luLn[p][i][0]*LC,LC,LC,luClL[p]);
  // Center 3x3 = purple
  lcd.fillRect(6*LC,6*LC,3*LC,3*LC,0x7B1FA2);
  // Entry squares colored per player
  for(int p=0;p<4;p++)lcd.fillRect(luTr[luEn[p]][1]*LC,luTr[luEn[p]][0]*LC,LC,LC,luClL[p]);
  // Safe spaces = pink
  int safeAbs[]={8,21,34,47};
  for(int i=0;i<4;i++){int r=luTr[safeAbs[i]][0],c=luTr[safeAbs[i]][1];lcd.fillRect(c*LC,r*LC,LC,LC,0xF48FB1);}
  // Grid on cross
  for(int r=0;r<15;r++)for(int c=0;c<15;c++){
    bool cr=(c>=6&&c<=8)||(r>=6&&r<=8);
    bool co=(r<6&&c<6)||(r<6&&c>8)||(r>8&&c<6)||(r>8&&c>8);
    if(cr&&!co)lcd.drawRect(c*LC,r*LC,LC,LC,0xBBBBBB);}

  // ---- Draw tokens ----
  // Home yard tokens
  for(int p=0;p<luPl;p++){
    int cnt=luHome(p);
    for(int t=0;t<4;t++){
      if(luP[p][t]!=-1)continue;
      int idx=0;for(int tt=0;tt<t;tt++)if(luP[p][tt]==-1)idx++;
      int cx=luHX[p]*LC+2*LC,cy=luHY[p]*LC+2*LC;int sp=LC*3/4;
      int ddx[]={-1,1,-1,1},ddy[]={-1,-1,1,1};
      int px=cx+ddx[idx]*sp;int py=cy+ddy[idx]*sp;
      lcd.fillCircle(px,py,LC/2-4,luCl[p]);lcd.drawCircle(px,py,LC/2-4,0x333333);
      lcd.fillCircle(px,py,LC/2-9,TX);
    }
  }

  // Track tokens: safe spaces show all colors in quadrants
  // First collect what's on each absolute track position
  bool trackDrawn[52];memset(trackDrawn,0,52);
  for(int p=0;p<luPl;p++)for(int t=0;t<4;t++){
    int ps=luP[p][t];if(ps<0||ps>=51)continue;
    int ab=(ps+luEn[p])%52;
    if(trackDrawn[ab])continue;trackDrawn[ab]=true;
    int gx=luTr[ab][1]*LC,gy=luTr[ab][0]*LC;
    bool safe=luIsSafe(ab);

    if(safe){
      // Draw up to 4 colors in quadrants
      int qx[]={0,LC/2,0,LC/2},qy[]={0,0,LC/2,LC/2};
      for(int cp=0;cp<luPl;cp++){
        int cnt=luCntTrack(cp,ab);
        if(cnt>0){
          int cx=gx+qx[cp]+LC/4,cy=gy+qy[cp]+LC/4;
          lcd.fillCircle(cx,cy,LC/4-2,luCl[cp]);
          lcd.drawCircle(cx,cy,LC/4-2,0x333333);
          if(cnt>1)luDrawDots(cx,cy,cnt,3);
        }
      }
    } else {
      // Normal space: only one color visible (last to arrive)
      // Find which player is here
      int lastP=-1;
      for(int cp=0;cp<luPl;cp++)if(luCntTrack(cp,ab)>0)lastP=cp;
      if(lastP>=0){
        int cnt=luCntTrack(lastP,ab);
        int cx=gx+LC/2,cy=gy+LC/2;
        lcd.fillCircle(cx,cy,LC/2-5,luCl[lastP]);lcd.drawCircle(cx,cy,LC/2-5,0x333333);
        if(cnt>1)luDrawDots(cx,cy,cnt,3);
      }
    }
  }

  // Lane tokens with dot counts
  for(int p=0;p<luPl;p++){
    bool drawn[6];memset(drawn,0,6);
    for(int t=0;t<4;t++){
      int ps=luP[p][t];if(ps<51||ps>56)continue;
      int li=ps-51;if(drawn[li])continue;drawn[li]=true;
      int cnt=0;for(int tt=0;tt<4;tt++)if(luP[p][tt]==ps)cnt++;
      int cx=luLn[p][li][1]*LC+LC/2,cy=luLn[p][li][0]*LC+LC/2;
      lcd.fillCircle(cx,cy,LC/2-5,luCl[p]);lcd.drawCircle(cx,cy,LC/2-5,0x333333);
      if(cnt>1)luDrawDots(cx,cy,cnt,3);
    }
  }

  // Finished tokens in center with dot count
  for(int p=0;p<luPl;p++){
    int cnt=luFn(p);if(!cnt)continue;
    int cx=6*LC+LC/2+p*(3*LC/4),cy=7*LC+LC/2;
    lcd.fillCircle(cx,cy,LC/2-4,luCl[p]);lcd.drawCircle(cx,cy,LC/2-4,0x333333);
    luDrawDots(cx,cy,cnt,3);
  }
}

// 6-button dice panel
static void luDraw6Btn(){int bx=PX+PW/2-150,by=280;
  bool show=testDice||diceReady;
  for(int i=0;i<6;i++){int x=bx+(i%3)*100,y=by+(i/3)*55;
    lcd.fillRoundRect(x,y,90,48,8,show?0x555555:0x333333);lcd.drawRoundRect(x,y,90,48,8,show?0x90CAF9:0x555555);
    if(testDice){lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(TX);char s[2];sprintf(s,"%d",i+1);lcd.drawString(s,x+32,y+8);}
    else{lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(show?TX:0x555555);lcd.drawString("?",x+32,y+8);}}}

static void luDrawPanels(){
  lcd.fillRect(PX,0,PW,480,BGC);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(0xE2B96F);lcd.drawCenterString("LUDO",PX+PW/2,15);
  // Player bars with color names
  for(int p=0;p<luPl;p++){
    int y=60+p*42;bool cur=(p==luCr&&!luGO);
    lcd.fillRoundRect(PX+15,y,PW-30,36,6,cur?luCl[p]:0x333333);
    lcd.setFont(&fonts::FreeSansBold9pt7b);lcd.setTextColor(TX);
    char buf[30];sprintf(buf,"P%d %s [%d/4]",p+1,luNm[p],luFn(p));
    lcd.drawString(buf,PX+25,y+9);
  }
  // Roll button (hidden in test mode)
  if(!testDice){
    lcd.fillRoundRect(PX+PW/2-80,240,160,35,10,0x444444);lcd.drawRoundRect(PX+PW/2-80,240,160,35,10,0x888888);
    lcd.setFont(&fonts::FreeSansBold9pt7b);lcd.setTextColor(diceWait?0xFFFF00:0x90CAF9);
    lcd.drawCenterString(diceWait?"ROLLING...":"TAP TO ROLL",PX+PW/2,250);
  }
  // Wait progress bar
  if(diceWait){uint32_t el=millis()-diceWaitStart;int pct=min((int)(el*100/1500),100);
    lcd.fillRoundRect(PX+PW/2-70,230,140,6,3,0x333333);int w=pct*136/100;if(w>0)lcd.fillRoundRect(PX+PW/2-68,231,w,4,2,0x4CAF50);}
  // 6 buttons
  luDraw6Btn();
  // Status text
  if(luNoMove){lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(0xF44336);lcd.drawCenterString(luSt,PX+PW/2,398);}
  else if(testDice&&!luRl){lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(0x90CAF9);lcd.drawCenterString("Pick a number!",PX+PW/2,398);}
  else if(diceReady&&!testDice){lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(0x90CAF9);lcd.drawCenterString("Pick a number!",PX+PW/2,398);}
  else if(luRl){lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(0xA5D6A7);char db[20];sprintf(db,"Picked: %d",luD);lcd.drawCenterString(db,PX+PW/2,398);}
  // New game button
  lcd.fillRect(PX,430,PW,50,BGC);drawNGBtn(PX,430,PW,50);
  // Win text
  if(luGO){lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(0xF9A825);lcd.drawString(luSt,PX+40,415);}
}

void lu_drawOpt(){lcd.fillScreen(BGC);lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(0xE2B96F);lcd.drawCenterString("LUDO",400,40);
  lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);lcd.drawCenterString("Players:",400,100);
  for(int i=0;i<3;i++){int bx=150+i*200,by=160;lcd.fillRoundRect(bx,by,160,70,12,0xE65100);lcd.drawRoundRect(bx,by,160,70,12,0xFF8F00);
    char s[2];sprintf(s,"%d",i+2);lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(TX);lcd.drawString(s,bx+65,by+18);}}

void lu_handleOpt(int16_t tx,int16_t ty){
  for(int i=0;i<3;i++){int bx=150+i*200,by=160;
    if(tx>=bx&&tx<bx+160&&ty>=by&&ty<by+70){luInit(i+2);appState=2;lcd.fillScreen(BGC);luDrawBoard();luDrawPanels();return;}}}

void lu_loop(){
  int16_t tx,ty,rx,ry;bool tch=tRaw(&rx,&ry);
  if(doNG(PX,430,PW,50,rx,ry,tch))return;
  if(luGO){delay(20);return;}
  // Show "no moves" message for 1.5s then advance turn
  if(luNoMove){if(millis()-luNoMoveT>1500){luNoMove=false;if(luD!=6)luCr=(luCr+1)%luPl;
    sprintf(luSt,"P%d %s: Pick",luCr+1,luNm[luCr]);luDrawBoard();luDrawPanels();}delay(20);return;}
  // Dice wait animation
  if(diceWait){updateDiceWait();luDrawPanels();delay(30);return;}
  if(!ngH&&tOnce(&tx,&ty)){
    // Roll button (normal mode)
    if(!testDice&&!luRl&&!diceReady&&tx>=PX+PW/2-80&&tx<PX+PW/2+80&&ty>=240&&ty<275){startDiceWait();luDrawPanels();return;}
    // Pick from 6 buttons
    if((testDice||diceReady)&&!luRl){
      int bx=PX+PW/2-150,by=280;
      for(int i=0;i<6;i++){int x=bx+(i%3)*100,y=by+(i/3)*55;
        if(tx>=x&&tx<x+90&&ty>=y&&ty<y+48){
          luD=testDice?(i+1):diceVals[i];diceReady=false;
          bool ca=false;for(int t=0;t<4;t++)if(luCM(luCr,t))ca=true;
          if(ca){luRl=true;sprintf(luSt,"P%d %s: Got %d!",luCr+1,luNm[luCr],luD);}
          else{luRl=false;sprintf(luSt,"P%d %s: Got %d, no moves",luCr+1,luNm[luCr],luD);
            luNoMove=true;luNoMoveT=millis();}
          luDrawBoard();luDrawPanels();return;
        }
      }
    }
    // Token tap
    if(luRl&&tx<480&&ty<480){
      for(int t=0;t<4;t++){
        if(!luCM(luCr,t))continue;
        int px,py;luGXY(luCr,t,&px,&py);
        if(abs(tx-px)<20&&abs(ty-py)<20){
          luMv(luCr,t);luRl=false;
          if(luFn(luCr)==4){luGO=true;sprintf(luSt,"%s wins!",luNm[luCr]);}
          else{
            // Extra turn on 6, reaching home, or capture
            if(luD==6||luExtraTurn||luCapture){sprintf(luSt,"P%d %s: Extra turn!",luCr+1,luNm[luCr]);}
            else{luCr=(luCr+1)%luPl;sprintf(luSt,"P%d %s: Pick",luCr+1,luNm[luCr]);}
          }
          luDrawBoard();luDrawPanels();break;
        }
      }
    }
  }
}

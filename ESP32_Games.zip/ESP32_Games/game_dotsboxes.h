#pragma once
// Dots & Boxes - 2 players, timed, selectable 3x3 or 4x4 grid

#define DBMAX 5
#define DBDOT 8

static int dbG=3; // 3 or 4 (boxes per side)
static int dbS=120; // spacing, computed from grid
static int dbOX,dbOY; // offsets, computed

static int8_t dbH[DBMAX+1][DBMAX]; // horizontal lines
static int8_t dbV[DBMAX][DBMAX+1]; // vertical lines
static int8_t dbBox[DBMAX][DBMAX];
static int dbCr;static bool dbGO=false;static char dbSt[64]="";
static int dbSc[2];
static uint32_t dbMs[2],dbLTk;static bool dbClk=false;
static uint32_t dbPC[]={0xE53935,0x1E88E5};

static void dbCalc(){dbS=(dbG==3)?120:90;dbOX=(480-dbG*dbS)/2;dbOY=(480-dbG*dbS)/2;}

static void dbInit(){dbCr=0;dbGO=false;memset(dbH,0,sizeof(dbH));memset(dbV,0,sizeof(dbV));memset(dbBox,0,sizeof(dbBox));memset(dbSc,0,8);
  dbCalc();sprintf(dbSt,"P1's turn");}

static int dbCheckClaim(){int claimed=0;
  for(int r=0;r<dbG;r++)for(int c=0;c<dbG;c++){if(dbBox[r][c])continue;
    if(dbH[r][c]&&dbH[r+1][c]&&dbV[r][c]&&dbV[r][c+1]){dbBox[r][c]=dbCr+1;dbSc[dbCr]++;claimed++;}}
  return claimed;}

static void dbDrawBoard(){
  lcd.fillRect(0,0,480,480,0xFAF3E0);
  for(int r=0;r<dbG;r++)for(int c=0;c<dbG;c++){if(!dbBox[r][c])continue;
    int x=dbOX+c*dbS,y=dbOY+r*dbS;
    uint32_t fc=dbBox[r][c]==1?0xFFCDD2:0xBBDEFB;
    lcd.fillRect(x+4,y+4,dbS-8,dbS-8,fc);lcd.drawRect(x+4,y+4,dbS-8,dbS-8,dbPC[dbBox[r][c]-1]);}
  for(int r=0;r<=dbG;r++)for(int c=0;c<dbG;c++){int x1=dbOX+c*dbS,y1=dbOY+r*dbS;
    if(dbH[r][c])lcd.fillRect(x1+DBDOT,y1-3,dbS-DBDOT*2,7,0x4E342E);
    else for(int i=DBDOT+6;i<dbS-DBDOT-4;i+=10)lcd.fillCircle(x1+i,y1,2,0xD7CCC8);}
  for(int r=0;r<dbG;r++)for(int c=0;c<=dbG;c++){int x1=dbOX+c*dbS,y1=dbOY+r*dbS;
    if(dbV[r][c])lcd.fillRect(x1-3,y1+DBDOT,7,dbS-DBDOT*2,0x4E342E);
    else for(int i=DBDOT+6;i<dbS-DBDOT-4;i+=10)lcd.fillCircle(x1,y1+i,2,0xD7CCC8);}
  for(int r=0;r<=dbG;r++)for(int c=0;c<=dbG;c++){int x=dbOX+c*dbS,y=dbOY+r*dbS;
    lcd.fillCircle(x,y,DBDOT,0x4E342E);lcd.drawCircle(x,y,DBDOT,0x3E2723);}
}

static void dbDrawPanels(){
  lcd.fillRect(PX,0,PW,480,BGC);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(0xE2B96F);lcd.drawCenterString("DOTS & BOXES",PX+PW/2,12);
  for(int p=0;p<2;p++){int y=60+p*70;bool cur=(p==dbCr&&!dbGO);
    lcd.fillRoundRect(PX+15,y,PW-30,60,10,cur?dbPC[p]:0x87CEEB);
    lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(cur?TX:0x111111);
    char buf[30];sprintf(buf,"P%d: %d boxes",p+1,dbSc[p]);lcd.drawString(buf,PX+25,y+8);
    char tb[16];fmtTime(dbMs[p],tb);lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(cur?TX:0x111111);lcd.drawString(tb,PX+180,y+20);}
  int rem=0;for(int r=0;r<dbG;r++)for(int c=0;c<dbG;c++)if(!dbBox[r][c])rem++;
  lcd.setFont(&fonts::FreeSans9pt7b);lcd.setTextColor(0x888888);
  char rb[20];sprintf(rb,"%d of %d boxes left",rem,dbG*dbG);lcd.drawCenterString(rb,PX+PW/2,210);
  lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);lcd.drawCenterString(dbSt,PX+PW/2,240);
  lcd.fillRect(PX,430,PW,50,BGC);drawNGBtn(PX,430,PW,50);
  if(dbGO){lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(0xF9A825);lcd.drawCenterString(dbSt,PX+PW/2,310);}
}

static int dbSelG=3; // selected grid size
void db_drawOpt(){lcd.fillScreen(BGC);lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(0xE2B96F);lcd.drawCenterString("DOTS & BOXES",400,20);
  // Grid size
  lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);lcd.drawCenterString("Grid Size:",400,75);
  const char*gl[]={"4 x 4 dots","5 x 5 dots"};int gv[]={3,4};
  for(int i=0;i<2;i++){int bx=120+i*280,by=105;lcd.fillRoundRect(bx,by,240,55,10,0x5E35B1);lcd.drawRoundRect(bx,by,240,55,10,0xB39DDB);
    lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);lcd.drawCenterString(gl[i],bx+120,by+16);}
  lcd.drawRoundRect(120,105,240,55,10,0xFFFF00); // default highlight 4x4
  // Time
  lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);lcd.drawCenterString("Time per player:",400,185);
  const char*tl[]={"5 min","10 min","15 min"};
  for(int i=0;i<3;i++){int bx=80+i*240,by=220;lcd.fillRoundRect(bx,by,200,65,12,0x5E35B1);lcd.drawRoundRect(bx,by,200,65,12,0xB39DDB);
    lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);lcd.drawCenterString(tl[i],bx+100,by+20);}}

void db_handleOpt(int16_t tx,int16_t ty){
  // Grid selection
  for(int i=0;i<2;i++){int bx=120+i*280,by=105;if(tx>=bx&&tx<bx+240&&ty>=by&&ty<by+55){
    dbSelG=(i==0)?3:4;lcd.drawRoundRect(120,105,240,55,10,0x5E35B1);lcd.drawRoundRect(400,105,240,55,10,0x5E35B1);
    lcd.drawRoundRect(bx,by,240,55,10,0xFFFF00);return;}}
  // Time selection -> start game
  int tms[]={5,10,15};for(int i=0;i<3;i++){int bx=80+i*240,by=220;
    if(tx>=bx&&tx<bx+200&&ty>=by&&ty<by+65){dbG=dbSelG;dbInit();dbMs[0]=dbMs[1]=(uint32_t)tms[i]*60000;dbClk=true;dbLTk=millis();
      appState=2;lcd.fillScreen(BGC);dbDrawBoard();dbDrawPanels();return;}}}

void db_loop(){int16_t tx,ty,rx,ry;bool tch=tRaw(&rx,&ry);
  if(doNG(PX,430,PW,50,rx,ry,tch))return;
  if(dbGO){delay(20);return;}
  if(!ngH&&tOnce(&tx,&ty)&&tx<480&&ty<480){
    int bestD=999;int bestType=-1,bestR=-1,bestC=-1;
    for(int r=0;r<=dbG;r++)for(int c=0;c<dbG;c++){if(dbH[r][c])continue;
      int lx=dbOX+c*dbS+dbS/2,ly=dbOY+r*dbS;int d=abs(tx-lx)+abs(ty-ly);
      if(d<bestD&&d<dbS/2){bestD=d;bestType=0;bestR=r;bestC=c;}}
    for(int r=0;r<dbG;r++)for(int c=0;c<=dbG;c++){if(dbV[r][c])continue;
      int lx=dbOX+c*dbS,ly=dbOY+r*dbS+dbS/2;int d=abs(tx-lx)+abs(ty-ly);
      if(d<bestD&&d<dbS/2){bestD=d;bestType=1;bestR=r;bestC=c;}}
    if(bestType>=0){
      if(bestType==0)dbH[bestR][bestC]=-1;else dbV[bestR][bestC]=-1;
      int claimed=dbCheckClaim();
      bool allDone=true;for(int r=0;r<dbG;r++)for(int c=0;c<dbG;c++)if(!dbBox[r][c])allDone=false;
      if(allDone){dbGO=true;dbClk=false;
        if(dbSc[0]>dbSc[1])strcpy(dbSt,"Player 1 wins!");
        else if(dbSc[1]>dbSc[0])strcpy(dbSt,"Player 2 wins!");
        else strcpy(dbSt,"Draw!");}
      else if(claimed>0){sprintf(dbSt,"P%d claimed %d! Again",dbCr+1,claimed);}
      else{dbCr=1-dbCr;sprintf(dbSt,"P%d's turn",dbCr+1);}
      dbDrawBoard();dbDrawPanels();}
  }
  if(dbClk&&!dbGO){uint32_t now=millis(),dt=now-dbLTk;dbLTk=now;
    if(dbMs[dbCr]<=dt){dbMs[dbCr]=0;dbGO=true;dbClk=false;sprintf(dbSt,"P%d wins on time!",2-dbCr);dbDrawPanels();}
    else dbMs[dbCr]-=dt;
    static uint32_t dbtl=0;if(now-dbtl>500){dbtl=now;
      for(int p=0;p<2;p++){int y=60+p*70;bool cur=(p==dbCr);uint32_t bg=cur?dbPC[p]:0x87CEEB;
        lcd.fillRect(PX+175,y+18,130,35,bg);char tb[16];fmtTime(dbMs[p],tb);
        lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(cur?TX:0x111111);lcd.drawString(tb,PX+180,y+20);}}}
}

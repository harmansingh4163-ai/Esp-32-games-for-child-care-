#pragma once
// Rock Paper Scissors - 2 players. Like the dice mechanic:
// Tap "RANDOMIZE", wait 1.5s, 3 buttons appear with hidden RPS values.
// Player 1 picks one (reveal). Then Player 2 sees their own 3 hidden buttons.
// Player 2 picks one. Reveal both, decide winner, update score.
// State machine:
// 0=Idle (waiting to randomize), 1=Wait (1.5s shuffle), 2=P1 pick, 3=P2 pick, 4=Reveal
static int rpsState=0;
static uint32_t rpsWaitStart=0;
static int rpsP1Vals[3],rpsP2Vals[3]; // shuffled 0=Rock,1=Paper,2=Scissors
static int rpsP1Pick=-1,rpsP2Pick=-1;
static int rpsSc[2]={0,0};
static int rpsRound=1;
static char rpsSt[64]="";
static uint32_t rpsRevealT=0;
static int rpsLastResult=0; // 0=draw,1=P1,2=P2
static const char*rpsNames[]={"Rock","Paper","Scissors"};
static uint32_t rpsColors[]={SCOR,SBLU,SYLW};
static int rpsTargetScore=5;

static void rpsShuffle(int*arr){
  arr[0]=0;arr[1]=1;arr[2]=2;
  for(int i=2;i>0;i--){int j=random(0,i+1);int t=arr[i];arr[i]=arr[j];arr[j]=t;}
}

static void rpsInit(int target){
  randomSeed(millis());
  rpsState=0;rpsSc[0]=rpsSc[1]=0;rpsRound=1;
  rpsP1Pick=rpsP2Pick=-1;rpsTargetScore=target;
  sprintf(rpsSt,"Tap RANDOMIZE to begin");
}

// ---- Symbol drawings ----
static void rpsDrawRock(int cx,int cy,int sz,uint32_t cl){
  // Bumpy circle
  lcd.fillCircle(cx,cy,sz,cl);
  lcd.fillCircle(cx-sz/2,cy-sz/3,sz/3,cl);
  lcd.fillCircle(cx+sz/2,cy-sz/4,sz/3,cl);
  lcd.fillCircle(cx-sz/3,cy+sz/2,sz/3,cl);
  lcd.fillCircle(cx+sz/3,cy+sz/2,sz/4,cl);
  // Highlight
  lcd.fillCircle(cx-sz/3,cy-sz/3,sz/5,0xFFFFFF);
}
static void rpsDrawPaper(int cx,int cy,int sz,uint32_t cl){
  // Rectangle with folded corner
  lcd.fillRoundRect(cx-sz,cy-sz+5,sz*2,sz*2-10,6,cl);
  // Fold corner triangle
  lcd.fillTriangle(cx+sz-15,cy-sz+5,cx+sz,cy-sz+5,cx+sz,cy-sz+20,0xFFFFFF);
  // Lines
  for(int i=0;i<4;i++)lcd.drawLine(cx-sz+10,cy-sz/2+i*sz/3,cx+sz-10,cy-sz/2+i*sz/3,SURF);
}
static void rpsDrawScissors(int cx,int cy,int sz,uint32_t cl){
  // Two blades + handles
  // Top blade
  lcd.fillTriangle(cx-sz,cy+sz-5,cx,cy,cx-sz+5,cy+sz,cl);
  // Bottom blade
  lcd.fillTriangle(cx-sz,cy-sz+5,cx,cy,cx-sz+5,cy-sz,cl);
  // Tip joint
  lcd.fillCircle(cx,cy,5,SURF);
  // Handle rings
  lcd.fillCircle(cx-sz-3,cy-sz+8,8,cl);
  lcd.fillCircle(cx-sz-3,cy-sz+8,5,BGC);
  lcd.fillCircle(cx-sz-3,cy+sz-8,8,cl);
  lcd.fillCircle(cx-sz-3,cy+sz-8,5,BGC);
}
static void rpsDrawSym(int cx,int cy,int sz,int type){
  switch(type){
    case 0:rpsDrawRock(cx,cy,sz,0xB8AFA0);break; // stone color
    case 1:rpsDrawPaper(cx,cy,sz,0xE8E4D9);break; // paper color
    case 2:rpsDrawScissors(cx,cy,sz,0xC0C0CC);break; // silver
  }
}

static void rpsDrawHeader(){
  // Title bar
  lcd.fillRect(0,0,800,55,SURF);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(GOLD);
  lcd.drawCenterString("ROCK PAPER SCISSORS",400,8);
  // Score
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(SRED);
  char b[20];sprintf(b,"P1: %d",rpsSc[0]);
  lcd.drawString(b,40,32);
  lcd.setFont(&fonts::FreeSans9pt7b);lcd.setTextColor(TXD);
  char rb[20];sprintf(rb,"First to %d wins  -  Round %d",rpsTargetScore,rpsRound);
  lcd.drawCenterString(rb,400,38);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(SBLU);
  char b2[20];sprintf(b2,"P2: %d",rpsSc[1]);
  lcd.drawString(b2,700,32);
}

// Draw the 3 hidden buttons for a player. If reveal=true, show value.
static void rpsDrawHiddenBtns(int y,int*vals,int picked,bool reveal,uint32_t accent,const char*lb){
  // Label
  lcd.fillRoundRect(80,y-30,640,28,8,SURF2);
  lcd.drawRoundRect(80,y-30,640,28,8,accent);
  lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(accent);
  lcd.drawCenterString(lb,400,y-26);
  for(int i=0;i<3;i++){
    int bx=80+i*220,by=y,bw=200,bh=140;
    bool isPicked=(picked==i);
    bool showVal=isPicked||reveal;
    uint32_t bg=showVal?SURF2:SURF;
    uint32_t bd=isPicked?GOLD:(showVal?BORD2:accent);
    lcd.fillRoundRect(bx,by,bw,bh,14,bg);
    lcd.drawRoundRect(bx,by,bw,bh,14,bd);
    if(isPicked||reveal){
      rpsDrawSym(bx+bw/2,by+55,38,vals[i]);
      lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(rpsColors[vals[i]]);
      lcd.drawCenterString(rpsNames[vals[i]],bx+bw/2,by+110);
    } else {
      lcd.setFont(&fonts::FreeSansBold24pt7b);lcd.setTextColor(accent);
      lcd.drawCenterString("?",bx+bw/2,by+50);
      lcd.setFont(&fonts::FreeSans9pt7b);lcd.setTextColor(TXD);
      char nb[8];sprintf(nb,"Pick %d",i+1);
      lcd.drawCenterString(nb,bx+bw/2,by+110);
    }
  }
}

// Center action button
static void rpsDrawAction(){
  int bx=240,by=200,bw=320,bh=80;
  switch(rpsState){
    case 0:
      lcd.fillRoundRect(bx,by,bw,bh,16,PGN);
      lcd.drawRoundRect(bx,by,bw,bh,16,PGNB);
      lcd.setFont(&fonts::FreeSansBold24pt7b);lcd.setTextColor(TX);
      lcd.drawCenterString("RANDOMIZE",400,222);
      break;
    case 1: // shuffling
      lcd.fillRoundRect(bx,by,bw,bh,16,SURF);
      lcd.drawRoundRect(bx,by,bw,bh,16,GOLD);
      lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(GOLD);
      lcd.drawCenterString("Shuffling...",400,222);
      {uint32_t el=millis()-rpsWaitStart;int pct=min((int)(el*100/1500),100);
       lcd.fillRoundRect(bx+30,by+55,bw-60,12,5,SURF2);int w=pct*(bw-64)/100;
       if(w>0)lcd.fillRoundRect(bx+32,by+57,w,8,4,GOLD);}
      break;
  }
}

void rpsDrawAll(){
  lcd.fillScreen(BGC);
  rpsDrawHeader();
  switch(rpsState){
    case 0:case 1:
      rpsDrawAction();
      lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TXD);
      lcd.drawCenterString(rpsSt,400,360);
      // Last result memo
      if(rpsRound>1){
        lcd.setFont(&fonts::FreeSans9pt7b);lcd.setTextColor(TXD);
        const char*r=rpsLastResult==0?"Last round: Draw":(rpsLastResult==1?"Last round: Player 1 won":"Last round: Player 2 won");
        lcd.drawCenterString(r,400,390);}
      break;
    case 2:
      rpsDrawHiddenBtns(150,rpsP1Vals,rpsP1Pick,false,SRED,"PLAYER 1 - Pick one (others hidden)");
      lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TXD);
      lcd.drawCenterString("Player 2: Please look away",400,330);
      break;
    case 3:
      rpsDrawHiddenBtns(150,rpsP2Vals,rpsP2Pick,false,SBLU,"PLAYER 2 - Pick one (others hidden)");
      break;
    case 4:{
      // Reveal both - top P1, bottom P2
      // P1
      lcd.fillRoundRect(80,80,640,28,8,SURF2);lcd.drawRoundRect(80,80,640,28,8,SRED);
      lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(SRED);
      lcd.drawCenterString("PLAYER 1 chose",400,84);
      int p1v=rpsP1Vals[rpsP1Pick];
      lcd.fillRoundRect(290,115,220,90,14,SURF2);lcd.drawRoundRect(290,115,220,90,14,SRED);
      rpsDrawSym(400,140,30,p1v);
      lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(rpsColors[p1v]);
      lcd.drawCenterString(rpsNames[p1v],400,180);
      // P2
      lcd.fillRoundRect(80,220,640,28,8,SURF2);lcd.drawRoundRect(80,220,640,28,8,SBLU);
      lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(SBLU);
      lcd.drawCenterString("PLAYER 2 chose",400,224);
      int p2v=rpsP2Vals[rpsP2Pick];
      lcd.fillRoundRect(290,255,220,90,14,SURF2);lcd.drawRoundRect(290,255,220,90,14,SBLU);
      rpsDrawSym(400,280,30,p2v);
      lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(rpsColors[p2v]);
      lcd.drawCenterString(rpsNames[p2v],400,320);
      // Result band
      uint32_t rc=GOLD;const char*rt="Draw!";
      if(p1v!=p2v){
        // Rock(0) beats Scissors(2); Paper(1) beats Rock(0); Scissors(2) beats Paper(1)
        bool p1win=(p1v==0&&p2v==2)||(p1v==1&&p2v==0)||(p1v==2&&p2v==1);
        rc=p1win?SRED:SBLU;rt=p1win?"Player 1 wins!":"Player 2 wins!";
      }
      lcd.fillRoundRect(180,360,440,55,14,SURF2);lcd.drawRoundRect(180,360,440,55,14,rc);
      lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(rc);
      lcd.drawCenterString(rt,400,372);
      // continue prompt
      lcd.setFont(&fonts::FreeSans9pt7b);lcd.setTextColor(TXD);
      lcd.drawCenterString("Tap anywhere to continue",400,432);
      break;}
    case 5:{
      // Game over
      lcd.setFont(&fonts::FreeSansBold24pt7b);lcd.setTextColor(GOLD);
      lcd.drawCenterString(rpsSt,400,180);
      // Final score card
      lcd.fillRoundRect(200,240,400,100,14,SURF);lcd.drawRoundRect(200,240,400,100,14,GOLD);
      char b1[20],b2[20];
      sprintf(b1,"Player 1: %d",rpsSc[0]);sprintf(b2,"Player 2: %d",rpsSc[1]);
      lcd.setFont(&fonts::FreeSansBold18pt7b);
      lcd.setTextColor(SRED);lcd.drawCenterString(b1,400,255);
      lcd.setTextColor(SBLU);lcd.drawCenterString(b2,400,295);
      lcd.setFont(&fonts::FreeSans9pt7b);lcd.setTextColor(TXD);
      lcd.drawCenterString("Hold NEW GAME below to restart",400,360);
      break;}
  }
  drawNGBtn(PX,430,PW,50);
}

void rps_drawOpt(){
  lcd.fillScreen(BGC);
  lcd.fillRect(0,0,800,42,SURF);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(GOLD);
  lcd.drawCenterString("ROCK PAPER SCISSORS",400,8);
  // Info
  lcd.fillRoundRect(60,65,680,180,14,SURF);lcd.drawRoundRect(60,65,680,180,14,BORD);
  lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(GOLD);
  lcd.drawString("How to play",80,80);
  lcd.setFont(&fonts::FreeSans9pt7b);lcd.setTextColor(TX);
  lcd.drawString("- Tap RANDOMIZE. The 3 choices are shuffled and hidden.",80,120);
  lcd.drawString("- Player 1 picks one of 3 buttons (you do not see what you get).",80,145);
  lcd.drawString("- Player 2 then picks one of their own 3 hidden buttons.",80,170);
  lcd.drawString("- Both choices revealed and the winner of the round is scored.",80,195);
  lcd.drawString("- Rock beats Scissors  -  Paper beats Rock  -  Scissors beats Paper",80,220);
  // Target score selection
  lcd.setFont(&fonts::FreeSansBold12pt7b);lcd.setTextColor(TX);
  lcd.drawCenterString("First to win:",400,275);
  int tg[]={3,5,7};
  for(int i=0;i<3;i++){int bx=180+i*170,by=305;
    lcd.fillRoundRect(bx,by,140,75,14,SURF2);lcd.drawRoundRect(bx,by,140,75,14,BORD);
    char s[8];sprintf(s,"%d wins",tg[i]);
    lcd.setFont(&fonts::FreeSansBold18pt7b);lcd.setTextColor(GOLD);
    lcd.drawCenterString(s,bx+70,by+22);}
}

void rps_handleOpt(int16_t tx,int16_t ty){
  int tg[]={3,5,7};
  for(int i=0;i<3;i++){int bx=180+i*170,by=305;
    if(tx>=bx&&tx<bx+140&&ty>=by&&ty<by+75){
      rpsInit(tg[i]);appState=2;rpsDrawAll();return;}}
}

void rps_loop(){
  int16_t tx,ty,rx,ry;bool tch=tRaw(&rx,&ry);
  if(doNG(PX,430,PW,50,rx,ry,tch))return;
  // Shuffle animation
  if(rpsState==1){
    if(millis()-rpsWaitStart>=1500){
      rpsShuffle(rpsP1Vals);
      rpsShuffle(rpsP2Vals);
      rpsP1Pick=rpsP2Pick=-1;
      rpsState=2;
      rpsDrawAll();
    } else {
      // Animate the progress bar
      static uint32_t la=0;
      if(millis()-la>80){la=millis();rpsDrawAction();}
    }
    return;
  }
  if(!ngH&&tOnce(&tx,&ty)){
    if(rpsState==0){
      // Randomize button
      if(tx>=240&&tx<560&&ty>=200&&ty<280){
        rpsState=1;rpsWaitStart=millis();rpsDrawAll();return;}}
    else if(rpsState==2){
      // P1 picks
      for(int i=0;i<3;i++){int bx=80+i*220,by=150,bw=200,bh=140;
        if(tx>=bx&&tx<bx+bw&&ty>=by&&ty<by+bh){
          rpsP1Pick=i;rpsState=3;rpsDrawAll();return;}}}
    else if(rpsState==3){
      // P2 picks
      for(int i=0;i<3;i++){int bx=80+i*220,by=150,bw=200,bh=140;
        if(tx>=bx&&tx<bx+bw&&ty>=by&&ty<by+bh){
          rpsP2Pick=i;rpsState=4;
          // Calculate result and update score
          int v1=rpsP1Vals[rpsP1Pick],v2=rpsP2Vals[rpsP2Pick];
          rpsLastResult=0;
          if(v1!=v2){
            bool p1win=(v1==0&&v2==2)||(v1==1&&v2==0)||(v1==2&&v2==1);
            if(p1win){rpsSc[0]++;rpsLastResult=1;}else{rpsSc[1]++;rpsLastResult=2;}
          }
          rpsDrawAll();return;}}}
    else if(rpsState==4){
      // Tap anywhere -> next round or game over
      if(rpsSc[0]>=rpsTargetScore||rpsSc[1]>=rpsTargetScore){
        rpsState=5;
        sprintf(rpsSt,rpsSc[0]>rpsSc[1]?"Player 1 wins!":"Player 2 wins!");
      } else {
        rpsRound++;rpsState=0;
        sprintf(rpsSt,"Tap RANDOMIZE for round %d",rpsRound);
      }
      rpsDrawAll();return;
    }
  }
}

#ifndef CHESS_TYPES_H
#define CHESS_TYPES_H
#include <Arduino.h>
#define CC 60
#define BRD 480
#define PX 480
#define PW 320
#define TX 0xFFFFFF
#define BGC 0x1A1A2E
#define PGN 0x1B5E20
#endif

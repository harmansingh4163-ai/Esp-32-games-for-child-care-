#ifndef CHESS_TYPES_H
#define CHESS_TYPES_H
#include <Arduino.h>
// ===== Layout constants =====
#define CC 60
#define BRD 480
#define PX 480
#define PW 320
// ===== Palette =====
// Background color. This panel has unusual color rendering; try alternatives
// below if this doesn't look right:
//   0x90EE90  - light green (standard "LightGreen")
//   0xA8D5A0  - soft pastel green
//   0xC0E8C0  - very light green
//   0x1A1F2E  - rendered as bright neon green on this panel
//   0xB8D4A8  - rendered as mint
#define BGC   0x90EE90
#define SURF  0xA8D5A0
#define SURF2 0x6FA3D6
#define SURF3 0x8EBAE0
#define BORD  0x4A8AC0
#define BORD2 0x5E9ACC
#define TX    0xFFFFFF
#define TXD   0xE8F0F8
#define TXK   0x1A1A1A
#define GOLD  0xFFD23F
#define YLBORD 0xFFEB3B
// ===== Vibrant primaries (ONLY for Ludo) =====
#define VRED  0xE53935
#define VGRN  0x43A047
#define VBLU  0x1E88E5
#define VYLW  0xFDD835
// ===== Gentle pastels (used everywhere else) =====
#define SRED  0xC97D7D
#define SGRN  0x8FAD88
#define SBLU  0x7FA4C7
#define SYLW  0xE5C97A
#define SPRP  0xA89BC9
#define SORG  0xE5A370
#define STEA  0x7FAAA8
#define SPNK  0xE5A0B4
#define SCOR  0xE5876B
// Gentle versions of the others used in tile colors
#define VORG  SORG
#define VPRP  SPRP
#define VPNK  SPNK
#define VTEAL STEA
#define VCOR  SCOR
// Action button
#define PGN   0x2E7D32
#define PGNB  0x66BB6A
#define INACT 0x90AEC0
// Status
#define DANGER 0xB55A5A
#define WARN   0xD4A574
#endif
